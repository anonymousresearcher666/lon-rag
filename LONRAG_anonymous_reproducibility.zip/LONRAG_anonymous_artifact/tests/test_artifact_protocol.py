import numpy as np
from bridge_paper_protocol import augmented_scores_with_floor, percentile, fused_scores
from evaluation_common import recall_at_k, paired_bootstrap

def test_recall_at_k():
    assert recall_at_k([1,2],[2,3,1]) == 1.0
    assert recall_at_k([1,2],[1]) == 0.5

def test_percentile_ties_are_stable():
    scores={1:1.0,2:1.0,3:0.0}
    p=percentile(scores,[1,2,3])
    assert p[1] == p[2] == 1.0

def test_graph_append_score_floor_is_strictly_below_parent():
    scored=augmented_scores_with_floor({1:0.5,2:0.2},[1,2,3])
    assert scored[3] < scored[2]

def test_fusion_alpha_zero_is_judge_percentile():
    judge={1:0.1,2:0.9}; svo={1:0.9,2:0.1}
    assert fused_scores(judge,svo,[1,2],alpha=0.0) == percentile(judge,[1,2])

def test_paired_bootstrap_is_deterministic():
    delta=np.asarray([0.0,1.0,-1.0,0.5])
    assert paired_bootstrap(delta,seed=13,samples=100) == paired_bootstrap(delta,seed=13,samples=100)
