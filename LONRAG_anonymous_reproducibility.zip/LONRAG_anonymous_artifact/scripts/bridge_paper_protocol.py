"""Pure BridgeRAG paper-protocol ranking helpers."""
from collections.abc import Iterable
import numpy as np
PROTOCOL_VERSION='bridgerag_paper_v2_floor_augmented'
def merge_rankings(rankings: Iterable[Iterable[tuple[int,float]]]):
 scores={}; sources={}
 for si,ranking in enumerate(rankings):
  for pid,score in ranking: pid=int(pid); scores[pid]=max(scores.get(pid,-np.inf),float(score)); sources.setdefault(pid,set()).add(si)
 return scores,sources
def build_paper_pool(svo_rankings,entity_rankings,*,svo_keep=15,pool_keep=20):
 svo_scores,svo_sources=merge_rankings(svo_rankings); entity_scores,entity_sources=merge_rankings(entity_rankings); svo_top=sorted(svo_scores,key=lambda x:(-svo_scores[x],x))[:svo_keep]; st=set(svo_top); allowed=st|set(entity_scores); pool_scores={i:max(svo_scores[i] if i in st else -np.inf,entity_scores.get(i,-np.inf)) for i in allowed}; pool=sorted(allowed,key=lambda x:(-pool_scores[x],x))[:pool_keep]; sources={}
 for i in pool:
  if i in st:
   for s in sorted(svo_sources.get(i,set())): sources.setdefault(i,set()).add(f'svo_{s}')
  for s in sorted(entity_sources.get(i,set())): sources.setdefault(i,set()).add(f'entity_{s}')
 return pool,svo_top,pool_scores,svo_scores,entity_scores,sources
def augmented_scores_with_floor(canonical_scores,candidates):
 floor=min(float(v) for v in canonical_scores.values()); below=float(np.nextafter(np.float64(floor),np.float64(-np.inf))); return {int(i):float(canonical_scores.get(int(i),below)) for i in candidates}
def percentile(scores,candidates):
 values=np.asarray([float(scores[i]) for i in candidates]); d=len(candidates); return {i:float(np.sum(values<=float(scores[i]))/d) for i in candidates}
def fused_scores(judge_scores,svo_scores,candidates,*,alpha):
 jp=percentile(judge_scores,candidates); sp=percentile(svo_scores,candidates); return {i:(1-alpha)*jp[i]+alpha*sp[i] for i in candidates}
def rank_scores(scores,candidates,k=5): return sorted(candidates,key=lambda i:(-float(scores[i]),i))[:k]
