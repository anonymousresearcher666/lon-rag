#!/usr/bin/env python3
"""Materialize a HippoRAG corpus JSON as one Markdown file per passage."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument('--corpus',required=True,type=Path); p.add_argument('--output',required=True,type=Path); a=p.parse_args(); corpus=json.loads(a.corpus.read_text()); a.output.mkdir(parents=True,exist_ok=True)
 for stale in a.output.glob('*.md'): stale.unlink()
 for i,row in enumerate(corpus):
  title=str(row.get('title') or f'Passage {i}'); text=str(row.get('text') or '').strip(); safe=re.sub(r'[^A-Za-z0-9._-]+','_',title)[:80] or 'doc'; (a.output/f'{i:06d}_{safe}.md').write_text(f'# [{i:06d}] {title}\n\n{text}\n',encoding='utf-8')
 print(f'materialized {len(corpus)} passages in {a.output}')
if __name__=='__main__': raise SystemExit(main())
