#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from collections import Counter
from pathlib import Path
from transformers import AutoTokenizer
QUESTION_FILES={'novel':'novel_questions.json','medical':'medical_questions.json'}; CORPUS_FILES={'novel':'novel.json','medical':'medical.json'}
def canonical(v): return ' '.join(re.findall(r'[a-z0-9]+',v.lower()))
def split_evidence(v): return [p.strip() for p in re.split(r'\s*;\s*',str(v or '').strip()) if p.strip()]
def official_chunks(text,tokenizer,*,chunk_tokens,overlap_tokens):
 toks=tokenizer.encode(text,add_special_tokens=False); out=[]; start=0; step=chunk_tokens-overlap_tokens
 while start<len(toks):
  end=min(start+chunk_tokens,len(toks)); chunk=tokenizer.decode(toks[start:end],skip_special_tokens=True,clean_up_tokenization_spaces=True).strip()
  if chunk: out.append(chunk)
  if end==len(toks): break
  start+=step
 return out
def evidence_to_chunks(evidence,chunks,*,fallback_threshold):
 canon=[canonical(c) for c in chunks]; sets=[set(c.split()) for c in canon]; gold=[]; audit=[]
 for snippet in evidence:
  c=canonical(snippet); matches=[i for i,x in enumerate(canon) if c and c in x]; method='normalized_substring'; score=1.0 if matches else 0.0
  if not matches and c:
   t=set(c.split()); scored=[(len(t&s)/max(1,len(t)),i) for i,s in enumerate(sets)]; best=max((x[0] for x in scored),default=0.0); matches=[i for v,i in scored if v==best] if best>=fallback_threshold else []; method='token_recall_fallback' if matches else 'unmatched'; score=best
  for i in matches:
   if i not in gold: gold.append(i)
  audit.append({'evidence':snippet,'method':method,'score':score,'chunk_ids':matches})
 return gold,audit
def slug(v): return re.sub(r'[^A-Za-z0-9._-]+','_',v).strip('_') or 'corpus'
def main():
 p=argparse.ArgumentParser(); p.add_argument('--benchmark-root',required=True,type=Path); p.add_argument('--subset',choices=sorted(QUESTION_FILES),required=True); p.add_argument('--output-root',type=Path,default=Path('data/graphrag_bench')); p.add_argument('--tokenizer',default='nvidia/NV-Embed-v2'); p.add_argument('--chunk-tokens',type=int,default=256); p.add_argument('--overlap-tokens',type=int,default=32); p.add_argument('--fallback-threshold',type=float,default=.75); a=p.parse_args(); cp=a.benchmark_root/'Datasets'/'Corpus'/CORPUS_FILES[a.subset]; qp=a.benchmark_root/'Datasets'/'Questions'/QUESTION_FILES[a.subset]; tok=AutoTokenizer.from_pretrained(a.tokenizer,trust_remote_code=True); corpora=json.loads(cp.read_text()); corpora=corpora if isinstance(corpora,list) else [corpora]; questions=json.loads(qp.read_text()); by={}
 for r in questions: by.setdefault(str(r.get('source') or ''),[]).append(r)
 root=a.output_root/a.subset; root.mkdir(parents=True,exist_ok=True); manifest={'subset':a.subset,'tokenizer':a.tokenizer,'chunk_tokens':a.chunk_tokens,'overlap_tokens':a.overlap_tokens,'corpora':[]}
 for cr in corpora:
  source=str(cr.get('corpus_name') or '').strip(); context=str(cr.get('context') or '').strip()
  if not source or not context: continue
  chunks=official_chunks(context,tok,chunk_tokens=a.chunk_tokens,overlap_tokens=a.overlap_tokens); d=root/slug(source); docs=d/'docs'; docs.mkdir(parents=True,exist_ok=True)
  for stale in docs.glob('*.md'): stale.unlink()
  passages=[]
  for i,c in enumerate(chunks): passages.append({'id':i,'title':f'Passage {i}','text':c}); (docs/f'{i:06d}_passage.md').write_text(f'# Passage {i}\n\n{c}\n')
  prepared=[]; counts=Counter()
  for pos,row in enumerate(by.get(source,[])):
   gold,audit=evidence_to_chunks(split_evidence(row.get('evidence')),chunks,fallback_threshold=a.fallback_threshold); qt=str(row.get('question_type') or ''); counts[qt]+=1; prepared.append({'id':str(row.get('id') or f'{source}-{pos}'),'source':source,'question':str(row.get('question') or ''),'answer':str(row.get('answer') or ''),'question_type':qt,'evidence':str(row.get('evidence') or ''),'gold_passage_ids':gold,'evidence_mapping':audit})
  (d/'corpus.json').write_text(json.dumps(passages,indent=2,ensure_ascii=False)); (d/'questions.json').write_text(json.dumps(prepared,indent=2,ensure_ascii=False)); summary={'source':source,'passages':len(passages),'questions':len(prepared),'question_types':dict(counts)}; (d/'prepare_summary.json').write_text(json.dumps(summary,indent=2)); manifest['corpora'].append({**summary,'directory':str(d)})
 (root/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)); print(root/'manifest.json')
if __name__=='__main__': raise SystemExit(main())
