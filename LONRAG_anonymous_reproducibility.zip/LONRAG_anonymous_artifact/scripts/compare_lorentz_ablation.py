#!/usr/bin/env python3
"""Common dataset identity and dense/graph retrieval helpers."""
from __future__ import annotations
import json,re
from pathlib import Path
import numpy as np
from clm.pipeline import Memory
from clm.retrieval import PASSAGE_QUERY_INSTRUCTION, rank_passage_chunks
from clm.textembed import embed
from evaluation_common import recall_at_k
FILES={"hotpot":("hotpotqa.json","hotpotqa_corpus.json"),"2wiki":("2wikimultihopqa.json","2wikimultihopqa_corpus.json"),"musique":("musique.json","musique_corpus.json")}
recall=recall_at_k
def canonical(v): return " ".join(v.split())
def corpus_lookup(corpus):
 d={}
 for i,p in enumerate(corpus): d.setdefault((str(p.get('title') or ''),canonical(str(p.get('text') or ''))),i)
 return d
def _fp(text):
 h,_,b=text.partition('\n'); return re.sub(r'^\[\d+\]\s*','',re.sub(r'^#{1,6}\s+','',h.strip())),canonical(b)
def compatible_passage_ids(memory,corpus):
 exp={i:(str(p.get('title') or f'Passage {i}'),canonical(re.sub(r'(?m)^#{1,4}\s+','',str(p.get('text') or '').strip()))) for i,p in enumerate(corpus)}; idx={}
 for n in memory.graph.nodes:
  if n.kind!='chunk': continue
  m=re.match(r'^(\d+)_',n.provenance)
  if m: idx.setdefault(int(m.group(1)),set()).add(_fp(n.text))
 return {i for i,v in exp.items() if v in idx.get(i,set())}
def require_compatible_corpus(memory,corpus):
 x=compatible_passage_ids(memory,corpus)
 if corpus and not x: raise ValueError('loaded index is incompatible with evaluation corpus')
 return x
def gold_ids(dataset,row,lookup):
 if dataset=='musique': supporting=[(p['title'],p['paragraph_text']) for p in row.get('paragraphs',[]) if p.get('is_supporting')]
 else:
  titles={t for t,_ in row.get('supporting_facts',[])}; supporting=[(t,' '.join(s)) for t,s in row.get('context',[]) if t in titles]
 out=[]
 for t,x in supporting:
  i=lookup.get((t,canonical(x)))
  if i is not None and i not in out: out.append(i)
 return out
def passage_ids(memory,chunk_node_ids):
 out=[]
 for node_id in chunk_node_ids:
  m=re.match(r'^(\d+)_',memory.graph.nodes[node_id].provenance)
  if m: out.append(int(m.group(1)))
 return out
def dense_passage_ids(memory,question,top_k):
 _,_,vecs=memory._require_built(); q=embed([question],backend=memory.text_encoder,model=memory.text_model,dim=vecs.shape[1],instruction=PASSAGE_QUERY_INSTRUCTION)[0]; chunks=np.asarray([n.idx for n in memory.graph.nodes if n.kind=='chunk']); sims=vecs[chunks]@q; return passage_ids(memory,[int(chunks[p]) for p in np.argsort(-sims)[:top_k]])
