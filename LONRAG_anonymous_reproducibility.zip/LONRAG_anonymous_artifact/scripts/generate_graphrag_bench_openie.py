#!/usr/bin/env python3
"""Resumable structured OpenIE for prepared GraphRAG-Bench chunks."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from clm import llm
NER_SYSTEM='Extract named entities. Return JSON: {"named_entities": [...]}'
TRIPLE_SYSTEM='Construct RDF-style triples from the passage and named entities. Return JSON: {"triples": [[subject, relation, object], ...]}'
def parse_obj(text):
 text=(text or '').strip()
 try: return json.loads(text)
 except json.JSONDecodeError:
  dec=json.JSONDecoder()
  for i,ch in enumerate(text):
   if ch=='{':
    try:
     x,_=dec.raw_decode(text[i:])
     if isinstance(x,dict): return x
    except json.JSONDecodeError: pass
 raise ValueError('model did not return a JSON object')
def main():
 p=argparse.ArgumentParser(); p.add_argument('--corpus',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--cache-dir',required=True,type=Path); p.add_argument('--provider',default='ollama'); p.add_argument('--model',default='qwen3:30b-a3b'); p.add_argument('--base-url'); p.add_argument('--num-ctx',type=int,default=16384); p.add_argument('--workers',type=int,default=1); p.add_argument('--continue-on-error',action='store_true'); a=p.parse_args(); corpus=json.loads(a.corpus.read_text()); a.cache_dir.mkdir(parents=True,exist_ok=True); docs=[]
 cfg={'provider':a.provider,'model':a.model,'base_url':a.base_url,'num_ctx':a.num_ctx,'think':False,'temperature':0.0,'keep_alive':'30m'}
 for i,row in enumerate(corpus):
  title=str(row.get('title') or f'Passage {i}'); text=str(row.get('text') or ''); digest=hashlib.sha256((a.model+'\0'+title+'\0'+text).encode()).hexdigest(); cache=a.cache_dir/f'{i:06d}_{digest}.json'
  if cache.is_file(): result=json.loads(cache.read_text()); docs.append(result); continue
  passage=f'{title}\n{text}'; errors=[]
  try: entities=parse_obj(llm.chat(passage,system=NER_SYSTEM,provider=a.provider,config=cfg)).get('named_entities',[])
  except Exception as e:
   if not a.continue_on_error: raise
   entities=[]; errors.append({'stage':'NER','error':f'{type(e).__name__}: {e}'})
  try: triples=parse_obj(llm.chat('Passage:\n'+passage+'\n\nNamed entities: '+json.dumps(entities),system=TRIPLE_SYSTEM,provider=a.provider,config=cfg)).get('triples',[])
  except Exception as e:
   if not a.continue_on_error: raise
   triples=[]; errors.append({'stage':'TRIPLES','error':f'{type(e).__name__}: {e}'})
  triples=[[str(x).strip() for x in t] for t in triples if isinstance(t,list) and len(t)==3 and all(str(x).strip() for x in t)]; result={'idx':f'chunk-{i}','title':title,'text':text,'passage':passage,'extracted_entities':[str(x).strip() for x in entities if str(x).strip()],'extracted_triples':triples}
  if errors: result['openie_errors']=errors
  cache.write_text(json.dumps(result,ensure_ascii=False)); docs.append(result)
  if (i+1)%25==0: print(f'openie {i+1}/{len(corpus)}',flush=True)
 a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps({'config':{'provider':a.provider,'model':a.model,'num_ctx':a.num_ctx},'docs':docs,'openie_failures':sum(bool(d.get('openie_errors')) for d in docs)},ensure_ascii=False)); print('wrote',a.output)
if __name__=='__main__': raise SystemExit(main())
