#!/usr/bin/env python3
"""Post-hoc fixed-pool LON-RAG-L evaluator."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from typing import Any
import numpy as np
from clm.geometry import lorentz_dist
from clm.pipeline import Memory
from evaluation_common import paired_bootstrap,recall_at_k

def load_complete(path,expected):
 p=json.loads(Path(path).read_text()); r=p.get('queries',[])
 if p.get('status')!='complete' or len(r)!=expected or p.get('summary',{}).get('queries')!=expected: raise ValueError('source is not a complete matched LON artifact')
 return p
def passage_node_map(memory):
 out={}
 for n in memory.graph.nodes:
  if n.kind!='chunk': continue
  m=re.match(r'^(\d+)_',str(n.provenance))
  if m:
   pid=int(m.group(1))
   if pid in out and out[pid]!=n.idx: raise ValueError('one indexed chunk required per benchmark passage')
   out[pid]=n.idx
 return out
def percentile(scores,candidates):
 vals=np.asarray([scores[i] for i in candidates],dtype=float); d=max(1,len(candidates)); return {i:float(np.sum(vals<=scores[i])/d) for i in candidates}
def interval_class(dt,d):
 if dt<=0: return 'reverse_or_same'
 if dt-d>0: return 'forward_timelike'
 return 'spacelike'
def lorentz_order_scores(bridge_id,candidates,*,z,tau,nodes):
 bn=nodes[bridge_id]; cn=np.asarray([nodes[i] for i in candidates]); bz=np.repeat(z[bn][None,:],len(candidates),axis=0); d=lorentz_dist(bz,z[cn]); dt=tau[cn]-tau[bn]; margins=dt-d
 scores={pid:float(m) for pid,m in zip(candidates,margins)}; diag={pid:{'delta_tau':float(x),'distance':float(y),'margin':float(m),'class':interval_class(float(x),float(y))} for pid,x,y,m in zip(candidates,dt,d,margins)}; return scores,diag
def rerank_record(record,*,z,tau,nodes,alpha,gamma,preserve_dense,include_bridge,preserve_anchors):
 candidates=[int(x) for x in record['candidate_passage_ids']]; bridge=int(record['bridge_passage_id']); judge={int(k):float(v) for k,v in record['judge_scores'].items()}; sim={int(k):float(v) for k,v in record['candidate_similarity_scores'].items()}; jp=percentile(judge,candidates); sp=percentile(sim,candidates); margins,order=lorentz_order_scores(bridge,candidates,z=z,tau=tau,nodes=nodes); lp=percentile(margins,candidates); fused={i:(1-alpha-gamma)*jp[i]+alpha*sp[i]+gamma*lp[i] for i in candidates}; ranked=sorted(candidates,key=lambda i:(-fused[i],i)); dense=[int(x) for x in record.get('dense_passage_ids',[])]; reserved=dense[:preserve_dense]
 if include_bridge:
  for i in [int(x) for x in record.get('bridge_passage_ids',[bridge])][:preserve_anchors]:
   if i not in reserved: reserved.append(i)
 final=(reserved+[i for i in ranked if i not in reserved])[:5]; base=[int(x) for x in record['final_passage_ids']]
 if gamma==0 and final!=base: raise ValueError('gamma=0 did not reproduce source LON ranking')
 gold={int(x) for x in record['gold_passage_ids']}; g=[i for i in candidates if i in gold]; ng=[i for i in candidates if i not in gold]
 for i in candidates: order[i]['percentile']=lp[i]; order[i]['fused_score']=fused[i]
 result=dict(record); result.update({'base_final_passage_ids':base,'base_lon_recall_at_5':float(record['bridge_recall_at_5']),'final_passage_ids':final,'bridge_recall_at_5':recall_at_k(gold,final),'lorentz_order':{str(i):order[i] for i in candidates},'lorentz_gamma':gamma,'lorentz_gold_candidates':len(g),'lorentz_gold_forward':sum(order[i]['class']=='forward_timelike' for i in g),'lorentz_non_gold_candidates':len(ng),'lorentz_non_gold_forward':sum(order[i]['class']=='forward_timelike' for i in ng),'lorentz_gold_margin_sum':float(sum(order[i]['margin'] for i in g)),'lorentz_non_gold_margin_sum':float(sum(order[i]['margin'] for i in ng))}); return result
def main():
 p=argparse.ArgumentParser(); p.add_argument('--index',required=True,type=Path); p.add_argument('--source',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--gamma',required=True,type=float); p.add_argument('--expected',required=True,type=int); a=p.parse_args(); src=load_complete(a.source,a.expected); cfg=src.get('config',{}); alpha=float(cfg['alpha']); mem=Memory.load(a.index); z,tau,_=mem._require_built(); nodes=passage_node_map(mem); records=[rerank_record(r,z=z,tau=tau,nodes=nodes,alpha=alpha,gamma=a.gamma,preserve_dense=int(cfg.get('preserve_dense',0)),include_bridge=bool(cfg.get('include_bridge',False)),preserve_anchors=int(cfg.get('preserve_anchors',3))) for r in src['queries']]; base=np.asarray([r['base_lon_recall_at_5'] for r in records]); values=np.asarray([r['bridge_recall_at_5'] for r in records]); delta=values-base; summary={'queries':len(records),'gamma':a.gamma,'alpha':alpha,'source_lon_recall_at_5':float(base.mean()),'bridge_recall_at_5':float(values.mean()),'delta_vs_lon':float(delta.mean()),'delta_vs_lon_paired_ci95':paired_bootstrap(delta)}; a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps({'config':{'variant':'LON-RAG-L','gamma':a.gamma,'alpha':alpha,'candidate_pool_policy':'identical to source LON artifact','llm_policy':'no new LLM calls'},'status':'complete','summary':summary,'queries':records},indent=2)); print(json.dumps(summary,indent=2))
if __name__=='__main__': raise SystemExit(main())
