#!/usr/bin/env python3
"""Download and verify pinned HippoRAG reference assets."""
from __future__ import annotations
import argparse, hashlib, urllib.request
from pathlib import Path
COMMIT="c617143f01477243992a63b2e2151cc003dd3b21"
HIPPORAG1_HF_REVISION="c7432215c21247d739284a399fa771e625075528"
ASSETS={
"prompt":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/src/hipporag/prompts/dspy_prompts/filter_llama3.3-70B-Instruct.json","sha256":"092b7b2c168e353e549ddf331cb4acef5ed99a9aaf199b0c03614bcd231a685f","output":"data/hipporag2/filter_llama3.3-70B-Instruct.json"},
"qa-prompt":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/src/hipporag/prompts/templates/rag_qa_musique.py","sha256":"6d2b1fc5cf9afc86b11ccb5f4a172314a0e9dca74ffdbcaac6ae0bef13c69561","output":"data/hipporag2/rag_qa_musique.py"},
"musique-queries":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/musique.json","sha256":"98ed4e21d3076532f6388d42320fb809599c63a0d8dffca8ece5e41922be6b46","output":"data/hipporag2/musique.json"},
"musique-corpus":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/musique_corpus.json","sha256":"73157a03ce3f0b1a5673dd5dc12bb970c24976dbffc688af9eecdd758c97ffcb","output":"data/hipporag2/musique_corpus.json"},
"2wiki-queries":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/2wikimultihopqa.json","sha256":"895cba294064df0c3302c76847b1fc08d99b5619f7663dfaa3b65cd780f1cac4","output":"data/hipporag2/2wikimultihopqa.json"},
"2wiki-corpus":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/2wikimultihopqa_corpus.json","sha256":"9d6e352952aafb18dab22bf8195039461321a44a949df902ae83bce134ad238a","output":"data/hipporag2/2wikimultihopqa_corpus.json"},
"2wiki-openie":{"url":f"https://huggingface.co/jonathanjthomas/hipporag-qa/resolve/{HIPPORAG1_HF_REVISION}/output/openie_2wikimultihopqa_results_ner_meta-llama_Llama-3-70b-chat-hf_6119.json","sha256":"b35af2ac12c0ecaa69fd5f2e40f98dbbde0122ca3344fdbda8ff537d0b7ec3fc","output":"data/hipporag2/openie_2wikimultihopqa_results_ner_meta-llama_Llama-3-70b-chat-hf_6119.json"},
"hotpot-queries":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/hotpotqa.json","sha256":None,"output":"data/hipporag2/hotpotqa.json"},
"hotpot-corpus":{"url":f"https://raw.githubusercontent.com/OSU-NLP-Group/HippoRAG/{COMMIT}/reproduce/dataset/hotpotqa_corpus.json","sha256":None,"output":"data/hipporag2/hotpotqa_corpus.json"}}
def main():
 p=argparse.ArgumentParser(); p.add_argument("--asset",choices=sorted(ASSETS),default="prompt"); p.add_argument("--output",type=Path); a=p.parse_args(); spec=ASSETS[a.asset]
 payload=urllib.request.urlopen(spec["url"],timeout=120).read(); digest=hashlib.sha256(payload).hexdigest()
 if spec.get("sha256") and digest != spec["sha256"]: raise RuntimeError(f"checksum mismatch: expected {spec['sha256']}, got {digest}")
 out=a.output or Path(spec["output"]); out.parent.mkdir(parents=True,exist_ok=True); tmp=out.with_suffix(out.suffix+".tmp"); tmp.write_bytes(payload); tmp.replace(out); print(f"sha256={digest}\noutput={out}")
if __name__=="__main__": raise SystemExit(main())
