#!/usr/bin/env python3
"""Generate an aligned OpenIE JSON for a HippoRAG-style corpus.

This is the code-only fallback when a public precomputed OpenIE file is not
used. It deliberately preserves passage order/identity.
"""
from __future__ import annotations
import argparse,json,subprocess,sys,tempfile
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument('--corpus',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--cache-dir',required=True,type=Path); p.add_argument('--provider',default='ollama'); p.add_argument('--model',default='qwen3:30b-a3b'); p.add_argument('--num-ctx',type=int,default=16384); a=p.parse_args(); corpus=json.loads(a.corpus.read_text()); normalized=[{'id':i,'title':str(r.get('title') or f'Passage {i}'),'text':str(r.get('text') or '')} for i,r in enumerate(corpus)]
 with tempfile.NamedTemporaryFile('w',suffix='.json',delete=False,encoding='utf-8') as f: json.dump(normalized,f,ensure_ascii=False); tmp=Path(f.name)
 try: subprocess.run([sys.executable,str(Path(__file__).with_name('generate_graphrag_bench_openie.py')),'--corpus',str(tmp),'--output',str(a.output),'--cache-dir',str(a.cache_dir),'--provider',a.provider,'--model',a.model,'--num-ctx',str(a.num_ctx),'--continue-on-error'],check=True)
 finally: tmp.unlink(missing_ok=True)
if __name__=='__main__': raise SystemExit(main())
