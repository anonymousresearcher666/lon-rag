#!/usr/bin/env python3
"""Calibration/holdout evaluator for recognition-guided PPR.

Protocol: first 100 valid questions are calibration; remaining 900 are frozen
holdout. Candidate views are evaluated independently; a wider recognition view
must strictly beat its parent on calibration before it is evaluated on holdout.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from typing import Any
import numpy as np
from clm.pipeline import Memory
from clm.recognition import FactIndex,RecognitionFilter
from clm.retrieval import rank_passage_chunks
from compare_lorentz_ablation import FILES,corpus_lookup,dense_passage_ids,gold_ids,passage_ids,require_compatible_corpus
from evaluation_common import recall_at_k,paired_bootstrap

def rank(memory,question,facts,recognition,*,candidate_count):
 z,_,vecs=memory._require_built(); enc=memory.coordinate_encoder
 if enc is None: raise RuntimeError('coordinate encoder missing')
 trace={}
 chunks=rank_passage_chunks(question,memory.graph,z,vecs,embedding_backend=memory.text_encoder,embedding_model=memory.text_model,coordinate_encoder=enc,top_k=5,seed_count=5,prefilter=128,propagation_steps=20,reset_probability=.5,activation_weight=1.0,dense_weight=0.0,passage_node_weight=.05,synonym_threshold=.8,synonym_top_k=2047,lorentz_beta=0.0,lorentz_edges=False,lorentz_edge_mix=0.0,fact_index=facts,recognition_filter=recognition,recognition_trace=trace,fact_candidate_count=candidate_count)
 return passage_ids(memory,chunks),trace

def main():
 p=argparse.ArgumentParser(); p.add_argument('dataset',choices=FILES); p.add_argument('--data-root',required=True,type=Path); p.add_argument('--index',required=True,type=Path); p.add_argument('--fact-index',required=True,type=Path); p.add_argument('--prompt',required=True,type=Path); p.add_argument('--cache-root',default=Path('.clm_data/recognition'),type=Path); p.add_argument('--model',default='llama3.3:70b'); p.add_argument('--candidate-counts',nargs='+',type=int,default=[5,20]); p.add_argument('--output-root',required=True,type=Path); a=p.parse_args()
 qf,cf=FILES[a.dataset]; rows=json.loads((a.data_root/qf).read_text()); corpus=json.loads((a.data_root/cf).read_text()); lookup=corpus_lookup(corpus); memory=Memory.load(a.index); facts=FactIndex(a.fact_index); avail=require_compatible_corpus(memory,corpus)
 examples=[]
 for pos,row in enumerate(rows):
  gold=gold_ids(a.dataset,row,lookup)
  if gold and set(gold).issubset(avail): examples.append((str(row.get('id') or row.get('_id') or pos),row,gold))
 if len(examples)<100: raise RuntimeError('fewer than 100 valid examples')
 a.output_root.mkdir(parents=True,exist_ok=True); summaries={}
 for count in a.candidate_counts:
  recog=RecognitionFilter(prompt_path=a.prompt,cache_dir=a.cache_root/f'top{count}',llm_config={'provider':'ollama','model':a.model,'base_url':'http://localhost:11434','think':False,'temperature':0.0})
  for split,subset in [('calibration',examples[:100]),('holdout',examples[100:1000])]:
   records=[]
   for rid,row,gold in subset:
    got,trace=rank(memory,row['question'],facts,recog,candidate_count=count); records.append({'id':rid,'question':row['question'],'gold_passage_ids':gold,'passage_ids':got,'recall_at_5':recall_at_k(gold,got),'recognition':trace})
   out=a.output_root/f'recognition_top{count}_{split}.json'; out.write_text(json.dumps({'summary':{'dataset':a.dataset,'split':split,'queries':len(records),'candidate_count':count,'recall_at_5':float(np.mean([r['recall_at_5'] for r in records]))},'queries':records},indent=2)); summaries[(count,split)]=json.loads(out.read_text())['summary']
 control=a.candidate_counts[0]
 for count in a.candidate_counts[1:]:
  if summaries[(count,'calibration')]['recall_at_5'] <= summaries[(control,'calibration')]['recall_at_5']:
   print(f'WARNING: top-{count} does not strictly improve calibration over top-{control}; paper protocol would not advance it to holdout')
 print(json.dumps({str(k):v for k,v in summaries.items()},indent=2))
if __name__=='__main__': raise SystemExit(main())
