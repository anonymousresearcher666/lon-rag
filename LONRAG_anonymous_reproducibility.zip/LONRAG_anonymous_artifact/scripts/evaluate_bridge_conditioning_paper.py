#!/usr/bin/env python3
"""Exact BridgeRAG paper-protocol evaluator used by the anonymous artifact."""
from __future__ import annotations
import argparse,hashlib,json,os,re,time,urllib.error
from pathlib import Path
import numpy as np
from bridge_paper_protocol import PROTOCOL_VERSION,augmented_scores_with_floor,build_paper_pool,fused_scores,rank_scores
from clm import llm
from clm.pipeline import Memory
from clm.retrieval import PASSAGE_QUERY_INSTRUCTION
from clm.textembed import embed
from compare_lorentz_ablation import FILES,corpus_lookup,gold_ids,require_compatible_corpus
from evaluation_common import paired_bootstrap,recall_at_k
SVO_SYSTEM='You generate targeted retrieval queries for multi-hop QA.'
ENTITY_SYSTEM='You extract concise bridge entities for multi-hop retrieval.'
JUDGE_SYSTEM='You are a retrieval judge for multi-hop QA. Score each candidate from 0 to 10 for whether it is the next supporting passage needed given the bridge.'
PROMPT_VERSION='bridgerag_appendix_exact_batch_v1'; CALL_CACHE_DIR=None; CALL_NUM_CTX=16384; CALL_PROVIDER='ollama'; CALL_BASE_URL=None; MODEL_ATTEMPTS=3; REFRESH_CACHE=False
def passage_text(row):
 t=str(row.get('title') or '').strip(); b=str(row.get('text') or '').strip(); return f'{t}\n{b}' if t else b
def stable_record_id(row,position): return str(row.get('id') or row.get('_id') or position)
def parse_json_object(value):
 text=str(value or '').strip(); fenced=re.search(r'```(?:json)?\s*(\{.*?\})\s*```',text,re.DOTALL)
 if fenced: text=fenced.group(1)
 else:
  m=re.search(r'\{.*\}',text,re.DOTALL)
  if m: text=m.group(0)
 x=json.loads(text)
 if not isinstance(x,dict): raise ValueError('model response is not JSON object')
 return x
def parse_string_list(value,key,expected):
 vals=[str(x).strip() for x in parse_json_object(value).get(key,[]) if str(x).strip()]
 if len(vals)!=expected: raise ValueError(f'{key} returned {len(vals)}, expected {expected}')
 return vals
def parse_score_rows(value): return [x for x in parse_json_object(value).get('scores',[]) if isinstance(x,dict)]
def call_model(prompt,*,system,model,max_tokens,retry_index=0):
 global CALL_CACHE_DIR
 config={'model':model,'base_url':CALL_BASE_URL or os.environ.get('OLLAMA_BASE_URL','http://localhost:11434'),'think':False,'keep_alive':'30m','num_ctx':CALL_NUM_CTX}; digest=hashlib.sha256(json.dumps({'prompt_version':PROMPT_VERSION,'prompt':prompt,'system':system,'model':model,'max_tokens':max_tokens,'retry_index':retry_index},sort_keys=True).encode()).hexdigest(); path=CALL_CACHE_DIR/f'{digest}.json' if CALL_CACHE_DIR else None
 if path and path.is_file() and not REFRESH_CACHE:
  r=json.loads(path.read_text()).get('response')
  if r and str(r).strip(): return str(r)
 response=llm.chat(prompt,system=system,max_tokens=max_tokens,temperature=0.0,provider=CALL_PROVIDER,config=config); response=str(response or '').strip()
 if not response: raise ValueError('empty model response')
 if path: path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps({'response':response},ensure_ascii=False))
 return response
def generate_svo_queries(question,bridge,model):
 prompt=f'Question: {question}\nFirst-hop passage: {bridge}\n\nGenerate exactly 3 targeted queries in Subject-Verb-Object form to retrieve the second supporting passage. Output JSON: {{"queries": ["...", "...", "..."]}}'
 for attempt in range(MODEL_ATTEMPTS):
  try: return parse_string_list(call_model(prompt,system=SVO_SYSTEM,model=model,max_tokens=160,retry_index=attempt),'queries',3)
  except Exception:
   if attempt+1==MODEL_ATTEMPTS: raise
def extract_entities(question,bridge,model):
 prompt=f"Question: {question}\n\nBridge passage:\n{bridge}\n\nIdentify the TWO most relevant answer-side entities needed to answer the question. Reply with ONLY two short entities separated by ' | '."
 for attempt in range(MODEL_ATTEMPTS):
  response=call_model(prompt,system=ENTITY_SYSTEM,model=model,max_tokens=100,retry_index=attempt); vals=[x.strip().strip('"') for x in response.split('|') if x.strip()]
  if len(vals)==1: vals.append(vals[0])
  if len(vals)>=2: return vals[:2]
 raise ValueError('entity extractor failed')
def judge_candidates(question,bridge,entities,candidates,corpus,model):
 rendered=[{'id':i,'title':corpus[i].get('title',''),'passage':passage_text(corpus[i])} for i in candidates]; prompt=f'Query: {question}\nBridge entity 1: {entities[0]}\nBridge entity 2: {entities[1]}\nBridge passage: {bridge}\n\nCandidates:\n{json.dumps(rendered,ensure_ascii=False)}\n\nScore every candidate from 0 to 10. Output strict JSON: {{"scores": [{{"id": 123, "score": 8.5}}, ...]}}.'
 for attempt in range(MODEL_ATTEMPTS):
  rows=parse_score_rows(call_model(prompt,system=JUDGE_SYSTEM,model=model,max_tokens=max(240,16*len(candidates)),retry_index=attempt)); result={}
  for row in rows:
   try: pid=int(row['id']); score=min(10.0,max(0.0,float(row['score'])))
   except Exception: continue
   if pid in candidates: result[pid]=score
  if set(candidates)<=set(result): return result
 raise ValueError('judge failed to score all candidates')
def passage_matrix(memory,corpus_size):
 _,_,vecs=memory._require_built(); ids=[None]*corpus_size
 for n in memory.graph.nodes:
  if n.kind=='chunk':
   m=re.match(r'^(\d+)_',str(n.provenance))
   if m and int(m.group(1))<corpus_size: ids[int(m.group(1))]=n.idx
 if any(i is None for i in ids): raise ValueError('index missing benchmark passage vectors')
 return np.asarray(vecs[np.asarray(ids,dtype=int)],dtype=np.float32)
def embed_queries(values,memory,matrix): return np.asarray(embed(values,backend=memory.text_encoder,model=memory.text_model,dim=matrix.shape[1],instruction=PASSAGE_QUERY_INSTRUCTION),dtype=np.float32)
def ann(values,memory,matrix,*,top_k):
 sims=embed_queries(values,memory,matrix)@matrix.T; return [[(int(i),float(row[i])) for i in np.argsort(-row)[:top_k]] for row in sims]
def exact_svo_scores(svo_queries,candidates,memory,matrix):
 sims=embed_queries(svo_queries,memory,matrix)@matrix[np.asarray(candidates,dtype=int)].T; maxima=np.max(sims,axis=0); return {i:float(s) for i,s in zip(candidates,maxima)}
def append_graph_candidates(candidates,graph_ids,sources,*,corpus_size,top_k):
 added=[]
 for value in graph_ids[:top_k]:
  pid=int(str(value)); sources.setdefault(pid,set()).add('recognition_graph')
  if pid not in candidates: candidates.append(pid); added.append(pid)
 return added
def save(path,payload): path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_text(json.dumps(payload,indent=2,ensure_ascii=False)); tmp.replace(path)
def main():
 global CALL_CACHE_DIR,CALL_NUM_CTX,REFRESH_CACHE
 p=argparse.ArgumentParser(); p.add_argument('dataset',choices=FILES); p.add_argument('--data-root',required=True,type=Path); p.add_argument('--index',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--model',default='qwen3:30b-a3b'); p.add_argument('--num-ctx',type=int,default=16384); p.add_argument('--cache-dir',type=Path,default=Path('.clm_data/bridge_conditioning')); p.add_argument('--refresh-cache',action='store_true'); p.add_argument('--start',type=int,default=0); p.add_argument('--limit',type=int,default=100); p.add_argument('--alpha',type=float,default=.1); p.add_argument('--graph-artifact',type=Path); p.add_argument('--graph-field',default='recognition_ppr_passage_ids'); p.add_argument('--graph-top-k',type=int,default=0); a=p.parse_args(); CALL_CACHE_DIR=a.cache_dir; CALL_NUM_CTX=a.num_ctx; REFRESH_CACHE=a.refresh_cache
 qn,cn=FILES[a.dataset]; rows=json.loads((a.data_root/qn).read_text()); corpus=json.loads((a.data_root/cn).read_text()); memory=Memory.load(a.index); require_compatible_corpus(memory,corpus); matrix=passage_matrix(memory,len(corpus)); lookup=corpus_lookup(corpus); examples=[(r,gold_ids(a.dataset,r,lookup)) for r in rows]; examples=[x for x in examples if x[1]][a.start:a.start+a.limit]; graph_by={}
 if a.graph_artifact:
  gp=json.loads(a.graph_artifact.read_text()); graph_by={str(r['id']):r for r in gp.get('queries',[])}
 config={'protocol_version':PROTOCOL_VERSION,'dataset':a.dataset,'model':a.model,'num_ctx':a.num_ctx,'alpha':a.alpha,'start':a.start,'limit':a.limit,'graph_top_k':a.graph_top_k,'graph_field':a.graph_field,'bridge_selection':'dense_top1','candidate_protocol':'SVO top10 x3 -> SVO-15 + entity top5 x2 -> pool-20','scoring_protocol':'PIT judge + PIT SVO cosine'}; existing=json.loads(a.output.read_text()) if a.output.is_file() else {}; records=list(existing.get('queries',[])); completed={str(r['id']) for r in records}
 for position,(row,gold) in enumerate(examples,start=1):
  rid=stable_record_id(row,a.start+position)
  if rid in completed: continue
  question=row['question']; dense=ann([question],memory,matrix,top_k=5)[0]; bridge_id=dense[0][0]; bridge=passage_text(corpus[bridge_id]); svo=generate_svo_queries(question,bridge,a.model); entities=extract_entities(question,bridge,a.model); candidates,svo15,pool_scores,svo_retrieval,entity_retrieval,sources=build_paper_pool(ann(svo,memory,matrix,top_k=10),ann(entities,memory,matrix,top_k=5)); canonical=list(candidates); added=[]
  if rid in graph_by and a.graph_top_k: added=append_graph_candidates(candidates,graph_by[rid][a.graph_field],sources,corpus_size=len(corpus),top_k=a.graph_top_k)
  svo_scores=augmented_scores_with_floor(exact_svo_scores(svo,canonical,memory,matrix),candidates); judge=judge_candidates(question,bridge,entities,candidates,corpus,a.model); final_scores=fused_scores(judge,svo_scores,candidates,alpha=a.alpha); final=rank_scores(final_scores,candidates,k=5); record={'id':rid,'question':question,'gold_passage_ids':gold,'dense_passage_ids':[i for i,_ in dense],'bridge_passage_id':bridge_id,'bridge_passage_ids':[bridge_id],'svo_queries':svo,'entities':entities,'canonical_candidate_passage_ids':canonical,'candidate_passage_ids':candidates,'added_graph_candidate_ids':added,'candidate_similarity_scores':{str(i):svo_scores[i] for i in candidates},'judge_scores':{str(i):judge[i] for i in candidates},'final_passage_ids':final,'dense_recall_at_5':recall_at_k(gold,[i for i,_ in dense]),'canonical_candidate_gold_coverage':recall_at_k(gold,canonical),'candidate_gold_coverage':recall_at_k(gold,candidates),'bridge_recall_at_5':recall_at_k(gold,final)}; records.append(record); save(a.output,{'config':config,'status':'in_progress','queries':records}); print(f'{position}/{len(examples)}',flush=True)
 dense=np.asarray([r['dense_recall_at_5'] for r in records]); final=np.asarray([r['bridge_recall_at_5'] for r in records]); summary={'queries':len(records),'protocol_version':PROTOCOL_VERSION,'dense_recall_at_5':float(dense.mean()),'candidate_gold_coverage':float(np.mean([r['candidate_gold_coverage'] for r in records])),'bridge_recall_at_5':float(final.mean()),'delta_vs_dense':float((final-dense).mean()),'delta_vs_dense_paired_ci95':paired_bootstrap(final-dense)}; save(a.output,{'config':config,'status':'complete','summary':summary,'queries':records}); print(json.dumps(summary,indent=2))
if __name__=='__main__': raise SystemExit(main())
