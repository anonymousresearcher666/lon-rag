#!/usr/bin/env python3
"""Frozen no-target-tuning GraphRAG-Bench evaluator (Dense/Bridge/LON/LON-L)."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
from clm.pipeline import Memory
from clm.recognition import FactIndex,RecognitionFilter
from clm.retrieval import rank_passage_chunks
from compare_lorentz_ablation import dense_passage_ids,passage_ids
from evaluation_common import recall_at_k
import evaluate_bridge_conditioning_paper as bridge
from evaluate_lon_lorentz_variant import passage_node_map,lorentz_order_scores,percentile

def metric(gold,candidates,final):
 e=recall_at_k(gold,candidates); r=recall_at_k(gold,final); return {'recall_at_5':r,'exposure':e,'utilization':r/e if e else 0.0}
def main():
 p=argparse.ArgumentParser(); p.add_argument('--corpus-dir',required=True,type=Path); p.add_argument('--stack-root',required=True,type=Path); p.add_argument('--output',required=True,type=Path); p.add_argument('--question-type',default='Complex Reasoning'); p.add_argument('--recognition-prompt',required=True,type=Path); p.add_argument('--recognition-model',default='llama3.3:70b'); p.add_argument('--retriever-model',default='qwen3:30b-a3b'); p.add_argument('--fact-candidate-count',type=int,default=20); p.add_argument('--graph-top-k',type=int,default=5); p.add_argument('--alpha',type=float,default=.1); p.add_argument('--gamma',type=float,default=.2); p.add_argument('--cache-root',type=Path,default=Path('.clm_data/graphrag_bench')); a=p.parse_args()
 corpus=json.loads((a.corpus_dir/'corpus.json').read_text()); questions=json.loads((a.corpus_dir/'questions.json').read_text()); eligible=[r for r in questions if r.get('question_type')==a.question_type and r.get('gold_passage_ids')]; memory=Memory.load(a.stack_root/'index'); facts=FactIndex(a.stack_root/'fact_index'); recog=RecognitionFilter(prompt_path=a.recognition_prompt,cache_dir=a.cache_root/'recognition',llm_config={'provider':'ollama','model':a.recognition_model,'base_url':'http://localhost:11434','think':False,'temperature':0.0}); matrix=bridge.passage_matrix(memory,len(corpus)); z,tau,_=memory._require_built(); nodes=passage_node_map(memory); bridge.CALL_CACHE_DIR=a.cache_root/'bridge'; bridge.CALL_NUM_CTX=16384; records=[]
 for pos,row in enumerate(eligible,1):
  q=row['question']; gold=[int(x) for x in row['gold_passage_ids']]; dense=dense_passage_ids(memory,q,5)
  trace={}; chunks=rank_passage_chunks(q,memory.graph,z,memory.text_vecs,embedding_backend=memory.text_encoder,embedding_model=memory.text_model,coordinate_encoder=memory.coordinate_encoder,top_k=5,seed_count=5,prefilter=128,propagation_steps=20,reset_probability=.5,activation_weight=1.0,dense_weight=0.0,passage_node_weight=.05,synonym_threshold=.8,synonym_top_k=2047,lorentz_beta=0.0,lorentz_edges=False,lorentz_edge_mix=0.0,fact_index=facts,recognition_filter=recog,recognition_trace=trace,fact_candidate_count=a.fact_candidate_count); graph_ids=passage_ids(memory,chunks)
  dense_ann=bridge.ann([q],memory,matrix,top_k=5)[0]; bid=dense_ann[0][0]; btext=bridge.passage_text(corpus[bid]); svo=bridge.generate_svo_queries(q,btext,a.retriever_model); entities=bridge.extract_entities(q,btext,a.retriever_model); base_candidates,_,_,_,_,sources=bridge.build_paper_pool(bridge.ann(svo,memory,matrix,top_k=10),bridge.ann(entities,memory,matrix,top_k=5)); base=list(base_candidates); canonical_svo=bridge.exact_svo_scores(svo,base,memory,matrix); base_judge=bridge.judge_candidates(q,btext,entities,base,corpus,a.retriever_model); base_scores=bridge.fused_scores(base_judge,canonical_svo,base,alpha=a.alpha); bridge_final=bridge.rank_scores(base_scores,base,5)
  lon_candidates=list(base); bridge.append_graph_candidates(lon_candidates,graph_ids,sources,corpus_size=len(corpus),top_k=a.graph_top_k); lon_svo=bridge.augmented_scores_with_floor(canonical_svo,lon_candidates); lon_judge=bridge.judge_candidates(q,btext,entities,lon_candidates,corpus,a.retriever_model); lon_scores=bridge.fused_scores(lon_judge,lon_svo,lon_candidates,alpha=a.alpha); lon_final=bridge.rank_scores(lon_scores,lon_candidates,5)
  margins,_=lorentz_order_scores(bid,lon_candidates,z=z,tau=tau,nodes=nodes); jp=percentile(lon_judge,lon_candidates); sp=percentile(lon_svo,lon_candidates); lp=percentile(margins,lon_candidates); l_scores={i:(1-a.alpha-a.gamma)*jp[i]+a.alpha*sp[i]+a.gamma*lp[i] for i in lon_candidates}; l_final=sorted(lon_candidates,key=lambda i:(-l_scores[i],i))[:5]
  records.append({'id':str(row.get('id') or pos),'question':q,'gold_passage_ids':gold,'dense':metric(gold,dense,dense),'recognition':metric(gold,graph_ids,graph_ids),'bridgerag':metric(gold,base,bridge_final),'lon':metric(gold,lon_candidates,lon_final),'lorentz':metric(gold,lon_candidates,l_final)})
  if pos%10==0: print(f'{pos}/{len(eligible)}',flush=True)
 summary={'queries':len(records)}
 for name in ('dense','recognition','bridgerag','lon','lorentz'): summary[f'{name}_recall_at_5']=float(np.mean([r[name]['recall_at_5'] for r in records]))
 a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(json.dumps({'config':{'tuning':'none; frozen MuSiQue settings','fact_candidate_count':a.fact_candidate_count,'graph_top_k':a.graph_top_k,'alpha':a.alpha,'gamma':a.gamma},'status':'complete','summary':summary,'queries':records},indent=2)); print(json.dumps(summary,indent=2))
if __name__=='__main__': raise SystemExit(main())
