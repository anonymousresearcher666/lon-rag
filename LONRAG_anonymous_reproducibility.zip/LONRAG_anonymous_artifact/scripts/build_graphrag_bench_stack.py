#!/usr/bin/env python3
from __future__ import annotations
import argparse,os,subprocess,sys
from pathlib import Path
from clm.pipeline import Memory
from clm.recognition import FactIndex
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(); p.add_argument('--corpus-dir',required=True,type=Path); p.add_argument('--output-root',required=True,type=Path); p.add_argument('--openie-provider',default='ollama'); p.add_argument('--openie-model',default='qwen3:30b-a3b'); p.add_argument('--openie-base-url'); p.add_argument('--openie-num-ctx',type=int,default=16384); p.add_argument('--openie-workers',type=int,default=2); p.add_argument('--embedding-model',default='nvidia/NV-Embed-v2'); p.add_argument('--embedding-batch-size',type=int,default=4); p.add_argument('--geometry-steps',type=int,default=400); p.add_argument('--geometry-dim',type=int,default=8); p.add_argument('--seed',type=int,default=13); a=p.parse_args(); a.output_root.mkdir(parents=True,exist_ok=True); os.environ['CLM_EMBED_BATCH_SIZE']=str(a.embedding_batch_size); openie=a.output_root/'openie.json'; cache=a.output_root/'openie_cache'; idx=a.output_root/'index'; facts=a.output_root/'fact_index'
 if not openie.is_file(): subprocess.run([sys.executable,str(ROOT/'scripts/generate_graphrag_bench_openie.py'),'--corpus',str(a.corpus_dir/'corpus.json'),'--output',str(openie),'--cache-dir',str(cache),'--provider',a.openie_provider,'--model',a.openie_model,'--num-ctx',str(a.openie_num_ctx),'--workers',str(a.openie_workers),'--continue-on-error'],check=True)
 if not (idx/'graph.json').is_file():
  m=Memory(dim=a.geometry_dim,steps=a.geometry_steps,seed=a.seed,margin=.2,text_encoder='nv-embed-v2',text_model=a.embedding_model,training_backend='torch'); m.build(a.corpus_dir/'docs',extractor='openie',openie_results=openie,max_chars=1_000_000,overlap=0); m.save(idx)
 else: m=Memory.load(idx)
 if not (facts/'facts.hnsw').is_file(): FactIndex.build(facts,openie_path=openie,graph=m.graph,backend=m.text_encoder,model=m.text_model,dim=m.text_vecs.shape[1],batch_size=a.embedding_batch_size)
 print('stack complete:',a.output_root)
if __name__=='__main__': raise SystemExit(main())
