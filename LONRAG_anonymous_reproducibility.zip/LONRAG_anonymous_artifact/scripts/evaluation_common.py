"""Shared statistical helpers for benchmark evaluators."""
from __future__ import annotations
from collections.abc import Hashable, Iterable
from typing import TypeVar
import numpy as np
T = TypeVar("T", bound=Hashable)
def recall_at_k(gold: Iterable[T], predicted: Iterable[T]) -> float:
    gold_set=set(gold); return len(gold_set.intersection(predicted))/len(gold_set) if gold_set else 0.0
def paired_bootstrap(delta: np.ndarray, seed: int=13, samples: int=10_000) -> list[float]:
    values=np.asarray(delta,dtype=np.float64)
    if values.ndim != 1 or values.size == 0: raise ValueError("paired bootstrap requires a non-empty one-dimensional array")
    if samples <= 0: raise ValueError("samples must be positive")
    rng=np.random.default_rng(seed); draws=values[rng.integers(0,len(values),size=(samples,len(values)))].mean(axis=1)
    return [float(value) for value in np.quantile(draws,[0.025,0.975])]
