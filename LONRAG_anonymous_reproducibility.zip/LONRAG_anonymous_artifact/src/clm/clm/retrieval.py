"""Role-diverse retrieval and LoCI-Text serialization."""

from __future__ import annotations

from collections import OrderedDict, defaultdict
import hashlib
import os
from pathlib import Path
import re
from typing import Any

import numpy as np

from .geometry import lorentz_dist
from .graph import DEPENDENCY, OPPOSITION, RELATED, TAXONOMIC, Graph
from .encoder import CoordinateEncoder
from .textembed import embed


FACT_QUERY_INSTRUCTION = (
    "Given a question, retrieve relevant triplet facts that matches this question."
)
PASSAGE_QUERY_INSTRUCTION = (
    "Given a question, retrieve relevant documents that best answer the question."
)


_SYNONYM_CACHE: dict[tuple[int, int, float, int], list[tuple[int, int, float]]] = {}
_ROLE_CACHE: dict[int, tuple[dict, dict, dict, dict, dict]] = {}
_MENTION_CACHE: dict[int, dict[int, list[int]]] = {}
_PPR_STRUCTURE_CACHE: dict[tuple, dict[str, np.ndarray]] = {}
_PPR_TRANSITION_CACHE: dict[tuple, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
_PPR_SPARSE_CACHE: dict[tuple, object] = {}
_PPR_SIGNAL_CACHE: OrderedDict[tuple, tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = OrderedDict()
_PPR_SIGNAL_CACHE_LIMIT = 256


def clear_retrieval_caches() -> None:
    """Drop process-global retrieval caches when an index is replaced.

    Cache keys contain object identities for speed. Clearing at index lifecycle
    boundaries prevents a recycled Python object ID from returning another
    graph's adjacency or PPR signal.
    """
    _SYNONYM_CACHE.clear()
    _ROLE_CACHE.clear()
    _MENTION_CACHE.clear()
    _PPR_STRUCTURE_CACHE.clear()
    _PPR_TRANSITION_CACHE.clear()
    _PPR_SPARSE_CACHE.clear()
    _PPR_SIGNAL_CACHE.clear()


def _role_adjacency(graph: Graph):
    """Cache query-invariant typed adjacency for repeated retrieval."""
    key = id(graph)
    if key in _ROLE_CACHE:
        return _ROLE_CACHE[key]
    taxonomy_by_child: dict[int, list[int]] = defaultdict(list)
    children_by_parent: dict[int, list[int]] = defaultdict(list)
    dependency_neighbors: dict[int, list[int]] = defaultdict(list)
    opposition_neighbors: dict[int, list[int]] = defaultdict(list)
    association_neighbors: dict[int, list[int]] = defaultdict(list)
    for edge in graph.edges:
        if edge.etype in TAXONOMIC:
            taxonomy_by_child[edge.src].append(edge.dst)
            children_by_parent[edge.dst].append(edge.src)
        elif edge.etype in DEPENDENCY:
            dependency_neighbors[edge.src].append(edge.dst)
            dependency_neighbors[edge.dst].append(edge.src)
        elif edge.etype in OPPOSITION:
            opposition_neighbors[edge.src].append(edge.dst)
            opposition_neighbors[edge.dst].append(edge.src)
        elif edge.etype in RELATED and edge.etype != "mentioned_in":
            association_neighbors[edge.src].append(edge.dst)
            association_neighbors[edge.dst].append(edge.src)
    value = (
        taxonomy_by_child,
        children_by_parent,
        dependency_neighbors,
        opposition_neighbors,
        association_neighbors,
    )
    _ROLE_CACHE[key] = value
    return value


def _mentions_by_concept(graph: Graph) -> dict[int, list[int]]:
    key = id(graph)
    if key not in _MENTION_CACHE:
        mentions: dict[int, list[int]] = defaultdict(list)
        for edge in graph.edges:
            if edge.etype == "mentioned_in":
                mentions[edge.src].append(edge.dst)
        _MENTION_CACHE[key] = mentions
    return _MENTION_CACHE[key]


def _ppr_structure(
    graph: Graph,
    text_vecs: np.ndarray,
    z: np.ndarray,
    *,
    synonym_threshold: float,
    synonym_top_k: int,
) -> tuple[tuple, dict[str, np.ndarray]]:
    """Build query-invariant HippoRAG-style graph arrays once per index."""
    key = (
        id(graph), id(text_vecs), id(z), float(synonym_threshold), int(synonym_top_k)
    )
    if key in _PPR_STRUCTURE_CACHE:
        return key, _PPR_STRUCTURE_CACHE[key]
    concept_ids = np.asarray([
        node.idx for node in graph.nodes
        if node.kind == "concept"
        and node.provenance != "retrieval_supervision"
    ], dtype=int)
    chunk_ids = np.asarray([
        node.idx for node in graph.nodes if node.kind == "chunk"
    ], dtype=int)
    concept_mask = np.zeros(len(graph.nodes), dtype=bool)
    concept_mask[concept_ids] = True
    fact_src: list[int] = []
    fact_dst: list[int] = []
    mention_degree = np.zeros(len(graph.nodes), dtype=np.int32)
    sources: list[int] = []
    targets: list[int] = []
    observed_weights: list[float] = []
    valid_mask = concept_mask.copy()
    valid_mask[chunk_ids] = True
    for edge in graph.edges:
        if edge.etype == "mentioned_in":
            mention_degree[edge.src] += 1
        elif concept_mask[edge.src] and concept_mask[edge.dst]:
            fact_src.append(edge.src)
            fact_dst.append(edge.dst)
        if valid_mask[edge.src] and valid_mask[edge.dst]:
            sources.extend((edge.src, edge.dst))
            targets.extend((edge.dst, edge.src))
            weight = 1.0 if edge.etype == "mentioned_in" else 2.0
            observed_weights.extend((weight, weight))
    for source, target, weight in _synonym_edges(
        graph,
        text_vecs,
        concept_ids,
        threshold=synonym_threshold,
        top_k=synonym_top_k,
    ):
        sources.extend((source, target))
        targets.extend((target, source))
        observed_weights.extend((weight, weight))
    src = np.asarray(sources, dtype=int)
    dst = np.asarray(targets, dtype=int)
    structure = {
        "concept_ids": concept_ids,
        "chunk_ids": chunk_ids,
        "fact_src": np.asarray(fact_src, dtype=int),
        "fact_dst": np.asarray(fact_dst, dtype=int),
        "mention_degree": mention_degree,
        "src": src,
        "dst": dst,
        "observed": np.asarray(observed_weights, dtype=np.float64),
        "edge_distances": lorentz_dist(z[src], z[dst]) if len(src) else np.zeros(0),
    }
    _PPR_STRUCTURE_CACHE[key] = structure
    return key, structure


def _ppr_transitions(
    structure_key: tuple,
    structure: dict[str, np.ndarray],
    node_count: int,
    *,
    lorentz_edges: bool,
    lorentz_edge_mix: float,
    lorentz_temperature: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    key = (
        structure_key,
        bool(lorentz_edges),
        float(lorentz_edge_mix),
        float(lorentz_temperature),
    )
    if key in _PPR_TRANSITION_CACHE:
        return _PPR_TRANSITION_CACHE[key]
    src = structure["src"]
    dst = structure["dst"]
    observed = structure["observed"]
    if lorentz_edges:
        geometric = np.exp(
            -np.clip(
                structure["edge_distances"] / lorentz_temperature,
                0.0,
                30.0,
            )
        )
        edge_weights = observed * (
            (1.0 - lorentz_edge_mix) + lorentz_edge_mix * geometric
        )
    else:
        edge_weights = observed
    outgoing = np.zeros(node_count, dtype=np.float64)
    np.add.at(outgoing, src, edge_weights)
    transitions = edge_weights / np.maximum(outgoing[src], 1e-12)
    result = (src, dst, transitions)
    _PPR_TRANSITION_CACHE[key] = result
    return result


def _synonym_edges(
    graph: Graph,
    text_vecs: np.ndarray,
    concept_ids: np.ndarray,
    *,
    threshold: float,
    top_k: int,
) -> list[tuple[int, int, float]]:
    """Build HippoRAG-style phrase synonym edges with the local HNSW index."""
    if threshold <= 0.0 or top_k <= 1 or len(concept_ids) < 2:
        return []
    key = (id(graph), id(text_vecs), float(threshold), int(top_k))
    if key in _SYNONYM_CACHE:
        return _SYNONYM_CACHE[key]
    digest = hashlib.sha256()
    digest.update(b"hipporag2-synonym-cap101-directed-v4")
    digest.update(str(text_vecs.shape).encode())
    digest.update(str((float(threshold), int(top_k), len(concept_ids))).encode())
    sample_ids = np.concatenate((concept_ids[:64], concept_ids[-64:]))
    digest.update(np.asarray(text_vecs[sample_ids], dtype=np.float32).tobytes())
    cache_root = Path(os.environ.get(
        "CLM_SYNONYM_CACHE", ".clm_data/synonym_edges"
    ))
    cache_root.mkdir(parents=True, exist_ok=True)
    cache_path = cache_root / f"{digest.hexdigest()}.npz"
    if cache_path.exists():
        with np.load(cache_path) as arrays:
            cached_result = [
                (int(source), int(target), float(weight))
                for source, target, weight in zip(
                    arrays["src"], arrays["dst"], arrays["weight"]
                )
            ]
        _SYNONYM_CACHE[key] = cached_result
        return cached_result
    try:
        import hnswlib
    except ImportError:
        return []
    index = hnswlib.Index(space="ip", dim=text_vecs.shape[1])
    index.init_index(
        max_elements=len(concept_ids), M=32, ef_construction=200, random_seed=13
    )
    index.add_items(
        np.asarray(text_vecs[concept_ids], dtype=np.float32),
        concept_ids.astype(np.int64),
    )
    requested = min(top_k, len(concept_ids))
    index.set_ef(max(128, requested))
    returned = min(requested, 102)
    computed_result: list[tuple[int, int, float]] = []
    batch_size = 512
    retained_per_phrase = 101
    for start in range(0, len(concept_ids), batch_size):
        batch_ids = concept_ids[start:start + batch_size]
        labels, distances = index.knn_query(
            np.asarray(text_vecs[batch_ids], dtype=np.float32), k=returned,
        )
        scores = 1.0 - distances
        valid = (labels != batch_ids[:, None]) & (scores >= threshold)
        for row in range(len(batch_ids)):
            columns = np.flatnonzero(valid[row])[:retained_per_phrase]
            source = int(batch_ids[row])
            for column in columns.tolist():
                target = int(labels[row, column])
                score = float(scores[row, column])
                computed_result.append((source, target, score))
    temporary = cache_path.with_suffix(".tmp")
    with temporary.open("wb") as handle:
        np.savez(
            handle,
            src=np.asarray([edge[0] for edge in computed_result], dtype=np.int32),
            dst=np.asarray([edge[1] for edge in computed_result], dtype=np.int32),
            weight=np.asarray([edge[2] for edge in computed_result], dtype=np.float32),
        )
    os.replace(temporary, cache_path)
    _SYNONYM_CACHE[key] = computed_result
    return computed_result


def retrieve(
    query: str,
    graph: Graph,
    tau: np.ndarray,
    z: np.ndarray,
    text_vecs: np.ndarray,
    *,
    k_seeds: int = 5,
    budget: int = 12,
    alpha: float = 1.0,
    beta: float = 0.08,
    vindex=None,
    prefilter: int = 128,
    embedding_backend: str = "hashed",
    embedding_model: str = "all-MiniLM-L6-v2",
    coordinate_encoder: CoordinateEncoder | None = None,
    expand_roles: bool = True,
    association_hops: int = 2,
    association_width: int = 2,
    association_similarity_margin: float | None = None,
) -> list[tuple[int, str]]:
    """Retrieve concepts, then fill structural roles under a node budget.

    Text candidates are prefiltered by cosine similarity and reranked with the
    spatial coordinate produced by the jointly trained event head.
    """
    del tau
    if budget <= 0 or k_seeds <= 0:
        return []
    if association_hops < 0 or association_width < 0:
        raise ValueError("association_hops and association_width must be non-negative")
    if association_similarity_margin is not None and association_similarity_margin < 0:
        raise ValueError("association_similarity_margin must be non-negative")
    concept_ids = [node.idx for node in graph.nodes if node.kind == "concept"]
    if not concept_ids:
        return []

    query_vector = embed(
        [query],
        backend=embedding_backend,
        model=embedding_model,
        dim=text_vecs.shape[1],
    )[0]
    if query_vector.shape[0] != text_vecs.shape[1]:
        raise ValueError(
            "query embedding dimension does not match the persisted index; "
            "load it with the same text encoder used at build time"
        )

    if vindex is None:
        candidate_ids = concept_ids
    else:
        hits = vindex.search(query_vector, max(prefilter, k_seeds))
        candidate_ids = [
            node_id for node_id, _ in hits if graph.nodes[node_id].kind == "concept"
        ]
        if len(candidate_ids) < min(k_seeds, len(concept_ids)):
            candidate_ids = concept_ids

    candidates = np.asarray(candidate_ids, dtype=int)
    similarities = text_vecs[candidates] @ query_vector
    seed_order = np.argsort(-similarities)[: min(k_seeds, len(candidates))]
    seeds = [int(candidates[position]) for position in seed_order]

    if coordinate_encoder is None:
        query_z = z[seeds[0]]
    else:
        query_z, _ = coordinate_encoder.encode_query_vectors(query_vector[None, :])
        query_z = query_z[0]
    query_batch = np.repeat(query_z[None, :], len(candidates), axis=0)
    distances = lorentz_dist(query_batch, z[candidates])
    scores = alpha * similarities - beta * distances
    dense_similarity_cutoff = float(
        np.sort(similarities)[-min(budget, len(similarities))]
    )

    def rank_by_query(node_ids) -> list[int]:
        eligible = [
            int(node_id)
            for node_id in dict.fromkeys(node_ids)
            if graph.nodes[int(node_id)].kind == "concept"
        ]
        if not eligible:
            return []
        ids = np.asarray(eligible, dtype=int)
        node_similarities = text_vecs[ids] @ query_vector
        node_query_batch = np.repeat(query_z[None, :], len(ids), axis=0)
        node_distances = lorentz_dist(node_query_batch, z[ids])
        node_scores = alpha * node_similarities - beta * node_distances
        return [eligible[int(position)] for position in np.argsort(-node_scores)]

    if not expand_roles:
        order = np.argsort(-scores)[:budget]
        return [
            (int(candidates[position]), "seed" if rank < k_seeds else "context")
            for rank, position in enumerate(order)
        ]

    (
        taxonomy_by_child,
        children_by_parent,
        dependency_neighbors,
        opposition_neighbors,
        association_neighbors,
    ) = _role_adjacency(graph)

    picked: list[int] = []
    roles: dict[int, str] = {}

    def take(node_id: int, role: str) -> None:
        if node_id not in roles and len(picked) < budget:
            picked.append(node_id)
            roles[node_id] = role

    for seed in seeds:
        take(seed, "seed")
    for seed in seeds:
        for parent in taxonomy_by_child.get(seed, ()):
            take(parent, "ancestor")
            for sibling in children_by_parent.get(parent, ()):
                if sibling != seed:
                    take(sibling, "sibling")

    association_frontier = set(seeds)
    association_seen = set(seeds)
    for hop in range(association_hops):
        association_candidates: set[int] = set()
        for node_id in association_frontier:
            association_candidates.update(association_neighbors.get(node_id, ()))
        association_candidates -= association_seen
        ranked_associations = rank_by_query(association_candidates)
        if association_similarity_margin is not None:
            ranked_associations = [
                node_id for node_id in ranked_associations
                if float(text_vecs[node_id] @ query_vector)
                >= dense_similarity_cutoff - association_similarity_margin
            ]
        for node_id in ranked_associations[:association_width]:
            take(node_id, "associate" if hop == 0 else "bridge")
        association_frontier = set(ranked_associations[: max(8, association_width * 4)])
        association_seen.update(association_candidates)
        if not association_frontier or len(picked) == budget:
            break

    frontier = set(seeds)
    seen_frontier = set(seeds)
    for _ in range(2):
        next_frontier: set[int] = set()
        for node_id in frontier:
            for neighbor in dependency_neighbors.get(node_id, ()):
                take(neighbor, "constraint")
                if neighbor not in seen_frontier:
                    next_frontier.add(neighbor)
                    seen_frontier.add(neighbor)
        frontier = next_frontier

    for node_id in list(picked):
        for neighbor in opposition_neighbors.get(node_id, ()):
            take(neighbor, "counter")

    for position in np.argsort(-scores):
        take(int(candidates[position]), "context")
        if len(picked) == budget:
            break
    return [(node_id, roles[node_id]) for node_id in picked]


def evidence_chunks(
    graph: Graph,
    picked_idx,
    max_chunks: int = 4,
    *,
    query_vector: np.ndarray | None = None,
    text_vectors: np.ndarray | None = None,
    z: np.ndarray | None = None,
    query_z: np.ndarray | None = None,
    alpha: float = 1.0,
    beta: float = 0.35,
    activation_weight: float = 0.35,
    candidate_chunk_ids: list[int] | None = None,
) -> list[int]:
    """Rank provenance by the earliest retrieved concept it supports."""
    ordered = sorted(picked_idx) if isinstance(picked_idx, set) else list(picked_idx)
    rank = {node_id: position for position, node_id in enumerate(dict.fromkeys(ordered))}
    chunk_scores: dict[int, tuple[int, int]] = {}
    chunk_activation: dict[int, float] = defaultdict(float)
    mentions_by_concept = _mentions_by_concept(graph)
    for concept_id, concept_rank in rank.items():
        for chunk_id in mentions_by_concept.get(concept_id, ()):
            best_rank, mentions = chunk_scores.get(chunk_id, (len(rank), 0))
            chunk_scores[chunk_id] = (min(best_rank, concept_rank), mentions + 1)
            chunk_activation[chunk_id] += 1.0 / (1.0 + concept_rank)
    for chunk_id in candidate_chunk_ids or []:
        chunk_scores.setdefault(int(chunk_id), (len(rank), 0))
        chunk_activation.setdefault(int(chunk_id), 0.0)
    if (
        chunk_scores
        and query_vector is not None
        and text_vectors is not None
        and z is not None
        and query_z is not None
    ):
        chunk_ids = np.asarray(list(chunk_scores), dtype=int)
        similarities = text_vectors[chunk_ids] @ np.asarray(query_vector)
        query_batch = np.repeat(np.asarray(query_z)[None, :], len(chunk_ids), axis=0)
        distances = lorentz_dist(query_batch, z[chunk_ids])
        activations = np.asarray([chunk_activation[int(chunk_id)] for chunk_id in chunk_ids])
        if float(activations.max()) > 0:
            activations = activations / float(activations.max())
        combined = alpha * similarities - beta * distances + activation_weight * activations
        order = np.argsort(-combined)[:max_chunks]
        return [int(chunk_ids[position]) for position in order]
    return [
        chunk_id
        for chunk_id, _ in sorted(
            chunk_scores.items(),
            key=lambda item: (item[1][0], -item[1][1], item[0]),
        )[:max_chunks]
    ]


def rank_passage_chunks(
    query: str,
    graph: Graph,
    z: np.ndarray,
    text_vecs: np.ndarray,
    *,
    embedding_backend: str,
    embedding_model: str,
    coordinate_encoder: CoordinateEncoder,
    top_k: int = 5,
    seed_count: int = 5,
    prefilter: int = 128,
    propagation_steps: int = 20,
    reset_probability: float = 0.5,
    activation_weight: float = 0.05,
    dense_weight: float = 1.0,
    passage_node_weight: float = 0.05,
    synonym_threshold: float = 0.80,
    synonym_top_k: int = 101,
    lorentz_beta: float = 0.02,
    lorentz_edges: bool = True,
    lorentz_edge_mix: float = 0.25,
    lorentz_temperature: float = 1.0,
    lorentz_path_mix: float = 0.0,
    lorentz_path_temperature: float = 1.0,
    fact_index=None,
    recognition_filter=None,
    recognition_trace: dict | None = None,
    recognition_rejected_weight: float = 0.0,
    fact_candidate_count: int | None = None,
) -> list[int]:
    """Rank passage nodes with query-seeded graph propagation.

    This mirrors HippoRAG-style PPR passage ranking while using learned
    Lorentz distance both to weight graph transitions and to rerank passages.
    """
    if top_k <= 0 or seed_count <= 0:
        return []
    if propagation_steps < 0:
        raise ValueError("propagation_steps must be non-negative")
    if not 0.0 <= reset_probability <= 1.0:
        raise ValueError("reset_probability must lie in [0, 1]")
    if not 0.0 <= lorentz_edge_mix <= 1.0:
        raise ValueError("lorentz_edge_mix must lie in [0, 1]")
    if lorentz_temperature <= 0.0:
        raise ValueError("lorentz_temperature must be positive")
    if not 0.0 <= lorentz_path_mix <= 1.0:
        raise ValueError("lorentz_path_mix must lie in [0, 1]")
    if lorentz_path_temperature <= 0.0:
        raise ValueError("lorentz_path_temperature must be positive")
    if not 0.0 <= recognition_rejected_weight <= 1.0:
        raise ValueError("recognition_rejected_weight must lie in [0, 1]")
    if fact_candidate_count is not None and fact_candidate_count <= 0:
        raise ValueError("fact_candidate_count must be positive")

    recognized_facts = None
    recognized_fact_weights: list[float] | None = None
    fact_candidates = None
    if fact_index is not None:
        candidate_count = fact_candidate_count or seed_count
        fact_candidates = fact_index.search(query, top_k=candidate_count)
        if recognition_filter is not None:
            selected_facts, filter_trace = recognition_filter.filter(
                query, fact_candidates, max_facts=min(4, seed_count)
            )
            if recognition_trace is not None:
                recognition_trace.update(filter_trace)
            if not selected_facts and recognition_rejected_weight == 0.0:
                passage_query_vector = embed(
                    [query], backend=embedding_backend, model=embedding_model,
                    dim=text_vecs.shape[1], instruction=PASSAGE_QUERY_INSTRUCTION,
                )[0]
                chunk_ids = np.asarray(
                    [node.idx for node in graph.nodes if node.kind == "chunk"],
                    dtype=int,
                )
                similarities = text_vecs[chunk_ids] @ passage_query_vector
                return [
                    int(chunk_ids[position])
                    for position in np.argsort(-similarities)[:top_k]
                ]
            if recognition_rejected_weight > 0.0:
                selected_indices = {candidate.index for candidate in selected_facts}
                recognized_facts = fact_candidates
                recognized_fact_weights = [
                    1.0 if candidate.index in selected_indices
                    else recognition_rejected_weight
                    for candidate in recognized_facts
                ]
            else:
                recognized_facts = selected_facts
                recognized_fact_weights = [1.0] * len(recognized_facts)
        else:
            recognized_facts = fact_candidates
            recognized_fact_weights = [1.0] * len(recognized_facts)
        fact_query_vector = None
    else:
        fact_query_vector = embed(
            [query],
            backend=embedding_backend,
            model=embedding_model,
            dim=text_vecs.shape[1],
            instruction=FACT_QUERY_INSTRUCTION,
        )[0]
    passage_query_vector = embed(
        [query],
        backend=embedding_backend,
        model=embedding_model,
        dim=text_vecs.shape[1],
        instruction=PASSAGE_QUERY_INSTRUCTION,
    )[0]
    query_z, _ = coordinate_encoder.encode_query_vectors(
        passage_query_vector[None, :]
    )
    query_z = query_z[0]
    structure_key, structure = _ppr_structure(
        graph,
        text_vecs,
        z,
        synonym_threshold=synonym_threshold,
        synonym_top_k=synonym_top_k,
    )
    concept_ids = structure["concept_ids"]
    chunk_ids = structure["chunk_ids"]
    if not len(concept_ids) or not len(chunk_ids):
        return []

    signal_key = (
        query,
        structure_key,
        id(coordinate_encoder.query_spatial_weight)
        if coordinate_encoder.query_spatial_weight is not None
        else id(coordinate_encoder.spatial_weight),
        int(seed_count),
        int(prefilter),
        int(propagation_steps),
        float(reset_probability),
        float(passage_node_weight),
        bool(lorentz_edges),
        float(lorentz_edge_mix),
        float(lorentz_temperature),
        float(lorentz_path_mix),
        float(lorentz_path_temperature),
        tuple(
            (candidate.index, round(candidate.score * weight, 8))
            for candidate, weight in zip(
                recognized_facts or [], recognized_fact_weights or [], strict=True
            )
        ),
    )
    cached_signals = _PPR_SIGNAL_CACHE.get(signal_key)
    if cached_signals is not None:
        _PPR_SIGNAL_CACHE.move_to_end(signal_key)
        cached_chunk_ids, dense_signal, activation_signal, distance_signal = cached_signals
        scores = (
            dense_weight * dense_signal
            + activation_weight * activation_signal
            - lorentz_beta * distance_signal
        )
        order = np.argsort(-scores)[:top_k]
        return [int(cached_chunk_ids[position]) for position in order]

    seed_mass: dict[int, float]
    if recognized_facts is not None:
        fact_src_array = np.asarray(
            [candidate.src for candidate in recognized_facts], dtype=int
        )
        fact_dst_array = np.asarray(
            [candidate.dst for candidate in recognized_facts], dtype=int
        )
        fact_scores = np.asarray(
            [
                max(0.0, candidate.score) * weight
                for candidate, weight in zip(
                    recognized_facts, recognized_fact_weights or [], strict=True
                )
            ],
            dtype=np.float64,
        )
        fact_positions = np.arange(len(recognized_facts), dtype=int)
        recognized_seed_mass: dict[int, float] = defaultdict(float)
        seed_occurrences: dict[int, int] = defaultdict(int)
        mention_degree = structure["mention_degree"]
        for position, score in zip(fact_positions, fact_scores):
            for node_id in (int(fact_src_array[position]), int(fact_dst_array[position])):
                recognized_seed_mass[node_id] += float(score) / max(1, int(mention_degree[node_id]))
                seed_occurrences[node_id] += 1
        seed_mass = {
            node_id: score / seed_occurrences[node_id]
            for node_id, score in recognized_seed_mass.items()
        }
        seed_mass = dict(sorted(
            seed_mass.items(), key=lambda item: item[1], reverse=True
        )[:seed_count])
    else:
        node_similarities = text_vecs @ fact_query_vector
        fact_src_array = structure["fact_src"]
        fact_dst_array = structure["fact_dst"]
    if recognized_facts is None and len(fact_src_array):
        fact_scores = (
            node_similarities[fact_src_array] + node_similarities[fact_dst_array]
        ) / 2.0
        fact_count = min(seed_count, len(fact_scores))
        fact_positions = np.argpartition(-fact_scores, fact_count - 1)[:fact_count]
        fact_positions = fact_positions[np.argsort(-fact_scores[fact_positions])]
        unfiltered_seed_mass: dict[int, float] = defaultdict(float)
        mention_degree = structure["mention_degree"]
        selected_scores = fact_scores[fact_positions]
        selected_scores = selected_scores - float(selected_scores.min()) + 1e-6
        for position, score in zip(fact_positions, selected_scores):
            for node_id in (int(fact_src_array[position]), int(fact_dst_array[position])):
                unfiltered_seed_mass[node_id] += float(score) / max(1, int(mention_degree[node_id]))
        seed_mass = dict(unfiltered_seed_mass)
    elif recognized_facts is None:
        candidate_count = min(max(prefilter, seed_count), len(concept_ids))
        candidate_positions = np.argpartition(
            -node_similarities[concept_ids], candidate_count - 1,
        )[:candidate_count]
        ordered_candidates = candidate_positions[
            np.argsort(-node_similarities[concept_ids][candidate_positions])
        ]
        seed_mass = {
            int(concept_ids[position]): float(node_similarities[concept_ids[position]])
            for position in ordered_candidates[:seed_count]
        }
    reset = np.zeros(len(graph.nodes), dtype=np.float64)
    for node_id, score in seed_mass.items():
        reset[node_id] = max(0.0, score)

    passage_similarities = text_vecs[chunk_ids] @ passage_query_vector
    passage_min = float(passage_similarities.min())
    passage_range = float(passage_similarities.max()) - passage_min
    normalized_passage = (passage_similarities - passage_min) / max(passage_range, 1e-12)
    reset[chunk_ids] = normalized_passage * passage_node_weight
    reset /= max(float(reset.sum()), 1e-12)

    src, dst, transition_weights = _ppr_transitions(
        structure_key,
        structure,
        len(graph.nodes),
        lorentz_edges=lorentz_edges,
        lorentz_edge_mix=lorentz_edge_mix,
        lorentz_temperature=lorentz_temperature,
    )
    if len(src) and lorentz_path_mix > 0.0:
        query_source = lorentz_dist(query_z[None, :], z[src])
        query_target = lorentz_dist(query_z[None, :], z[dst])
        path_slack = np.maximum(
            0.0,
            query_source + structure["edge_distances"] - query_target,
        )
        coherence = np.exp(
            -np.clip(path_slack / lorentz_path_temperature, 0.0, 30.0)
        )
        path_weight = transition_weights * (
            (1.0 - lorentz_path_mix) + lorentz_path_mix * coherence
        )
        outgoing = np.zeros(len(graph.nodes), dtype=np.float64)
        np.add.at(outgoing, src, path_weight)
        transition_weights = path_weight / np.maximum(outgoing[src], 1e-12)
    if len(src):
        sparse_key = None
        if lorentz_path_mix == 0.0:
            sparse_key = (
                structure_key, bool(lorentz_edges), float(lorentz_edge_mix),
                float(lorentz_temperature), len(graph.nodes),
            )
        transition_matrix: Any = (
            _PPR_SPARSE_CACHE.get(sparse_key) if sparse_key is not None else None
        )
        if transition_matrix is None:
            try:
                from scipy.sparse import csr_matrix
                transition_matrix = csr_matrix(
                    (transition_weights, (dst, src)),
                    shape=(len(graph.nodes), len(graph.nodes)),
                )
                if sparse_key is not None:
                    _PPR_SPARSE_CACHE[sparse_key] = transition_matrix
            except ImportError:
                transition_matrix = None
        mass = reset.copy()
        for _ in range(propagation_steps):
            if transition_matrix is not None:
                propagated = np.asarray(transition_matrix @ mass).reshape(-1)
            else:
                propagated = np.zeros_like(mass)
                np.add.at(propagated, dst, mass[src] * transition_weights)
            mass = reset_probability * reset + (1.0 - reset_probability) * propagated
    else:
        mass = reset

    activation = mass[chunk_ids]
    query_batch = np.repeat(query_z[None, :], len(chunk_ids), axis=0)
    passage_distances = lorentz_dist(query_batch, z[chunk_ids])
    passage_activation = np.log1p(activation)

    def standardize(values: np.ndarray) -> np.ndarray:
        std = float(values.std())
        return (values - float(values.mean())) / (std if std > 1e-9 else 1.0)

    dense_signal = standardize(passage_similarities)
    activation_signal = standardize(passage_activation)
    distance_signal = standardize(passage_distances)
    _PPR_SIGNAL_CACHE[signal_key] = (
        chunk_ids,
        dense_signal,
        activation_signal,
        distance_signal,
    )
    _PPR_SIGNAL_CACHE.move_to_end(signal_key)
    while len(_PPR_SIGNAL_CACHE) > _PPR_SIGNAL_CACHE_LIMIT:
        _PPR_SIGNAL_CACHE.popitem(last=False)
    scores = (
        dense_weight * dense_signal
        + activation_weight * activation_signal
        - lorentz_beta * distance_signal
    )
    order = np.argsort(-scores)[:top_k]
    return [int(chunk_ids[position]) for position in order]


def loci_text(graph: Graph, picked: list[tuple[int, str]], chunk_ids: list[int]) -> str:
    """Serialize a retrieved subgraph as role-tagged structured text."""
    by_role: dict[str, list[str]] = defaultdict(list)
    for node_id, role in picked:
        by_role[role].append(graph.nodes[node_id].name)

    lines: list[str] = []
    for role, label in (
        ("ancestor", "Parent"),
        ("seed", "Focus"),
        ("sibling", "Siblings - comparing"),
        ("associate", "Direct associations"),
        ("bridge", "Multi-hop bridges"),
        ("counter", "Alternatives / conflicts"),
        ("context", "Related context"),
    ):
        if role in by_role:
            lines.append(f"[{label}] " + ", ".join(sorted(set(by_role[role]))))

    selected = {node_id for node_id, _ in picked}
    dependency_lines: set[str] = set()
    for edge in graph.edges:
        if edge.etype not in DEPENDENCY or edge.src not in selected or edge.dst not in selected:
            continue
        source = graph.nodes[edge.src].name
        target = graph.nodes[edge.dst].name
        if edge.etype == "requires":
            dependency_lines.add(f"  {target} REQUIRES {source}")
        else:
            dependency_lines.add(f"  {source} {edge.etype.upper()} {target}")
    if dependency_lines:
        lines.append("[Constraint path]")
        lines.extend(sorted(dependency_lines))

    if chunk_ids:
        lines.append("[Evidence]")
        for chunk_id in chunk_ids:
            node = graph.nodes[chunk_id]
            lines.append(f"  ({node.provenance}) {node.text[:400]}")
    lines.append(
        "[Instruction] Answer using only the structured context above. "
        "Do not assert a requires/causes/prevents/limits relationship unless "
        "it appears in the context."
    )
    return "\n".join(lines)
