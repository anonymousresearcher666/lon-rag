"""Pure-NumPy optimizer for the CLM prototype objective."""

from __future__ import annotations

import numpy as np

from .encoder import initialize_projection
from .geometry import dist_grads, radial, radial_grad


DEFAULT_WEIGHTS = {
    "text": 1.0,
    "kg": 1.0,
    "hierarchy": 0.5,
    "sibling": 0.3,
    "evidence": 0.5,
    "retrieval": 0.7,
    "causal": 1.0,
    "spacelike": 0.8,
    "negative": 0.8,
    "repulse": 0.1,
}


class Adam:
    def __init__(self, shape, lr=0.02, b1=0.9, b2=0.999, eps=1e-8):
        self.m = np.zeros(shape)
        self.v = np.zeros(shape)
        self.lr, self.b1, self.b2, self.eps, self.t = lr, b1, b2, eps, 0

    def step(self, gradient):
        self.t += 1
        self.m = self.b1 * self.m + (1 - self.b1) * gradient
        self.v = self.b2 * self.v + (1 - self.b2) * gradient * gradient
        corrected_m = self.m / (1 - self.b1 ** self.t)
        corrected_v = self.v / (1 - self.b2 ** self.t)
        return -self.lr * corrected_m / (np.sqrt(corrected_v) + self.eps)


def _pairs(values):
    array = np.asarray(values, dtype=int)
    if len(array):
        return array[:, 0], array[:, 1]
    return np.zeros(0, dtype=int), np.zeros(0, dtype=int)


def _accumulate(gz, gt, a, b, ga, gb, ta=None, tb=None):
    np.add.at(gz, a, ga)
    np.add.at(gz, b, gb)
    if ta is not None:
        np.add.at(gt, a, ta)
        np.add.at(gt, b, tb)


def train(
    n_nodes,
    dep_edges,
    opp_edges,
    tax_edges,
    attract_edges,
    dim=8,
    steps=3000,
    margin=0.2,
    seed=13,
    lr=0.02,
    w=None,
    d_att=1.2,
    d_rep=2.0,
    n_neg=4,
    callback=None,
    *,
    text_vectors=None,
    kg_edges=None,
    sibling_edges=None,
    evidence_edges=None,
    retrieval_edges=None,
    retrieval_query_vectors=None,
    retrieval_query_edges=None,
    retrieval_query_negative_edges=None,
    retrieval_candidate_ids=None,
    negative_edges=None,
    encoder_init=None,
    return_encoder=False,
    initial_z=None,
    initial_tau=None,
    trainable_mask=None,
):
    """Train node events and, when text vectors are supplied, shared text heads.

    The edge convention is dependency ``(prerequisite, dependent)`` and
    taxonomy ``(child, parent)``. The optional edge groups implement the paper's
    text, KG, hierarchy, sibling, evidence, retrieval, causal, and spacelike
    objective terms.
    """
    if n_nodes <= 0 or steps <= 0:
        raise ValueError("n_nodes and steps must be positive")
    weights = {**DEFAULT_WEIGHTS, **(w or {})}
    rng = np.random.default_rng(seed)

    spatial_weight: np.ndarray | None = None
    temporal_weight: np.ndarray | None = None
    x = None if text_vectors is None else np.asarray(text_vectors, dtype=np.float64)
    if x is not None and (x.ndim != 2 or x.shape[0] != n_nodes):
        raise ValueError("text_vectors must have shape (n_nodes, text_dim)")
    if x is not None:
        if encoder_init is None:
            spatial_weight, temporal_weight = initialize_projection(x, dim, seed)
        else:
            spatial_weight = np.asarray(encoder_init["spatial_weight"], dtype=np.float64).copy()
            temporal_weight = np.asarray(encoder_init["temporal_weight"], dtype=np.float64).copy()
        z = (
            np.asarray(initial_z, dtype=np.float64).copy()
            if initial_z is not None
            else x @ spatial_weight + 0.01 * rng.standard_normal((n_nodes, dim))
        )
        tau = (
            np.asarray(initial_tau, dtype=np.float64).copy()
            if initial_tau is not None
            else x @ temporal_weight + 0.1 * rng.standard_normal(n_nodes)
        )
        opt_spatial = Adam(spatial_weight.shape, lr=lr)
        opt_temporal = Adam(temporal_weight.shape, lr=lr)
    else:
        z = (
            np.asarray(initial_z, dtype=np.float64).copy()
            if initial_z is not None
            else 0.1 * rng.standard_normal((n_nodes, dim))
        )
        tau = (
            np.asarray(initial_tau, dtype=np.float64).copy()
            if initial_tau is not None
            else 0.1 * rng.standard_normal(n_nodes)
        )

    if z.shape != (n_nodes, dim) or tau.shape != (n_nodes,):
        raise ValueError("initial coordinates do not match n_nodes and dim")
    mask = np.ones(n_nodes, dtype=bool) if trainable_mask is None else np.asarray(trainable_mask, dtype=bool)
    if mask.shape != (n_nodes,):
        raise ValueError("trainable_mask must have shape (n_nodes,)")

    opt_z, opt_tau = Adam(z.shape, lr=lr), Adam(tau.shape, lr=lr)
    dep_a, dep_b = _pairs(dep_edges)
    opp_a, opp_b = _pairs(opp_edges)
    tax_child, tax_parent = _pairs(tax_edges)
    kg_a, kg_b = _pairs(attract_edges if kg_edges is None else kg_edges)
    sibling_a, sibling_b = _pairs(sibling_edges or [])
    evidence_a, evidence_b = _pairs(evidence_edges or [])
    retrieval_a, retrieval_b = _pairs(retrieval_edges or [])
    retrieval_queries = (
        None if retrieval_query_vectors is None
        else np.asarray(retrieval_query_vectors, dtype=np.float64)
    )
    query_a, query_positive = _pairs(retrieval_query_edges or [])
    negative_query, negative_node = _pairs(retrieval_query_negative_edges or [])
    if retrieval_queries is not None:
        if x is None:
            raise ValueError("retrieval query supervision requires text_vectors")
        if retrieval_queries.ndim != 2 or retrieval_queries.shape[1] != x.shape[1]:
            raise ValueError(
                "retrieval_query_vectors must have shape (queries, text_dim)"
            )
        if len(query_a) and int(query_a.max()) >= len(retrieval_queries):
            raise ValueError("retrieval query edge references an unknown query")
        if len(query_positive) and int(query_positive.max()) >= n_nodes:
            raise ValueError("retrieval query edge references an unknown node")
    elif len(query_a):
        raise ValueError("retrieval_query_edges require retrieval_query_vectors")
    if len(negative_query):
        if retrieval_queries is None:
            raise ValueError(
                "retrieval_query_negative_edges require retrieval_query_vectors"
            )
        if int(negative_query.max()) >= len(retrieval_queries):
            raise ValueError("retrieval negative edge references an unknown query")
        if int(negative_node.max()) >= n_nodes:
            raise ValueError("retrieval negative edge references an unknown node")
    negative_options: dict[int, list[int]] = {}
    for query_id, node_id in zip(negative_query.tolist(), negative_node.tolist()):
        negative_options.setdefault(query_id, []).append(node_id)
    retrieval_candidates = np.asarray(
        list(range(n_nodes)) if retrieval_candidate_ids is None
        else retrieval_candidate_ids,
        dtype=int,
    )
    if len(query_a) and not len(retrieval_candidates):
        raise ValueError("retrieval_candidate_ids must not be empty")
    if len(retrieval_candidates) and (
        int(retrieval_candidates.min()) < 0
        or int(retrieval_candidates.max()) >= n_nodes
    ):
        raise ValueError("retrieval_candidate_ids contain an unknown node")
    hard_negative_a, hard_negative_b = _pairs(negative_edges or [])
    history = []

    def attraction_loss(gz, gt, a, b, threshold, weight):
        if not len(a) or weight == 0:
            return 0.0
        distance, grad_a, grad_b = dist_grads(z[a], z[b])
        active = (distance > threshold).astype(float) * weight
        _accumulate(gz, gt, a, b, active[:, None] * grad_a, active[:, None] * grad_b)
        return float(weight * np.maximum(distance - threshold, 0).sum())

    for step in range(steps):
        gz = np.zeros_like(z)
        gt = np.zeros_like(tau)
        grad_spatial = None if x is None else np.zeros_like(spatial_weight)
        grad_temporal = None if x is None else np.zeros_like(temporal_weight)
        loss = 0.0

        if x is not None and weights["text"]:
            predicted_z = x @ spatial_weight
            predicted_tau = x @ temporal_weight
            spatial_error = z - predicted_z
            temporal_error = tau - predicted_tau
            scale = weights["text"] / n_nodes
            loss += 0.5 * scale * (
                np.sum(spatial_error * spatial_error)
                + np.sum(temporal_error * temporal_error)
            )
            gz += scale * spatial_error
            gt += scale * temporal_error
            grad_spatial -= scale * x.T @ spatial_error
            grad_temporal -= scale * x.T @ temporal_error

        if len(dep_a):
            distance, grad_a, grad_b = dist_grads(z[dep_a], z[dep_b])
            hinge = margin + distance - (tau[dep_b] - tau[dep_a])
            active = (hinge > 0).astype(float) * weights["causal"]
            loss += weights["causal"] * np.maximum(hinge, 0).sum()
            _accumulate(
                gz, gt, dep_a, dep_b,
                active[:, None] * grad_a,
                active[:, None] * grad_b,
                active,
                -active,
            )

        if len(opp_a):
            distance, grad_a, grad_b = dist_grads(z[opp_a], z[opp_b])
            delta_tau = tau[opp_a] - tau[opp_b]
            hinge = margin - (distance - np.abs(delta_tau))
            active = (hinge > 0).astype(float) * weights["spacelike"]
            loss += weights["spacelike"] * np.maximum(hinge, 0).sum()
            sign = np.sign(delta_tau)
            _accumulate(
                gz, gt, opp_a, opp_b,
                -active[:, None] * grad_a,
                -active[:, None] * grad_b,
                active * sign,
                -active * sign,
            )

        if len(hard_negative_a):
            distance, grad_a, grad_b = dist_grads(
                z[hard_negative_a], z[hard_negative_b]
            )
            delta_tau = tau[hard_negative_a] - tau[hard_negative_b]
            hinge = margin - (distance - np.abs(delta_tau))
            active = (hinge > 0).astype(float) * weights["negative"]
            loss += weights["negative"] * np.maximum(hinge, 0).sum()
            sign = np.sign(delta_tau)
            _accumulate(
                gz, gt, hard_negative_a, hard_negative_b,
                -active[:, None] * grad_a,
                -active[:, None] * grad_b,
                active * sign,
                -active * sign,
            )

        if len(tax_child):
            child_radius = radial(z[tax_child])
            parent_radius = radial(z[tax_parent])
            hinge = 0.5 * margin + parent_radius - child_radius
            active = (hinge > 0).astype(float) * weights["hierarchy"]
            loss += weights["hierarchy"] * np.maximum(hinge, 0).sum()
            np.add.at(gz, tax_child, -active[:, None] * radial_grad(z[tax_child]))
            np.add.at(gz, tax_parent, active[:, None] * radial_grad(z[tax_parent]))

        loss += attraction_loss(gz, gt, kg_a, kg_b, d_att, weights["kg"])
        loss += attraction_loss(gz, gt, sibling_a, sibling_b, 0.8, weights["sibling"])
        loss += attraction_loss(gz, gt, evidence_a, evidence_b, 0.7, weights["evidence"])

        if len(retrieval_a) and n_nodes > 2:
            negative = rng.integers(0, n_nodes, len(retrieval_a))
            invalid = (negative == retrieval_a) | (negative == retrieval_b)
            while np.any(invalid):
                negative[invalid] = rng.integers(0, n_nodes, int(np.sum(invalid)))
                invalid = (negative == retrieval_a) | (negative == retrieval_b)
            positive_d, pos_ga, pos_gb = dist_grads(z[retrieval_a], z[retrieval_b])
            negative_d, neg_ga, neg_gb = dist_grads(z[retrieval_a], z[negative])
            hinge = margin + positive_d - negative_d
            active = (hinge > 0).astype(float) * weights["retrieval"]
            loss += weights["retrieval"] * np.maximum(hinge, 0).sum()
            np.add.at(gz, retrieval_a, active[:, None] * (pos_ga - neg_ga))
            np.add.at(gz, retrieval_b, active[:, None] * pos_gb)
            np.add.at(gz, negative, -active[:, None] * neg_gb)

        if len(query_a) and len(retrieval_candidates) > 1:
            assert retrieval_queries is not None
            assert spatial_weight is not None
            assert grad_spatial is not None
            negative = rng.choice(retrieval_candidates, size=len(query_a))
            for position, query_id in enumerate(query_a.tolist()):
                options = negative_options.get(query_id)
                if options:
                    negative[position] = options[step % len(options)]
            invalid = negative == query_positive
            while np.any(invalid):
                negative[invalid] = rng.choice(
                    retrieval_candidates, size=int(np.sum(invalid))
                )
                invalid = negative == query_positive
            query_x = retrieval_queries[query_a]
            query_z = query_x @ spatial_weight
            positive_d, query_pos_grad, positive_grad = dist_grads(
                query_z, z[query_positive]
            )
            negative_d, query_neg_grad, negative_grad = dist_grads(
                query_z, z[negative]
            )
            hinge = margin + positive_d - negative_d
            active = (hinge > 0).astype(float) * weights["retrieval"]
            loss += weights["retrieval"] * np.maximum(hinge, 0).sum()
            query_grad = active[:, None] * (
                query_pos_grad - query_neg_grad
            )
            grad_spatial += query_x.T @ query_grad
            np.add.at(
                gz, query_positive, active[:, None] * positive_grad
            )
            np.add.at(
                gz, negative, -active[:, None] * negative_grad
            )

        negative_a = rng.integers(0, n_nodes, n_neg * max(len(dep_a), 32))
        negative_b = rng.integers(0, n_nodes, len(negative_a))
        keep = negative_a != negative_b
        negative_a, negative_b = negative_a[keep], negative_b[keep]
        distance, grad_a, grad_b = dist_grads(z[negative_a], z[negative_b])
        active = (distance < d_rep).astype(float) * weights["repulse"]
        loss += weights["repulse"] * np.maximum(d_rep - distance, 0).sum()
        _accumulate(
            gz, gt, negative_a, negative_b,
            -active[:, None] * grad_a,
            -active[:, None] * grad_b,
        )

        gz[~mask] = 0.0
        gt[~mask] = 0.0
        z += opt_z.step(gz)
        tau += opt_tau.step(gt)
        if x is not None:
            assert spatial_weight is not None and temporal_weight is not None
            assert grad_spatial is not None and grad_temporal is not None
            spatial_weight += opt_spatial.step(grad_spatial)
            temporal_weight += opt_temporal.step(grad_temporal)
        if step % 50 == 0 or step == steps - 1:
            history.append((step, float(loss)))
            if callback:
                callback(step, steps, float(loss))

    result = (z, tau, history)
    if return_encoder:
        if spatial_weight is None:
            raise ValueError("return_encoder requires text_vectors")
        return (*result, {
            "spatial_weight": spatial_weight,
            "temporal_weight": temporal_weight,
        })
    return result
