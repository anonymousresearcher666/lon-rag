"""Numerical adapters for LoCI-Prefix and LoCI-Attention ablations."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .geometry import lift, lorentz_dist


def event_features(tau: np.ndarray, z: np.ndarray, node_ids: list[int]) -> np.ndarray:
    """Return event features ``[tau, x0, x1, ...]`` for selected nodes."""
    ids = np.asarray(node_ids, dtype=int)
    if len(ids) == 0:
        return np.zeros((0, z.shape[1] + 2), dtype=np.float64)
    return np.concatenate((tau[ids, None], lift(z[ids])), axis=1)


@dataclass
class LoCIPrefixProjector:
    """Project CLM events into a fixed-length generator prefix matrix."""

    weight: np.ndarray
    bias: np.ndarray

    @classmethod
    def initialize(cls, event_dim: int, target_dim: int, seed: int = 13):
        rng = np.random.default_rng(seed)
        weight = rng.normal(
            scale=1.0 / np.sqrt(event_dim), size=(event_dim, target_dim)
        )
        return cls(weight, np.zeros(target_dim, dtype=np.float64))

    @classmethod
    def fit(
        cls,
        events: np.ndarray,
        target_embeddings: np.ndarray,
        ridge: float = 1e-4,
    ):
        """Fit a ridge projection when generator-side target vectors exist."""
        x = np.asarray(events, dtype=np.float64)
        y = np.asarray(target_embeddings, dtype=np.float64)
        if x.ndim != 2 or y.ndim != 2 or len(x) != len(y):
            raise ValueError("events and target_embeddings must be aligned matrices")
        augmented = np.concatenate((x, np.ones((len(x), 1))), axis=1)
        gram = augmented.T @ augmented + ridge * np.eye(augmented.shape[1])
        parameters = np.linalg.solve(gram, augmented.T @ y)
        return cls(parameters[:-1], parameters[-1])

    def transform(
        self,
        events: np.ndarray,
        *,
        prefix_length: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return padded prefix vectors and a boolean valid-token mask."""
        if prefix_length <= 0:
            raise ValueError("prefix_length must be positive")
        values = np.tanh(np.asarray(events, dtype=np.float64) @ self.weight + self.bias)
        prefix = np.zeros((prefix_length, self.weight.shape[1]), dtype=np.float64)
        count = min(prefix_length, len(values))
        prefix[:count] = values[:count]
        mask = np.zeros(prefix_length, dtype=bool)
        mask[:count] = True
        return prefix, mask


def loci_attention_bias(
    query_tau: float,
    query_z: np.ndarray,
    node_tau: np.ndarray,
    node_z: np.ndarray,
    *,
    spatial_weight: float = 1.0,
    causal_weight: float = 0.25,
) -> np.ndarray:
    """Compute a query-to-memory cross-attention bias from CLM geometry."""
    if len(node_z) == 0:
        return np.zeros(0, dtype=np.float64)
    query_batch = np.repeat(np.asarray(query_z)[None, :], len(node_z), axis=0)
    distance = lorentz_dist(query_batch, np.asarray(node_z))
    delta_tau = np.asarray(node_tau) - float(query_tau)
    interval = -(delta_tau * delta_tau) + distance * distance
    timelike_bonus = np.sqrt(np.maximum(-interval, 0.0))
    return -spatial_weight * distance + causal_weight * timelike_bonus
