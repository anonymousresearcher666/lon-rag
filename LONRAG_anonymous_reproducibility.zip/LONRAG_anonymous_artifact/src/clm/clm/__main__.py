"""CLI:  python -m clm build <docs_dir> [--out INDEX] [--extractor rules|llm]
        python -m clm ask "<question>" [--index INDEX] [--provider ...]
        python -m clm gui [--port 7860]
"""

import argparse
import json
import sys

from .pipeline import Memory


def main():
    ap = argparse.ArgumentParser(prog="clm")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build")
    b.add_argument("docs_dir")
    b.add_argument("--out", default="clm_index")
    b.add_argument("--extractor", default="rules", choices=["rules", "llm"])
    b.add_argument("--steps", type=int, default=2500)
    b.add_argument("--dim", type=int, default=8)
    b.add_argument("--margin", type=float, default=0.2)
    b.add_argument("--training-backend", choices=["numpy", "torch"])
    b.add_argument("--vector-backend",
                   choices=["auto", "numpy", "faiss", "hnswlib", "qdrant"])
    b.add_argument("--text-encoder", default="hashed",
                   choices=[
                       "hashed", "sentence-transformers", "ollama", "nv-embed-v2",
                   ])
    b.add_argument("--text-model", default="all-MiniLM-L6-v2")
    b.add_argument("--max-chars", type=int, default=900)
    b.add_argument("--overlap", type=int, default=120)
    b.add_argument(
        "--retrieval-supervision",
        help="JSON/JSONL question-to-positive-chunk supervision for L_retrieval",
    )

    r = sub.add_parser("retrain")
    r.add_argument("--index", required=True, help="Existing validated CLM index")
    r.add_argument("--out", required=True, help="Destination for the retrained index")
    r.add_argument(
        "--retrieval-supervision",
        required=True,
        help="JSON/JSONL question-to-positive-chunk supervision for L_retrieval",
    )
    r.add_argument("--steps", type=int, default=None)
    r.add_argument("--seed", type=int, default=None)

    a = sub.add_parser("ask")
    a.add_argument("question")
    a.add_argument("--index", default="clm_index")
    a.add_argument("--provider", choices=["openai", "ollama", "offline"])

    c = sub.add_parser("calibrate")
    c.add_argument("data", help="JSONL file of labeled directional claims")
    c.add_argument("--index", default="clm_index")
    c.add_argument("--out", default=None)
    c.add_argument("--alpha", type=float, default=0.1)

    i = sub.add_parser("add")
    i.add_argument("docs_dir")
    i.add_argument("--index", default="clm_index")
    i.add_argument("--out", default=None)
    i.add_argument("--extractor", default="rules", choices=["rules", "llm"])
    i.add_argument("--steps", type=int, default=200)

    e = sub.add_parser("benchmark")
    e.add_argument("data", help="JSONL benchmark dataset")
    e.add_argument("--index", default="clm_index")
    e.add_argument("--modes", default=",".join((
        "full", "no_geometry", "no_roles", "text_only",
        "flat_conditioning", "no_verification",
    )))
    e.add_argument("--output", default="benchmark.csv")
    e.add_argument("--generate", action="store_true")
    e.add_argument("--provider", choices=["openai", "ollama", "offline"])

    g = sub.add_parser("gui")
    g.add_argument("--port", type=int, default=7860)

    args = ap.parse_args()

    if args.cmd == "build":
        m = Memory(
            dim=args.dim,
            steps=args.steps,
            margin=args.margin,
            training_backend=args.training_backend,
            vector_backend=args.vector_backend,
            text_encoder=args.text_encoder,
            text_model=args.text_model,
        )
        stats = m.build(args.docs_dir, extractor=args.extractor,
                        max_chars=args.max_chars, overlap=args.overlap,
                        retrieval_supervision=args.retrieval_supervision,
                        progress=lambda s, f: print(f"\r[{f:5.0%}] {s:<50}",
                                                    end="", flush=True))
        print()
        m.save(args.out)
        print(json.dumps(stats, indent=2))
    elif args.cmd == "retrain":
        m = Memory.load(args.index)
        stats = m.retrain_geometry(
            args.retrieval_supervision,
            steps=args.steps,
            seed=args.seed,
            progress=lambda s, f: print(
                f"\r[{f:5.0%}] {s:<50}", end="", flush=True
            ),
        )
        print()
        m.save(args.out)
        print(json.dumps(stats, indent=2))
    elif args.cmd == "ask":
        m = Memory.load(args.index)
        out = m.ask(args.question, provider=args.provider)
        print(f"\n=== ANSWER (provider: {out['provider']}) ===\n{out['answer']}")
        print("\n=== VERIFICATION ===")
        for c in out["verification"]:
            print(f"  [{c['verdict'].upper():11s}] {c['claim']}"
                  + (f"  (slack {c['ccc_slack']}, GAD {c['gad']})"
                     if "ccc_slack" in c else f"  ({c.get('reason','')})"))
        print(f"\nlatency: {out['latency']}")
    elif args.cmd == "calibrate":
        m = Memory.load(args.index)
        calibration = m.calibrate(args.data, alpha=args.alpha)
        m.save(args.out or args.index)
        print(json.dumps(calibration.to_dict(), indent=2))
    elif args.cmd == "add":
        m = Memory.load(args.index)
        update = m.add_documents(
            args.docs_dir,
            extractor=args.extractor,
            refinement_steps=args.steps,
            progress=lambda s, f: print(f"\r[{f:5.0%}] {s:<50}", end="", flush=True),
        )
        print()
        m.save(args.out or args.index)
        print(json.dumps(update, indent=2))
    elif args.cmd == "benchmark":
        from .benchmark import run_benchmark, write_report
        m = Memory.load(args.index)
        modes = [value.strip() for value in args.modes.split(",") if value.strip()]
        records, summary = run_benchmark(
            m,
            args.data,
            modes=modes,
            generate=args.generate,
            provider=args.provider,
        )
        write_report(args.output, records)
        print(json.dumps(summary, indent=2))
    elif args.cmd == "gui":
        from .server import serve
        serve(args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
