"""Lorentz-model geometry for Causal Lorentzian Memory."""
import numpy as np
EPS = 1e-9

def lift(z):
    x0=np.sqrt(1.0+np.sum(z*z,axis=-1,keepdims=True)); return np.concatenate([x0,z],axis=-1)

def minkowski_dot(x,y): return -x[...,0]*y[...,0]+np.sum(x[...,1:]*y[...,1:],axis=-1)

def lorentz_dist(za,zb):
    xa,xb=lift(za),lift(zb); u=np.clip(-minkowski_dot(xa,xb),1.0+EPS,None); return np.arccosh(u)

def dist_grads(za,zb):
    xa0=np.sqrt(1.0+np.sum(za*za,axis=-1,keepdims=True)); xb0=np.sqrt(1.0+np.sum(zb*zb,axis=-1,keepdims=True)); u=(xa0*xb0).squeeze(-1)-np.sum(za*zb,axis=-1); u=np.clip(u,1.0+EPS,None); d=np.arccosh(u); dd=1.0/np.sqrt(u*u-1.0); ga=dd[:,None]*((za/xa0)*xb0-zb); gb=dd[:,None]*((zb/xb0)*xa0-za); return d,ga,gb

def radial(z):
    x0=np.sqrt(1.0+np.sum(z*z,axis=-1)); return np.arccosh(np.clip(x0,1.0+EPS,None))

def radial_grad(z):
    x0=np.sqrt(1.0+np.sum(z*z,axis=-1,keepdims=True)); denom=np.sqrt(np.clip(x0*x0-1.0,EPS,None)); return (z/x0)/denom

def interval(tau_a,za,tau_b,zb):
    d=lorentz_dist(za,zb); return -(tau_a-tau_b)**2+d*d
