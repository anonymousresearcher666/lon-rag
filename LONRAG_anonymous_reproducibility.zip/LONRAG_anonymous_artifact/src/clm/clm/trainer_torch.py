"""PyTorch/autograd optimizer for the full CLM prototype objective."""

from __future__ import annotations

from typing import Any

import numpy as np

from .encoder import initialize_projection
from .trainer_numpy import DEFAULT_WEIGHTS


def train(
    n_nodes,
    dep_edges,
    opp_edges,
    tax_edges,
    attract_edges,
    dim=8,
    steps=3000,
    margin=0.2,
    seed=13,
    lr=0.02,
    w=None,
    d_att=1.2,
    d_rep=2.0,
    n_neg=4,
    callback=None,
    device=None,
    *,
    text_vectors=None,
    kg_edges=None,
    sibling_edges=None,
    evidence_edges=None,
    retrieval_edges=None,
    retrieval_query_vectors=None,
    retrieval_query_edges=None,
    retrieval_query_negative_edges=None,
    retrieval_candidate_ids=None,
    negative_edges=None,
    encoder_init=None,
    return_encoder=False,
    initial_z=None,
    initial_tau=None,
    trainable_mask=None,
):
    import torch

    if n_nodes <= 0 or steps <= 0:
        raise ValueError("n_nodes and steps must be positive")
    weights = {**DEFAULT_WEIGHTS, **(w or {})}
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    def pairs(values):
        tensor = torch.as_tensor(values, dtype=torch.long, device=dev)
        return tensor if tensor.numel() else torch.zeros((0, 2), dtype=torch.long, device=dev)

    x = None
    parameters: list[Any] = []
    spatial_weight: Any = None
    temporal_weight: Any = None
    if text_vectors is not None:
        values = np.asarray(text_vectors, dtype=np.float64)
        if values.ndim != 2 or values.shape[0] != n_nodes:
            raise ValueError("text_vectors must have shape (n_nodes, text_dim)")
        x = torch.as_tensor(values, dtype=torch.float64, device=dev)
        if encoder_init is None:
            initial_spatial, initial_temporal = initialize_projection(values, dim, seed)
        else:
            initial_spatial = np.asarray(encoder_init["spatial_weight"])
            initial_temporal = np.asarray(encoder_init["temporal_weight"])
        spatial_weight = torch.as_tensor(
            initial_spatial, dtype=torch.float64, device=dev
        ).clone().requires_grad_(True)
        temporal_weight = torch.as_tensor(
            initial_temporal, dtype=torch.float64, device=dev
        ).clone().requires_grad_(True)
        initial_z_values = (
            torch.as_tensor(initial_z, dtype=torch.float64, device=dev)
            if initial_z is not None
            else x @ spatial_weight + 0.01 * torch.randn(
                n_nodes, dim, dtype=torch.float64, device=dev
            )
        )
        initial_tau_values = (
            torch.as_tensor(initial_tau, dtype=torch.float64, device=dev)
            if initial_tau is not None
            else x @ temporal_weight + 0.1 * torch.randn(
                n_nodes, dtype=torch.float64, device=dev
            )
        )
        z = initial_z_values.detach().clone().requires_grad_(True)
        tau = initial_tau_values.detach().clone().requires_grad_(True)
        parameters.extend((spatial_weight, temporal_weight))
    else:
        z = (
            torch.as_tensor(initial_z, dtype=torch.float64, device=dev).clone()
            if initial_z is not None
            else 0.1 * torch.randn(n_nodes, dim, dtype=torch.float64, device=dev)
        ).requires_grad_(True)
        tau = (
            torch.as_tensor(initial_tau, dtype=torch.float64, device=dev).clone()
            if initial_tau is not None
            else 0.1 * torch.randn(n_nodes, dtype=torch.float64, device=dev)
        ).requires_grad_(True)
    if z.shape != (n_nodes, dim) or tau.shape != (n_nodes,):
        raise ValueError("initial coordinates do not match n_nodes and dim")
    mask = torch.ones(n_nodes, dtype=torch.bool, device=dev) if trainable_mask is None else torch.as_tensor(
        trainable_mask, dtype=torch.bool, device=dev
    )
    if mask.shape != (n_nodes,):
        raise ValueError("trainable_mask must have shape (n_nodes,)")
    parameters.extend((z, tau))
    optimizer = torch.optim.Adam(parameters, lr=lr)

    dep = pairs(dep_edges)
    opp = pairs(opp_edges)
    tax = pairs(tax_edges)
    kg = pairs(attract_edges if kg_edges is None else kg_edges)
    sibling = pairs(sibling_edges or [])
    evidence = pairs(evidence_edges or [])
    retrieval = pairs(retrieval_edges or [])
    retrieval_queries: Any = None
    if retrieval_query_vectors is not None:
        values = np.asarray(retrieval_query_vectors, dtype=np.float64)
        if x is None:
            raise ValueError("retrieval query supervision requires text_vectors")
        if values.ndim != 2 or values.shape[1] != x.shape[1]:
            raise ValueError(
                "retrieval_query_vectors must have shape (queries, text_dim)"
            )
        retrieval_queries = torch.as_tensor(values, dtype=torch.float64, device=dev)
    query_retrieval = pairs(retrieval_query_edges or [])
    query_negative = pairs(retrieval_query_negative_edges or [])
    if query_retrieval.shape[0] and retrieval_queries is None:
        raise ValueError("retrieval_query_edges require retrieval_query_vectors")
    if query_retrieval.shape[0]:
        if int(query_retrieval[:, 0].max()) >= retrieval_queries.shape[0]:
            raise ValueError("retrieval query edge references an unknown query")
        if int(query_retrieval[:, 1].max()) >= n_nodes:
            raise ValueError("retrieval query edge references an unknown node")
    if query_negative.shape[0]:
        if retrieval_queries is None:
            raise ValueError(
                "retrieval_query_negative_edges require retrieval_query_vectors"
            )
        if int(query_negative[:, 0].max()) >= retrieval_queries.shape[0]:
            raise ValueError("retrieval negative edge references an unknown query")
        if int(query_negative[:, 1].max()) >= n_nodes:
            raise ValueError("retrieval negative edge references an unknown node")
    negative_options: dict[int, list[int]] = {}
    for query_id, node_id in query_negative.detach().cpu().tolist():
        negative_options.setdefault(query_id, []).append(node_id)
    candidate_values = (
        list(range(n_nodes)) if retrieval_candidate_ids is None
        else retrieval_candidate_ids
    )
    retrieval_candidates = torch.as_tensor(
        candidate_values, dtype=torch.long, device=dev
    )
    if query_retrieval.shape[0] and not retrieval_candidates.numel():
        raise ValueError("retrieval_candidate_ids must not be empty")
    if retrieval_candidates.numel() and (
        int(retrieval_candidates.min()) < 0
        or int(retrieval_candidates.max()) >= n_nodes
    ):
        raise ValueError("retrieval_candidate_ids contain an unknown node")
    hard_negative = pairs(negative_edges or [])

    def distance(za, zb):
        x0a = torch.sqrt(1 + (za * za).sum(-1))
        x0b = torch.sqrt(1 + (zb * zb).sum(-1))
        inner = torch.clamp(x0a * x0b - (za * zb).sum(-1), min=1 + 1e-9)
        return torch.acosh(inner)

    def radius(values):
        norm = torch.sqrt(1 + (values * values).sum(-1))
        return torch.acosh(torch.clamp(norm, min=1 + 1e-9))

    def attraction(edge_tensor, threshold, weight):
        if edge_tensor.shape[0] == 0 or weight == 0:
            return z.sum() * 0
        d = distance(z[edge_tensor[:, 0]], z[edge_tensor[:, 1]])
        return weight * torch.clamp(d - threshold, min=0).sum()

    history = []
    for step in range(steps):
        optimizer.zero_grad()
        loss = z.sum() * 0
        if x is not None and weights["text"]:
            loss = loss + 0.5 * weights["text"] * (
                ((z - x @ spatial_weight) ** 2).sum()
                + ((tau - x @ temporal_weight) ** 2).sum()
            ) / n_nodes
        if dep.shape[0]:
            d = distance(z[dep[:, 0]], z[dep[:, 1]])
            loss = loss + weights["causal"] * torch.clamp(
                margin + d - (tau[dep[:, 1]] - tau[dep[:, 0]]), min=0
            ).sum()
        if opp.shape[0]:
            d = distance(z[opp[:, 0]], z[opp[:, 1]])
            delta_tau = (tau[opp[:, 0]] - tau[opp[:, 1]]).abs()
            loss = loss + weights["spacelike"] * torch.clamp(
                margin - (d - delta_tau), min=0
            ).sum()
        if hard_negative.shape[0]:
            d = distance(z[hard_negative[:, 0]], z[hard_negative[:, 1]])
            delta_tau = (
                tau[hard_negative[:, 0]] - tau[hard_negative[:, 1]]
            ).abs()
            loss = loss + weights["negative"] * torch.clamp(
                margin - (d - delta_tau), min=0
            ).sum()
        if tax.shape[0]:
            loss = loss + weights["hierarchy"] * torch.clamp(
                0.5 * margin + radius(z[tax[:, 1]]) - radius(z[tax[:, 0]]), min=0
            ).sum()
        loss = loss + attraction(kg, d_att, weights["kg"])
        loss = loss + attraction(sibling, 0.8, weights["sibling"])
        loss = loss + attraction(evidence, 0.7, weights["evidence"])

        if retrieval.shape[0] and n_nodes > 2:
            negative = torch.randint(0, n_nodes, (retrieval.shape[0],), device=dev)
            invalid = (negative == retrieval[:, 0]) | (negative == retrieval[:, 1])
            while invalid.any():
                negative[invalid] = torch.randint(0, n_nodes, (int(invalid.sum()),), device=dev)
                invalid = (negative == retrieval[:, 0]) | (negative == retrieval[:, 1])
            positive_d = distance(z[retrieval[:, 0]], z[retrieval[:, 1]])
            negative_d = distance(z[retrieval[:, 0]], z[negative])
            loss = loss + weights["retrieval"] * torch.clamp(
                margin + positive_d - negative_d, min=0
            ).sum()

        if query_retrieval.shape[0] and retrieval_candidates.numel() > 1:
            query_ids = query_retrieval[:, 0]
            positive = query_retrieval[:, 1]
            negative_positions = torch.randint(
                0, retrieval_candidates.shape[0],
                (query_retrieval.shape[0],), device=dev,
            )
            negative = retrieval_candidates[negative_positions]
            for position, query_id in enumerate(query_ids.detach().cpu().tolist()):
                options = negative_options.get(query_id)
                if options:
                    negative[position] = options[step % len(options)]
            invalid = negative == positive
            while invalid.any():
                negative_positions[invalid] = torch.randint(
                    0, retrieval_candidates.shape[0],
                    (int(invalid.sum()),), device=dev,
                )
                negative = retrieval_candidates[negative_positions]
                invalid = negative == positive
            query_z = retrieval_queries[query_ids] @ spatial_weight
            positive_d = distance(query_z, z[positive])
            negative_d = distance(query_z, z[negative])
            loss = loss + weights["retrieval"] * torch.clamp(
                margin + positive_d - negative_d, min=0
            ).sum()

        count = n_neg * max(int(dep.shape[0]), 32)
        negative_a = torch.randint(0, n_nodes, (count,), device=dev)
        negative_b = torch.randint(0, n_nodes, (count,), device=dev)
        keep = negative_a != negative_b
        negative_d = distance(z[negative_a[keep]], z[negative_b[keep]])
        loss = loss + weights["repulse"] * torch.clamp(d_rep - negative_d, min=0).sum()

        loss.backward()
        assert z.grad is not None and tau.grad is not None
        z.grad[~mask] = 0
        tau.grad[~mask] = 0
        optimizer.step()
        if step % 50 == 0 or step == steps - 1:
            value = float(loss.item())
            history.append((step, value))
            if callback:
                callback(step, steps, value)

    result = (z.detach().cpu().numpy(), tau.detach().cpu().numpy(), history)
    if return_encoder:
        if spatial_weight is None:
            raise ValueError("return_encoder requires text_vectors")
        return (*result, {
            "spatial_weight": spatial_weight.detach().cpu().numpy(),
            "temporal_weight": temporal_weight.detach().cpu().numpy(),
        })
    return result
