"""HippoRAG 2 compatible query-to-triple recognition memory."""

from __future__ import annotations

from dataclasses import dataclass
from collections import OrderedDict
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

import numpy as np

from . import llm
from .extraction import canonicalize
from .graph import Graph
from .textembed import embed


@dataclass(frozen=True)
class FactCandidate:
    index: int
    triple: tuple[str, str, str]
    src: int
    dst: int
    score: float


class FactIndex:
    """Persistent HNSW index over exact OpenIE triple strings."""

    LEGACY_QUERY_INSTRUCTION = (
        "Given a question, retrieve relevant triplet facts that match this question."
    )

    def __init__(self, path: str | Path):
        source = Path(path)
        metadata = json.loads((source / "metadata.json").read_text())
        self.backend = metadata["backend"]
        self.model = metadata["model"]
        self.dim = int(metadata["dim"])
        self.query_instruction = metadata.get(
            "query_instruction",
            self.LEGACY_QUERY_INSTRUCTION,
        )
        self.triples = [tuple(item) for item in metadata["triples"]]
        arrays = np.load(source / "endpoints.npz")
        self.src = arrays["src"]
        self.dst = arrays["dst"]
        try:
            import hnswlib
        except ImportError as exc:
            raise RuntimeError("hnswlib is required for the fact index") from exc
        self.index = hnswlib.Index(space="ip", dim=self.dim)
        self.index.load_index(str(source / "facts.hnsw"), max_elements=len(self.triples))
        self.index.set_ef(max(128, min(1024, len(self.triples))))
        self._search_cache: OrderedDict[
            tuple[str, int], list[FactCandidate]
        ] = OrderedDict()

    @classmethod
    def build(
        cls,
        path: str | Path,
        *,
        openie_path: str | Path,
        graph: Graph,
        backend: str,
        model: str,
        dim: int,
        batch_size: int = 64,
        cached_prefix: int = 0,
        prefix_batch_size: int = 128,
    ) -> "FactIndex":
        output = Path(path)
        output.mkdir(parents=True, exist_ok=True)
        raw = json.loads(Path(openie_path).read_text())
        unique: dict[tuple[str, str, str], tuple[int, int]] = {}
        for document in raw.get("docs", []):
            for value in document.get("extracted_triples", []):
                if not isinstance(value, (list, tuple)) or len(value) != 3:
                    continue
                triple = (
                    str(value[0]).strip().lower(),
                    str(value[1]).strip().lower(),
                    str(value[2]).strip().lower(),
                )
                source = graph.get_concept(canonicalize(triple[0]))
                target = graph.get_concept(canonicalize(triple[2]))
                if source is None or target is None or source == target:
                    continue
                unique.setdefault(triple, (source, target))
        triples = list(unique)
        endpoints = [unique[triple] for triple in triples]
        texts = [str(triple) for triple in triples]
        import os
        old_batch = os.environ.get("CLM_EMBED_BATCH_SIZE")
        try:
            matrices = []
            if cached_prefix:
                os.environ["CLM_EMBED_BATCH_SIZE"] = str(prefix_batch_size)
                matrices.append(embed(
                    texts[:cached_prefix], backend=backend, model=model, dim=dim
                ))
            os.environ["CLM_EMBED_BATCH_SIZE"] = str(batch_size)
            matrices.append(embed(
                texts[cached_prefix:], backend=backend, model=model, dim=dim
            ))
            vectors = np.vstack(matrices)
        finally:
            if old_batch is None:
                os.environ.pop("CLM_EMBED_BATCH_SIZE", None)
            else:
                os.environ["CLM_EMBED_BATCH_SIZE"] = old_batch
        if vectors.shape != (len(triples), dim):
            raise RuntimeError("invalid fact embedding matrix")
        try:
            import hnswlib
        except ImportError as exc:
            raise RuntimeError("hnswlib is required for the fact index") from exc
        index = hnswlib.Index(space="ip", dim=dim)
        index.init_index(
            max_elements=len(triples), M=32, ef_construction=200, random_seed=13
        )
        index.add_items(np.asarray(vectors, dtype=np.float32), np.arange(len(triples)))
        index.save_index(str(output / "facts.hnsw"))
        np.savez(
            output / "endpoints.npz",
            src=np.asarray([pair[0] for pair in endpoints], dtype=np.int32),
            dst=np.asarray([pair[1] for pair in endpoints], dtype=np.int32),
        )
        (output / "metadata.json").write_text(json.dumps({
            "format_version": 1,
            "backend": backend,
            "model": model,
            "dim": dim,
            "openie_path": str(Path(openie_path).resolve()),
            "query_instruction": (
                "Given a question, retrieve relevant triplet facts that matches "
                "this question."
            ),
            "triples": triples,
        }, ensure_ascii=False))
        return cls(output)

    @classmethod
    def reembed(
        cls,
        source_path: str | Path,
        output_path: str | Path,
        *,
        backend: str,
        model: str,
        batch_size: int = 4,
    ) -> "FactIndex":
        source = Path(source_path)
        output = Path(output_path)
        output.mkdir(parents=True, exist_ok=True)
        metadata = json.loads((source / "metadata.json").read_text())
        triples = [tuple(item) for item in metadata["triples"]]
        texts = [str(triple) for triple in triples]
        import os
        old_batch = os.environ.get("CLM_EMBED_BATCH_SIZE")
        try:
            os.environ["CLM_EMBED_BATCH_SIZE"] = str(batch_size)
            vectors = embed(texts, backend=backend, model=model)
        finally:
            if old_batch is None:
                os.environ.pop("CLM_EMBED_BATCH_SIZE", None)
            else:
                os.environ["CLM_EMBED_BATCH_SIZE"] = old_batch
        if vectors.ndim != 2 or len(vectors) != len(triples):
            raise RuntimeError("invalid replacement fact embedding matrix")
        try:
            import hnswlib
        except ImportError as exc:
            raise RuntimeError("hnswlib is required for the fact index") from exc
        index = hnswlib.Index(space="ip", dim=int(vectors.shape[1]))
        index.init_index(
            max_elements=len(triples), M=32, ef_construction=200, random_seed=13
        )
        index.add_items(np.asarray(vectors, dtype=np.float32), np.arange(len(triples)))
        index.save_index(str(output / "facts.hnsw"))
        arrays = np.load(source / "endpoints.npz")
        np.savez(output / "endpoints.npz", src=arrays["src"], dst=arrays["dst"])
        (output / "metadata.json").write_text(json.dumps({
            **metadata,
            "backend": backend,
            "model": model,
            "dim": int(vectors.shape[1]),
            "query_instruction": (
                "Given a question, retrieve relevant triplet facts that matches "
                "this question."
            ),
            "reembedded_from": str(source.resolve()),
        }, ensure_ascii=False))
        return cls(output)

    def search(self, query: str, top_k: int = 5) -> list[FactCandidate]:
        cache_key = (query, int(top_k))
        cached = self._search_cache.get(cache_key)
        if cached is not None:
            self._search_cache.move_to_end(cache_key)
            return cached
        vector = embed(
            [query], backend=self.backend, model=self.model, dim=self.dim,
            instruction=getattr(
                self, "query_instruction", self.LEGACY_QUERY_INSTRUCTION
            ),
        )[0]
        requested = min(max(1, top_k), len(self.triples))
        labels, distances = self.index.knn_query(
            np.asarray(vector, dtype=np.float32)[None, :], k=requested
        )
        _, opposite_distances = self.index.knn_query(
            np.asarray(-vector, dtype=np.float32)[None, :], k=1
        )
        scores = 1.0 - distances[0]
        maximum = float(scores[0])
        minimum = -float(1.0 - opposite_distances[0, 0])
        scale = max(maximum - minimum, 1e-12)
        result = [
            FactCandidate(
                int(index), self.triples[int(index)], int(self.src[int(index)]),
                int(self.dst[int(index)]),
                float((score - minimum) / scale),
            )
            for index, score in zip(labels[0], scores)
        ]
        self._search_cache[cache_key] = result
        self._search_cache.move_to_end(cache_key)
        while len(self._search_cache) > 2048:
            self._search_cache.popitem(last=False)
        return result


class RecognitionFilter:
    """DSPy-prompted LLM filter with deterministic, auditable disk caching."""

    INPUT_TEMPLATE = (
        "[[ ## question ## ]]\n{question}\n\n"
        "[[ ## fact_before_filter ## ]]\n{facts}\n\n"
        "Respond with the corresponding output fields, starting with the field "
        "`[[ ## fact_after_filter ## ]]` (must be formatted as a valid Python "
        "Fact), and then ending with the marker for `[[ ## completed ## ]]`."
    )
    OUTPUT_TEMPLATE = (
        "[[ ## fact_after_filter ## ]]\n{facts}\n\n[[ ## completed ## ]]"
    )
    FACT_SCHEMA = {
        "type": "object",
        "properties": {
            "fact": {
                "type": "array",
                "maxItems": 4,
                "items": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {"type": "string"},
                },
            }
        },
        "required": ["fact"],
    }

    def __init__(
        self,
        *,
        prompt_path: str | Path,
        cache_dir: str | Path,
        llm_config: dict,
        max_attempts: int = 9,
    ):
        prompt = json.loads(Path(prompt_path).read_text())
        program = prompt["prog"]
        self.system = program["system"]
        self.messages: list[dict[str, str]] = []
        for demo in program.get("demos", []):
            self.messages.append({
                "role": "user",
                "content": self.INPUT_TEMPLATE.format(
                    question=demo["question"], facts=demo["fact_before_filter"]
                ),
            })
            self.messages.append({
                "role": "assistant",
                "content": self.OUTPUT_TEMPLATE.format(
                    facts=demo["fact_after_filter"]
                ),
            })
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.llm_config = dict(llm_config)
        if max_attempts <= 0:
            raise ValueError("max_attempts must be positive")
        self.max_attempts = int(max_attempts)
        self._memory_cache: OrderedDict[
            tuple[str, tuple[int, ...], int], tuple[list[FactCandidate], dict]
        ] = OrderedDict()

    @staticmethod
    def _parse_payload(response: str) -> tuple[list[list[str]], bool]:
        match = re.search(
            r"\[\[ ## fact_after_filter ## \]\]\s*(.*?)\s*"
            r"(?:\[\[ ## completed ## \]\]|$)",
            response,
            flags=re.DOTALL,
        )
        value = match.group(1).strip() if match else response.strip()
        value = re.sub(r"^```(?:json|python)?\s*|\s*```$", "", value)
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            try:
                parsed = ast.literal_eval(value)
            except (ValueError, SyntaxError):
                return [], False
        if not isinstance(parsed, dict) or not isinstance(parsed.get("fact"), list):
            return [], False
        facts = parsed["fact"]
        valid = all(isinstance(fact, list) and len(fact) == 3 for fact in facts)
        if not valid:
            return [], False
        return facts, True

    @staticmethod
    def _parse(response: str) -> list[list[str]]:
        return RecognitionFilter._parse_payload(response)[0]

    def filter(
        self, query: str, candidates: list[FactCandidate], max_facts: int = 4
    ) -> tuple[list[FactCandidate], dict]:
        memory_key = (
            query, tuple(candidate.index for candidate in candidates), int(max_facts)
        )
        cached = self._memory_cache.get(memory_key)
        if cached is not None:
            self._memory_cache.move_to_end(memory_key)
            return cached
        payload = {"fact": [list(candidate.triple) for candidate in candidates]}
        prompt = self.INPUT_TEMPLATE.format(
            question=query, facts=json.dumps(payload, ensure_ascii=False)
        )
        digest = hashlib.sha256()
        digest.update(json.dumps(
            self.llm_config, sort_keys=True, default=str
        ).encode())
        digest.update(self.system.encode())
        digest.update(json.dumps(
            self.messages, sort_keys=True, ensure_ascii=False
        ).encode())
        digest.update(prompt.encode())
        cache_path = self.cache_dir / f"{digest.hexdigest()}.json"
        response = ""
        valid_response = False
        record = {}
        if cache_path.exists():
            try:
                record = json.loads(cache_path.read_text())
            except (json.JSONDecodeError, OSError):
                record = {}
            response = str(record.get("response") or "")
            _, valid_response = self._parse_payload(response)
        attempts = 0
        transport_errors: list[str] = []
        prompt_variant = "full_few_shot"
        while not valid_response and attempts < self.max_attempts:
            attempts += 1
            if attempts <= 5:
                few_shot_messages = self.messages
                prompt_variant = "full_few_shot"
            elif attempts <= 7:
                few_shot_messages = self.messages[-8:]
                prompt_variant = "reduced_few_shot"
            else:
                few_shot_messages = []
                prompt_variant = "zero_shot_retry"
            attempt_config = {
                **self.llm_config,
                "system": self.system,
                "few_shot_messages": few_shot_messages,
                "max_tokens": 2048 if attempts <= 5 else 4096,
                "temperature": 0.0,
            }
            model_name = str(self.llm_config.get("model") or "").lower()
            if model_name.startswith("qwen3:") and not self.llm_config.get(
                "think", True
            ):
                attempt_config["max_tokens"] = 512 if attempts <= 5 else 1024
            if attempts % 2 == 1:
                attempt_config["format"] = self.FACT_SCHEMA
            try:
                response = llm.chat(
                    prompt,
                    provider=self.llm_config.get("provider", "ollama"),
                    config=attempt_config,
                )
            except Exception as exc:
                transport_errors.append(f"{type(exc).__name__}: {exc}")
                response = ""
                continue
            _, valid_response = self._parse_payload(response)
        if not valid_response:
            raise RuntimeError(
                "recognition model failed to produce valid fact JSON after "
                f"{self.max_attempts} attempts; last response={response[:200]!r}"
            )
        record = {
            "question": query,
            "candidates": payload["fact"],
            "response": response,
            "attempts": attempts,
            "prompt_variant": prompt_variant,
        }
        temporary = cache_path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(record, indent=2, ensure_ascii=False))
        temporary.replace(cache_path)
        generated = self._parse(response)
        candidate_strings = [str(list(candidate.triple)) for candidate in candidates]
        selected: list[FactCandidate] = []
        for fact in generated:
            closest = difflib.get_close_matches(
                str(fact), candidate_strings, n=1, cutoff=0.0
            )
            if not closest:
                continue
            candidate = candidates[candidate_strings.index(closest[0])]
            if candidate not in selected:
                selected.append(candidate)
        result = selected[:max_facts], {
            "candidates": payload["fact"],
            "selected": [list(candidate.triple) for candidate in selected[:max_facts]],
            "cache": str(cache_path),
            "valid_response": valid_response,
            "attempts": attempts,
            "transport_errors": transport_errors,
            "prompt_variant": record.get("prompt_variant", "full_few_shot"),
        }
        self._memory_cache[memory_key] = result
        self._memory_cache.move_to_end(memory_key)
        while len(self._memory_cache) > 2048:
            self._memory_cache.popitem(last=False)
        return result
