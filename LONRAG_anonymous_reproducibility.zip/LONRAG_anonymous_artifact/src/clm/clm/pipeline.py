"""End-to-end CLM prototype: documents to a queryable geometric memory."""

from __future__ import annotations

import json
import os
import re
import time
from collections.abc import Callable
from itertools import combinations
from pathlib import Path

import numpy as np

from . import llm
from .chunking import chunk_corpus
from .calibration import CalibrationState
from .extraction import ALLOWED_RELATIONS, add_relation, extract_llm, extract_openie, extract_rules
from .encoder import CoordinateEncoder
from .geometry import lorentz_dist
from .graph import DEPENDENCY, OPPOSITION, RELATED, TAXONOMIC, Graph
from .retrieval import PASSAGE_QUERY_INSTRUCTION, clear_retrieval_caches, evidence_chunks, loci_text, rank_passage_chunks, retrieve
from .textembed import embed
from .train import train
from .vectorstore import get_index
from .verify import EntityResolver, extract_claims, verification_features, verify_answer


def _canonical_passage_text(value: object) -> str:
    return " ".join(str(value).split())


def _chunk_title_and_body(text: str) -> tuple[str, str]:
    heading, _, body = text.partition("\n")
    title = re.sub(r"^#{1,6}\s+", "", heading.strip())
    title = re.sub(r"^\[\d+\]\s+", "", title)
    return title, body.strip()


class Memory:
    FORMAT_VERSION = 3

    def __init__(self, dim: int = 8, steps: int = 2500, seed: int = 13, margin: float = 0.2,
                 vector_backend: str | None = None, text_encoder: str = "hashed",
                 text_model: str = "all-MiniLM-L6-v2", training_backend: str | None = None,
                 vector_options: dict | None = None):
        if dim <= 0 or steps <= 0:
            raise ValueError("dim and steps must be positive")
        self.dim = dim
        self.steps = steps
        self.seed = seed
        self.margin = margin
        self.vector_backend = vector_backend
        self.text_encoder = text_encoder
        self.text_model = text_model
        self.training_backend = training_backend
        self.vector_options = dict(vector_options or {})
        self.graph = Graph()
        self.z = None
        self.tau = None
        self.text_vecs = None
        self.coordinate_encoder = None
        self.backend = None
        self.vindex = None
        self.stats = {}
        self.calibration = CalibrationState()

    def _require_built(self):
        if self.z is None or self.tau is None or self.text_vecs is None:
            raise RuntimeError("memory has not been built or loaded")
        return self.z, self.tau, self.text_vecs

    def _build_vindex(self):
        if self.text_vecs is None:
            raise RuntimeError("text embeddings have not been built or loaded")
        index = get_index(self.text_vecs.shape[1], backend=self.vector_backend, options=self.vector_options)
        index.add(list(range(len(self.graph.nodes))), self.text_vecs)
        self.vindex = index

    def _objective_edges(self):
        dependency = [(e.src, e.dst) for e in self.graph.edges_of(DEPENDENCY)]
        opposition = [(e.src, e.dst) for e in self.graph.edges_of(OPPOSITION)]
        taxonomy = [(e.src, e.dst) for e in self.graph.edges_of(TAXONOMIC)]
        related = [(e.src, e.dst) for e in self.graph.edges if e.etype in RELATED and e.etype != "mentioned_in"]
        evidence = [(e.src, e.dst) for e in self.graph.edges if e.etype == "mentioned_in"]
        dependency_adjacency = {}
        for source, target in dependency:
            dependency_adjacency.setdefault(source, []).append(target)
        reachable_cache = {}
        def descendants(source):
            if source not in reachable_cache:
                seen, frontier = set(), list(dependency_adjacency.get(source, ()))
                while frontier:
                    node = frontier.pop()
                    if node in seen:
                        continue
                    seen.add(node)
                    frontier.extend(dependency_adjacency.get(node, ()))
                reachable_cache[source] = seen
            return reachable_cache[source]
        concepts_by_chunk = {}
        for concept, chunk in evidence:
            if self.graph.nodes[concept].kind == "concept":
                concepts_by_chunk.setdefault(chunk, []).append(concept)
        negative, negative_seen = [], set()
        for concepts in concepts_by_chunk.values():
            unique = list(dict.fromkeys(concepts))
            emitted = 0
            for left, right in combinations(unique, 2):
                pair = (min(left, right), max(left, right))
                if pair in negative_seen or right in descendants(left) or left in descendants(right):
                    continue
                negative_seen.add(pair)
                negative.append(pair)
                emitted += 1
                if emitted == 4:
                    break
        children_by_parent = {}
        for child, parent in taxonomy:
            children_by_parent.setdefault(parent, []).append(child)
        siblings = []
        for children in children_by_parent.values():
            siblings.extend(list(combinations(children[:64], 2)))
        return {"dependency": dependency, "opposition": opposition, "taxonomy": taxonomy,
                "kg": dependency + taxonomy + related, "siblings": siblings,
                "evidence": evidence, "negative": negative}

    def _retrieval_training_data(self, retrieval_supervision, chunk_ids):
        if retrieval_supervision is None:
            return None, [], []
        if self.text_vecs is None:
            raise RuntimeError("text embeddings have not been built or loaded")
        supervision_path = Path(retrieval_supervision)
        if not supervision_path.is_file():
            raise FileNotFoundError(f"retrieval supervision does not exist: {supervision_path}")
        raw = supervision_path.read_text(encoding="utf-8").strip()
        if supervision_path.suffix.lower() == ".json":
            rows = json.loads(raw)
            if isinstance(rows, dict):
                rows = rows.get("examples")
        else:
            rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
        if not isinstance(rows, list) or not rows:
            raise ValueError("retrieval supervision must contain examples")
        chunk_lookup = {}
        for node_id in chunk_ids:
            node = self.graph.nodes[node_id]
            for value in (node.name, node.provenance, node.text):
                chunk_lookup.setdefault(value, []).append(node.idx)
        questions, query_edges, query_negative_edges = [], [], []
        for row_number, row in enumerate(rows, start=1):
            if not isinstance(row, dict) or not isinstance(row.get("question"), str):
                raise ValueError(f"retrieval supervision row {row_number} requires a question")
            positives = row.get("positive_chunks") or row.get("positive_chunk_ids") or row.get("positive_provenance") or row.get("positive_texts")
            if not isinstance(positives, list) or not positives:
                raise ValueError(f"retrieval supervision row {row_number} requires positive chunks")
            question_id = len(questions)
            questions.append(row["question"])
            matched = []
            for positive in positives:
                if not isinstance(positive, str) or positive not in chunk_lookup:
                    raise ValueError(f"retrieval supervision row {row_number} references unknown chunk {positive!r}")
                matched.extend(chunk_lookup[positive])
            query_edges.extend((question_id, node_id) for node_id in dict.fromkeys(matched))
            negatives = row.get("negative_chunks") or row.get("negative_chunk_ids") or row.get("negative_provenance") or row.get("negative_texts") or []
            if not isinstance(negatives, list):
                raise ValueError(f"retrieval supervision row {row_number} negatives must be a list")
            matched_negatives = []
            for negative in negatives:
                if not isinstance(negative, str) or negative not in chunk_lookup:
                    raise ValueError(f"retrieval supervision row {row_number} references unknown negative chunk {negative!r}")
                matched_negatives.extend(chunk_lookup[negative])
            positive_ids = set(matched)
            for node_id in dict.fromkeys(matched_negatives):
                if node_id in positive_ids:
                    raise ValueError(f"retrieval supervision row {row_number} uses the same chunk as a positive and negative")
                query_negative_edges.append((question_id, node_id))
        query_vectors = embed(questions, backend=self.text_encoder, model=self.text_model,
                              dim=self.text_vecs.shape[1], instruction=PASSAGE_QUERY_INSTRUCTION)
        return query_vectors, query_edges, query_negative_edges

    def build(self, docs_dir, extractor="rules", progress=None, max_chars=900, overlap=120,
              llm_config=None, openie_results=None, retrieval_supervision=None):
        clear_retrieval_caches()
        if extractor not in {"rules", "llm", "docs", "openie"}:
            raise ValueError("extractor must be 'rules', 'llm', 'docs', or 'openie'")
        docs_path = Path(docs_dir)
        if not docs_path.is_dir():
            raise FileNotFoundError(f"document directory does not exist: {docs_path}")
        if extractor == "llm" and llm.resolve_provider(llm_config) == "offline":
            raise RuntimeError("LLM extraction requested but no online LLM provider is configured")
        openie_docs = None
        if extractor == "openie":
            if openie_results is None:
                raise ValueError("openie extractor requires openie_results")
            with Path(openie_results).open(encoding="utf-8") as handle:
                payload = json.load(handle)
            openie_docs = payload.get("docs") if isinstance(payload, dict) else None
            if not isinstance(openie_docs, list):
                raise ValueError("openie_results must contain a docs list")
        self.graph = Graph()
        self.z = self.tau = self.text_vecs = None
        self.coordinate_encoder = None
        self.vindex = None
        started = time.time()
        def report(stage, fraction):
            if progress:
                progress(stage, fraction)
        report("chunking", 0.05)
        chunks = chunk_corpus(str(docs_path), max_chars=max_chars, overlap=overlap)
        if not chunks:
            raise ValueError(f"no supported documents found in {docs_path}")
        if openie_docs is not None and len(openie_docs) < len(chunks):
            raise ValueError("openie results contain fewer documents than passage chunks")
        if openie_docs is not None:
            openie_docs = openie_docs[:len(chunks)]
            for position, ((_, _, chunk_text), openie_doc) in enumerate(zip(chunks, openie_docs)):
                if not isinstance(openie_doc, dict):
                    raise ValueError(f"OpenIE document {position} is not an object")
                chunk_title, chunk_body = _chunk_title_and_body(chunk_text)
                if openie_doc.get("title") is not None and _canonical_passage_text(openie_doc["title"]) != _canonical_passage_text(chunk_title):
                    raise ValueError(f"OpenIE title mismatch at passage {position}")
                if openie_doc.get("text") is not None and _canonical_passage_text(openie_doc["text"]) != _canonical_passage_text(chunk_body):
                    raise ValueError(f"OpenIE text mismatch at passage {position}")
        chunk_ids = [self.graph.add_node(chunk_id, kind="chunk", text=text, provenance=chunk_id) for chunk_id, _, text in chunks]
        seed_relations = 0
        if extractor != "docs":
            seed_path = docs_path / "clm_seed.json"
            if seed_path.exists():
                seed_data = json.loads(seed_path.read_text())
                for entry in seed_data.get("edges", []):
                    if not isinstance(entry, list) or len(entry) != 3 or not all(isinstance(v, str) for v in entry):
                        raise ValueError("each clm_seed.json edge must be [subject, relation, object]")
                    subject, relation, object_ = entry
                    relation = relation.lower().strip()
                    if relation not in ALLOWED_RELATIONS:
                        raise ValueError(f"unsupported seed relation: {relation!r}")
                    seed_relations += add_relation(self.graph, subject, relation, object_, confidence=1.0, provenance="clm_seed.json")
        report("extraction", 0.15)
        extracted_relations = 0
        if extractor == "docs":
            for (chunk_id, _, text), chunk_node_id in zip(chunks, chunk_ids):
                title = text.splitlines()[0].lstrip("#").strip() if text.splitlines() else chunk_id
                concept_id = self.graph.add_node(title or chunk_id, kind="concept", text=text, provenance=chunk_id)
                self.graph.add_edge(concept_id, chunk_node_id, "mentioned_in", 1.0, chunk_id)
                extracted_relations += 1
        else:
            for pos, ((chunk_id, _, text), chunk_node_id) in enumerate(zip(chunks, chunk_ids)):
                if extractor == "llm":
                    extracted_relations += extract_llm(self.graph, chunk_node_id, text, chunk_id, lambda prompt: llm.chat(prompt, config=llm_config))
                elif extractor == "openie":
                    title = text.splitlines()[0].lstrip("#").strip() if text.splitlines() else chunk_id
                    extracted_relations += extract_openie(self.graph, chunk_node_id, title, openie_docs[pos].get("extracted_triples", []), chunk_id)
                else:
                    extracted_relations += extract_rules(self.graph, chunk_node_id, text, chunk_id)
        demoted = self.graph.dependency_scc_filter()
        report("text embedding", 0.35)
        texts = [node.text if node.kind == "chunk" else node.name for node in self.graph.nodes]
        self.text_vecs = embed(texts, backend=self.text_encoder, model=self.text_model)
        self._build_vindex()
        retrieval_query_vectors, retrieval_query_edges, retrieval_query_negative_edges = self._retrieval_training_data(retrieval_supervision, chunk_ids)
        objective = self._objective_edges()
        def training_progress(step, total, loss):
            report(f"geometry training (loss {loss:.1f})", 0.45 + 0.5 * step / max(total, 1))
        (self.z, self.tau, history, encoder_state), self.backend = train(
            len(self.graph.nodes), objective["dependency"], objective["opposition"], objective["taxonomy"], objective["kg"],
            dim=self.dim, steps=self.steps, seed=self.seed, margin=self.margin, backend=self.training_backend,
            callback=training_progress, text_vectors=self.text_vecs, kg_edges=objective["kg"], sibling_edges=objective["siblings"],
            evidence_edges=objective["evidence"], retrieval_edges=[], retrieval_query_vectors=retrieval_query_vectors,
            retrieval_query_edges=retrieval_query_edges, retrieval_query_negative_edges=retrieval_query_negative_edges,
            retrieval_candidate_ids=chunk_ids, negative_edges=objective["negative"], return_encoder=True)
        self.coordinate_encoder = CoordinateEncoder(encoder_state["spatial_weight"], encoder_state["temporal_weight"], self.text_encoder, self.text_model)
        dep_sat, opp_sat = self._margin_satisfaction(objective["dependency"], objective["opposition"])
        self.stats = {"nodes": len(self.graph.nodes), "chunks": len(chunk_ids), "concepts": len(self.graph.nodes)-len(chunk_ids),
                      "extracted_relations": extracted_relations, "seed_relations": seed_relations,
                      "dep_edges": len(objective["dependency"]), "opp_edges": len(objective["opposition"]),
                      "hard_negative_edges": len(objective["negative"]), "retrieval_supervision_pairs": len(retrieval_query_edges),
                      "retrieval_hard_negative_pairs": len(retrieval_query_negative_edges),
                      "retrieval_supervision_questions": 0 if retrieval_query_vectors is None else len(retrieval_query_vectors),
                      "tax_edges": len(objective["taxonomy"]), "cycles_demoted": demoted, "backend": self.backend,
                      "vector_backend": self.vindex.name, "text_encoder": self.text_encoder, "text_model": self.text_model,
                      "margin": self.margin, "build_seconds": round(time.time()-started,1), "dep_margin_satisfaction": dep_sat,
                      "opp_margin_satisfaction": opp_sat, "final_loss": history[-1][1] if history else None}
        report("done", 1.0)
        return self.stats

    def retrain_geometry(self, retrieval_supervision, *, steps=None, seed=None, progress=None):
        self._require_built()
        chunk_ids = [n.idx for n in self.graph.nodes if n.kind == "chunk"]
        training_steps = self.steps if steps is None else steps
        training_seed = self.seed if seed is None else seed
        query_vectors, query_edges, query_negative_edges = self._retrieval_training_data(retrieval_supervision, chunk_ids)
        objective = self._objective_edges()
        def training_progress(step, total, loss):
            if progress:
                progress(f"geometry retraining (loss {loss:.1f})", step/max(total,1))
        (self.z, self.tau, history, encoder_state), self.backend = train(
            len(self.graph.nodes), objective["dependency"], objective["opposition"], objective["taxonomy"], objective["kg"],
            dim=self.dim, steps=training_steps, seed=training_seed, margin=self.margin, backend=self.training_backend or self.backend,
            callback=training_progress, text_vectors=self.text_vecs, kg_edges=objective["kg"], sibling_edges=objective["siblings"],
            evidence_edges=objective["evidence"], retrieval_edges=[], retrieval_query_vectors=query_vectors,
            retrieval_query_edges=query_edges, retrieval_query_negative_edges=query_negative_edges,
            retrieval_candidate_ids=chunk_ids, negative_edges=objective["negative"], return_encoder=True)
        self.coordinate_encoder = CoordinateEncoder(encoder_state["spatial_weight"], encoder_state["temporal_weight"], self.text_encoder, self.text_model)
        dep_sat, opp_sat = self._margin_satisfaction(objective["dependency"], objective["opposition"])
        self.steps, self.seed = training_steps, training_seed
        self.stats.update({"retrieval_supervision_pairs": len(query_edges), "retrieval_hard_negative_pairs": len(query_negative_edges),
                           "retrieval_supervision_questions": 0 if query_vectors is None else len(query_vectors),
                           "hard_negative_edges": len(objective["negative"]), "dep_margin_satisfaction": dep_sat,
                           "opp_margin_satisfaction": opp_sat, "final_loss": history[-1][1] if history else None,
                           "geometry_retrain_source": str(Path(retrieval_supervision))})
        return self.stats

    def _margin_satisfaction(self, dependency_edges, opposition_edges):
        z, tau, _ = self._require_built()
        results = []
        for pairs, relation_class in ((dependency_edges, "dependency"), (opposition_edges, "opposition")):
            if not pairs:
                results.append(None); continue
            a = np.asarray([p[0] for p in pairs]); b = np.asarray([p[1] for p in pairs])
            distances = lorentz_dist(z[a], z[b])
            if relation_class == "dependency":
                satisfied = tau[b] - tau[a] >= distances + self.margin
            else:
                satisfied = distances >= np.abs(tau[a] - tau[b]) + self.margin
            results.append(round(float(np.mean(satisfied)),4))
        return results[0], results[1]

    def ask(self, question, provider=None, *, llm_config=None, retrieval_config=None):
        z, tau, text_vecs = self._require_built()
        if not question.strip():
            raise ValueError("question must not be empty")
        retrieval_config = retrieval_config or {}
        if self.coordinate_encoder is None:
            raise RuntimeError("coordinate encoder is missing")
        picked = retrieve(question, self.graph, tau, z, text_vecs, vindex=self.vindex,
                          embedding_backend=self.text_encoder, embedding_model=self.text_model,
                          coordinate_encoder=self.coordinate_encoder,
                          **{k: retrieval_config[k] for k in ["k_seeds","budget","alpha","beta","prefilter","association_hops","association_width","association_similarity_margin"] if k in retrieval_config})
        query_vector = embed([question], backend=self.text_encoder, model=self.text_model, dim=text_vecs.shape[1], instruction=PASSAGE_QUERY_INSTRUCTION)[0]
        query_z, _ = self.coordinate_encoder.encode_query_vectors(query_vector[None,:])
        chunk_ids = np.asarray([n.idx for n in self.graph.nodes if n.kind == "chunk"], dtype=int)
        sims = text_vecs[chunk_ids] @ query_vector if len(chunk_ids) else np.zeros(0)
        dense_k = int(retrieval_config.get("dense_fallback_k",10))
        dense_candidates = [int(chunk_ids[p]) for p in np.argsort(-sims)[:dense_k]] if dense_k and len(chunk_ids) else []
        max_chunks = int(retrieval_config.get("max_chunks",4))
        if retrieval_config.get("ranker","fixed") == "ppr":
            chunks = rank_passage_chunks(question, self.graph, z, text_vecs, embedding_backend=self.text_encoder,
                                         embedding_model=self.text_model, coordinate_encoder=self.coordinate_encoder, top_k=max_chunks)
        else:
            chunks = evidence_chunks(self.graph, [n for n,_ in picked], max_chunks=max_chunks, query_vector=query_vector,
                                     text_vectors=text_vecs, z=z, query_z=query_z[0], alpha=float(retrieval_config.get("alpha",1.0)),
                                     beta=float(retrieval_config.get("beta",0.35)), activation_weight=float(retrieval_config.get("evidence_activation_weight",0.10)),
                                     candidate_chunk_ids=dense_candidates)
        context = loci_text(self.graph, picked, chunks)
        answer, used_provider = llm.generate(question, context, provider=provider, config=llm_config)
        flags = verify_answer(answer, self.graph, tau, z, chunks, text_vectors=text_vecs, coordinate_encoder=self.coordinate_encoder, calibration=self.calibration)
        return {"question": question, "answer": answer, "provider": used_provider, "prompt": llm.render_prompt(question,context,llm_config),
                "context": context, "retrieved": [(self.graph.nodes[n].name,role) for n,role in picked], "verification": flags}

    def calibrate(self, path, *, alpha=0.1):
        z, tau, text_vecs = self._require_built()
        if self.coordinate_encoder is None:
            raise RuntimeError("coordinate encoder is missing")
        resolver = EntityResolver(self.graph, text_vecs, self.coordinate_encoder)
        faithful_gad, faithful_ccc, reversed_scores, invalid_scores = [], [], [], []
        rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
        for row_number, row in enumerate(rows, start=1):
            label = row.get("label")
            if label not in {"faithful","reversed","invalid"}:
                raise ValueError(f"calibration row {row_number} has invalid label {label!r}")
            claims = extract_claims(row.get("claim",""))
            if len(claims) != 1:
                raise ValueError(f"calibration row {row_number} must contain exactly one directional claim")
            a_term,b_term,_,span = claims[0]
            ra, rb = resolver.resolve(a_term), resolver.resolve(b_term)
            if ra is None or rb is None:
                raise ValueError(f"calibration row {row_number} has unresolved endpoints")
            a,b = ra[1], rb[1]
            evidence = [e.dst for e in self.graph.edges if e.etype == "mentioned_in" and e.src in {a,b}]
            features = verification_features(span,a,b,evidence,tau,z,self.coordinate_encoder)
            if label == "faithful": faithful_gad.append(features.gad); faithful_ccc.append(features.ccc_slack)
            elif label == "reversed": reversed_scores.append(features.reversed_slack)
            else: invalid_scores.append(features.invalid_slack)
        self.calibration = CalibrationState.fit(faithful_gad=faithful_gad, faithful_ccc=faithful_ccc,
                                                reversed_slack=reversed_scores, invalid_slack=invalid_scores, alpha=alpha)
        return self.calibration

    def save(self, path):
        z,tau,text_vecs = self._require_built()
        output = Path(path); output.mkdir(parents=True,exist_ok=True)
        if self.coordinate_encoder is None: raise RuntimeError("coordinate encoder is missing")
        arrays = {"z":z,"tau":tau,"text_vecs":text_vecs,"spatial_weight":self.coordinate_encoder.spatial_weight,"temporal_weight":self.coordinate_encoder.temporal_weight}
        if self.coordinate_encoder.query_spatial_weight is not None: arrays["query_spatial_weight"] = self.coordinate_encoder.query_spatial_weight
        if self.coordinate_encoder.query_spatial_bias is not None: arrays["query_spatial_bias"] = self.coordinate_encoder.query_spatial_bias
        np.savez(output/"coords.npz", **arrays)
        data = {"format_version":self.FORMAT_VERSION,"config":{"dim":self.dim,"steps":self.steps,"seed":self.seed,"margin":self.margin,
                "vector_backend":self.vector_backend,"text_encoder":self.text_encoder,"text_model":self.text_model,"training_backend":self.training_backend,
                "vector_options":{k:v for k,v in self.vector_options.items() if k not in {"api_key","token","password"}}},
                "stats":self.stats,"calibration":self.calibration.to_dict(),"ccc_excluded_pairs":sorted([list(p) for p in self.graph.ccc_excluded_pairs]),
                "nodes":[[n.name,n.kind,n.text,n.provenance] for n in self.graph.nodes],
                "edges":[[e.src,e.dst,e.etype,e.confidence,e.provenance] for e in self.graph.edges]}
        (output/"graph.json").write_text(json.dumps(data,indent=2),encoding="utf-8")

    @classmethod
    def load(cls, path, *, vector_backend=None, vector_options=None):
        clear_retrieval_caches(); source = Path(path)
        data = json.loads((source/"graph.json").read_text())
        config = data.get("config",{})
        if vector_backend is not None: config["vector_backend"] = vector_backend
        if vector_options is not None: config["vector_options"] = vector_options
        memory = cls(**config)
        with np.load(source/"coords.npz") as arrays:
            memory.z, memory.tau, memory.text_vecs = arrays["z"], arrays["tau"], arrays["text_vecs"]
            if "spatial_weight" in arrays:
                memory.coordinate_encoder = CoordinateEncoder(arrays["spatial_weight"],arrays["temporal_weight"],memory.text_encoder,memory.text_model,
                                                               arrays["query_spatial_weight"] if "query_spatial_weight" in arrays else None,
                                                               arrays["query_spatial_bias"] if "query_spatial_bias" in arrays else None)
            else:
                memory.coordinate_encoder = CoordinateEncoder.fit_existing(memory.text_vecs,memory.z,memory.tau,backend=memory.text_encoder,model=memory.text_model)
        memory.stats = data.get("stats",{}); memory.calibration = CalibrationState.from_dict(data.get("calibration")); memory.backend = memory.stats.get("backend")
        for name,kind,text,provenance in data["nodes"]: memory.graph.add_node(name,kind,text,provenance)
        for src,dst,relation,confidence,provenance in data["edges"]: memory.graph.add_edge(src,dst,relation,confidence,provenance)
        memory.graph.ccc_excluded_pairs = {tuple(p) for p in data.get("ccc_excluded_pairs",[])}
        memory._build_vindex(); return memory
