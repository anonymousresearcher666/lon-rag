"""CCC, GAD, and lightweight generated-claim handling."""

from __future__ import annotations

import difflib
import re
from collections.abc import Collection, Sequence
from dataclasses import dataclass

import numpy as np

from .geometry import lorentz_dist
from .graph import Graph
from .calibration import CalibrationState
from .encoder import CoordinateEncoder
from .textembed import embed


def ccc(tau: np.ndarray, z: np.ndarray, a: int, b: int, *, tolerance: float = 1e-9) -> tuple[str, float]:
    distance = float(lorentz_dist(z[a:a + 1], z[b:b + 1])[0])
    delta_tau = float(tau[b] - tau[a])
    interval = -(delta_tau * delta_tau) + distance * distance
    margin_slack = delta_tau - distance
    if interval > tolerance:
        return "invalid", margin_slack
    if delta_tau <= tolerance:
        return "reversed", margin_slack
    return "pass", margin_slack


def gad(z: np.ndarray, claim_z: np.ndarray, evidence_idx: Sequence[int]) -> float:
    if len(evidence_idx) == 0:
        return float("inf")
    evidence = np.asarray(evidence_idx, dtype=int)
    claim_batch = np.repeat(np.asarray(claim_z)[None, :], len(evidence), axis=0)
    return float(np.min(lorentz_dist(claim_batch, z[evidence])))


_TERM = r"((?:[A-Za-z][A-Za-z0-9\-]*[ ]){0,3}[A-Za-z][A-Za-z0-9\-]*)"
CLAIM_PATTERNS = [
    (_TERM + r"\s+(?:requires?|depends? on|needs?)\s+" + _TERM, "requires"),
    (_TERM + r"\s+(?:causes?|leads? to)\s+" + _TERM, "causes"),
    (_TERM + r"\s+prevents?\s+" + _TERM, "prevents"),
    (_TERM + r"\s+(?:limits?|constrains?|restricts?)\s+" + _TERM, "limits"),
]


def extract_claims(text: str) -> list[tuple[str, str, str, str]]:
    from .extraction import canonicalize
    claims: list[tuple[str, str, str, str]] = []
    in_quoted_evidence = False
    for raw_line in text.splitlines():
        normalized_line = re.sub(r"\s+", " ", raw_line).strip()
        if normalized_line.startswith("[Evidence]"):
            in_quoted_evidence = True
            continue
        if normalized_line.startswith("["):
            in_quoted_evidence = False
            continue
        if in_quoted_evidence:
            continue
        for sentence in re.split(r"(?<=[.;!?])\s+", normalized_line):
            for pattern, relation in CLAIM_PATTERNS:
                for match in re.finditer(pattern, sentence, flags=re.IGNORECASE):
                    subject = canonicalize(match.group(1))
                    object_ = canonicalize(match.group(2))
                    if not subject or not object_ or subject == object_:
                        continue
                    if relation == "requires":
                        a, b = object_, subject
                    else:
                        a, b = subject, object_
                    claims.append((a, b, relation, match.group(0)))
    return claims


def resolve(term: str, names: Collection[str], cutoff: float = 0.75) -> str | None:
    if term in names:
        return term
    match = difflib.get_close_matches(term, list(names), n=1, cutoff=cutoff)
    return match[0] if match else None


class EntityResolver:
    def __init__(self, graph: Graph, text_vectors: np.ndarray | None = None, coordinate_encoder: CoordinateEncoder | None = None):
        self.graph = graph
        self.ids = [node.idx for node in graph.nodes if node.kind == "concept"]
        self.names = [graph.nodes[node_id].name for node_id in self.ids]
        self.by_name = dict(zip(self.names, self.ids))
        self.text_vectors = text_vectors
        self.coordinate_encoder = coordinate_encoder

    def resolve(self, term: str, cutoff: float = 0.55) -> tuple[str, int] | None:
        if term in self.by_name:
            return term, self.by_name[term]
        term_tokens = set(term.split())
        lexical = []
        for name in self.names:
            name_tokens = set(name.split())
            overlap = len(term_tokens & name_tokens) / max(1, len(term_tokens | name_tokens))
            sequence = difflib.SequenceMatcher(None, term, name).ratio()
            containment = 1.0 if name in term or term in name else 0.0
            lexical.append(max(overlap, sequence, containment))
        scores = np.asarray(lexical, dtype=float)
        if self.text_vectors is not None and self.coordinate_encoder is not None:
            query = embed([term], backend=self.coordinate_encoder.backend, model=self.coordinate_encoder.model, dim=self.coordinate_encoder.input_dim)[0]
            semantic = self.text_vectors[np.asarray(self.ids)] @ query
            scores = 0.55 * scores + 0.45 * ((semantic + 1.0) / 2.0)
        best = int(np.argmax(scores))
        if scores[best] < cutoff:
            return None
        return self.names[best], self.ids[best]


@dataclass(frozen=True)
class VerificationFeatures:
    ccc_verdict: str
    ccc_slack: float
    reversed_slack: float
    invalid_slack: float
    gad: float


def verification_features(span: str, a: int, b: int, evidence_idx: Sequence[int], tau: np.ndarray, z: np.ndarray, coordinate_encoder: CoordinateEncoder | None) -> VerificationFeatures:
    verdict, ccc_slack = ccc(tau, z, a, b)
    distance = float(lorentz_dist(z[a:a + 1], z[b:b + 1])[0])
    delta_tau = float(tau[b] - tau[a])
    if coordinate_encoder is None:
        claim_z = z[b]
    else:
        encoded, _ = coordinate_encoder.encode_texts([span])
        claim_z = encoded[0]
    return VerificationFeatures(
        ccc_verdict=verdict,
        ccc_slack=ccc_slack,
        reversed_slack=(-delta_tau - distance),
        invalid_slack=(distance - abs(delta_tau)),
        gad=gad(z, claim_z, evidence_idx),
    )


def verify_answer(answer: str, graph: Graph, tau: np.ndarray, z: np.ndarray, evidence_idx: Sequence[int], *, gad_threshold: float = 1.5, ccc_domain: set[int] | None = None, min_confidence: float = 0.75, text_vectors: np.ndarray | None = None, coordinate_encoder: CoordinateEncoder | None = None, calibration: CalibrationState | None = None) -> list[dict]:
    calibration = calibration or CalibrationState(gad_max=gad_threshold)
    resolver = EntityResolver(graph, text_vectors, coordinate_encoder)
    results: list[dict] = []
    for a_term, b_term, relation, span in extract_claims(answer):
        resolved_a = resolver.resolve(a_term)
        resolved_b = resolver.resolve(b_term)
        if resolved_a is None or resolved_b is None:
            results.append({
                "claim": span,
                "etype": relation,
                "verdict": "abstain",
                "reason": "unresolved endpoint",
                "a": a_term if resolved_a is None else resolved_a[0],
                "b": b_term if resolved_b is None else resolved_b[0],
            })
            continue
        resolved_a_name, a = resolved_a
        resolved_b_name, b = resolved_b
        outside_domain = ccc_domain is not None and (a not in ccc_domain or b not in ccc_domain)
        if outside_domain or not graph.ccc_eligible(a, b, min_confidence):
            results.append({
                "claim": span,
                "etype": relation,
                "verdict": "abstain",
                "reason": "outside CCC confidence/cycle domain",
                "a": resolved_a_name,
                "b": resolved_b_name,
            })
            continue
        features = verification_features(span, a, b, evidence_idx, tau, z, coordinate_encoder)
        verdict = features.ccc_verdict
        if verdict == "pass" and (features.ccc_slack < calibration.ccc_pass_min or features.gad > calibration.gad_max):
            verdict = "unsupported"
        elif verdict == "reversed" and features.reversed_slack < calibration.reversed_slack_min:
            verdict = "abstain"
        elif verdict == "invalid" and features.invalid_slack < calibration.invalid_slack_min:
            verdict = "abstain"
        results.append({
            "claim": span,
            "etype": relation,
            "verdict": verdict,
            "ccc_slack": round(features.ccc_slack, 3),
            "gad": round(features.gad, 3),
            "a": resolved_a_name,
            "b": resolved_b_name,
            "calibrated": calibration.calibrated,
        })
    return results


def reachability_check(graph: Graph, a: int, b: int) -> bool:
    return graph.reachable(a, b)
