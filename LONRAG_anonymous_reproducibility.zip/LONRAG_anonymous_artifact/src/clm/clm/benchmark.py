"""Dataset-driven benchmark and pipeline-stage ablation runner."""

from __future__ import annotations

import csv
import json
import time
from pathlib import Path

import numpy as np

from . import llm
from .extraction import canonicalize
from .retrieval import evidence_chunks, loci_text, retrieve
from .verify import verify_answer


ABLATIONS = {
    "full": {"beta": 0.35, "expand_roles": True, "loci": True, "verify": True},
    "no_geometry": {"beta": 0.0, "expand_roles": True, "loci": True, "verify": True},
    "no_roles": {"beta": 0.35, "expand_roles": False, "loci": True, "verify": True},
    "text_only": {"beta": 0.0, "expand_roles": False, "loci": True, "verify": True},
    "flat_conditioning": {"beta": 0.35, "expand_roles": True, "loci": False, "verify": True},
    "no_verification": {"beta": 0.35, "expand_roles": True, "loci": True, "verify": False},
}


def load_dataset(path: str | Path) -> list[dict]:
    with Path(path).open(encoding="utf-8") as handle:
        rows = [json.loads(line) for line in handle if line.strip()]
    for number, row in enumerate(rows, start=1):
        if not isinstance(row.get("question"), str) or not row["question"].strip():
            raise ValueError(f"benchmark row {number} requires a non-empty question")
        if "expected_concepts" in row and not isinstance(row["expected_concepts"], list):
            raise ValueError(f"benchmark row {number} expected_concepts must be a list")
    return rows


def _flat_context(memory, picked, chunks) -> str:
    lines = [memory.graph.nodes[node_id].name for node_id, _ in picked]
    lines.extend(memory.graph.nodes[chunk_id].text[:400] for chunk_id in chunks)
    return "\n".join(lines)


def run_benchmark(
    memory,
    dataset_path: str | Path,
    *,
    modes: list[str] | None = None,
    generate: bool = False,
    provider: str | None = None,
) -> tuple[list[dict], list[dict]]:
    """Run retrieval/conditioning/verification ablations on JSONL examples."""
    z, tau, text_vectors = memory._require_built()
    modes = modes or list(ABLATIONS)
    unknown = set(modes) - set(ABLATIONS)
    if unknown:
        raise ValueError(f"unknown benchmark modes: {sorted(unknown)}")
    examples = load_dataset(dataset_path)
    records = []
    for example_id, example in enumerate(examples):
        expected = {canonicalize(value) for value in example.get("expected_concepts", [])}
        expected_verdicts = example.get("expected_verdicts", [])
        for mode in modes:
            config = ABLATIONS[mode]
            started = time.perf_counter()
            picked = retrieve(
                example["question"],
                memory.graph,
                tau,
                z,
                text_vectors,
                beta=float(config["beta"]),
                vindex=memory.vindex,
                embedding_backend=memory.text_encoder,
                embedding_model=memory.text_model,
                coordinate_encoder=memory.coordinate_encoder,
                expand_roles=bool(config["expand_roles"]),
            )
            picked_ids = {node_id for node_id, _ in picked}
            chunks = evidence_chunks(memory.graph, [node_id for node_id, _ in picked])
            context = (
                loci_text(memory.graph, picked, chunks)
                if config["loci"]
                else _flat_context(memory, picked, chunks)
            )
            if generate:
                answer, used_provider = llm.generate(
                    example["question"], context, provider=provider
                )
            else:
                answer = example.get("answer", "")
                used_provider = "dataset" if answer else "none"
            verification = []
            if config["verify"] and answer:
                verification = verify_answer(
                    answer,
                    memory.graph,
                    tau,
                    z,
                    chunks,
                    text_vectors=text_vectors,
                    coordinate_encoder=memory.coordinate_encoder,
                    calibration=memory.calibration,
                )
            names = {memory.graph.nodes[node_id].name for node_id, _ in picked}
            recall = len(names & expected) / len(expected) if expected else None
            verdicts = [item["verdict"] for item in verification]
            verdict_accuracy = None
            if expected_verdicts:
                matches = sum(
                    actual == expected_value
                    for actual, expected_value in zip(verdicts, expected_verdicts)
                )
                verdict_accuracy = matches / len(expected_verdicts)
            records.append({
                "example_id": example_id,
                "mode": mode,
                "question": example["question"],
                "concept_recall": recall,
                "retrieved_nodes": len(picked),
                "evidence_chunks": len(chunks),
                "context_chars": len(context),
                "verification_claims": len(verification),
                "verdict_accuracy": verdict_accuracy,
                "provider": used_provider,
                "latency_ms": round(1000 * (time.perf_counter() - started), 3),
            })

    summary = []
    for mode in modes:
        selected = [row for row in records if row["mode"] == mode]
        summary.append({
            "mode": mode,
            "examples": len(selected),
            "mean_concept_recall": _mean(row["concept_recall"] for row in selected),
            "mean_verdict_accuracy": _mean(row["verdict_accuracy"] for row in selected),
            "mean_context_chars": _mean(row["context_chars"] for row in selected),
            "mean_latency_ms": _mean(row["latency_ms"] for row in selected),
        })
    return records, summary


def _mean(values) -> float | None:
    usable = [value for value in values if value is not None]
    return round(float(np.mean(usable)), 4) if usable else None


def write_report(path: str | Path, records: list[dict]) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]) if records else [])
        if records:
            writer.writeheader()
            writer.writerows(records)
