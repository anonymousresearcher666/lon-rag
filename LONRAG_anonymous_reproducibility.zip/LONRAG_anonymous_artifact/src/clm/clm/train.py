"""Backend dispatch: torch (CPU/CUDA) if available, else pure NumPy."""


def get_backend():
    try:
        import torch  # noqa: F401
        return "torch"
    except ImportError:
        return "numpy"


def train(*args, backend=None, **kwargs):
    be = backend or get_backend()
    if be not in {"numpy", "torch"}:
        raise ValueError(f"unsupported training backend: {be!r}")
    if be == "torch":
        from . import trainer_torch
        return trainer_torch.train(*args, **kwargs), "torch"
    from . import trainer_numpy
    kwargs.pop("device", None)
    return trainer_numpy.train(*args, **kwargs), "numpy"
