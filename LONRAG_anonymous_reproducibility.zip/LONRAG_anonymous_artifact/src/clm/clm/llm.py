"""LLM interface - OpenAI-compatible, OpenRouter, Ollama, and offline."""
import json,os,urllib.error,urllib.request
SYSTEM_PROMPT=("You are a careful technical assistant. Use ONLY the structured context provided. Be concise and explicit about conditions and prerequisites.")
def _post_json(url,body,headers=None,timeout=120):
    req=urllib.request.Request(url,data=json.dumps(body).encode(),headers={"Content-Type":"application/json",**(headers or {})});
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.loads(r.read())
def _ollama_up(base):
    try: urllib.request.urlopen(base+"/api/tags",timeout=2); return True
    except Exception:return False
def resolve_provider(config=None):
    config=config or {}; p=str(config.get("provider") or os.environ.get("CLM_LLM_PROVIDER","auto")).lower()
    if p in ("openai","openrouter","ollama","offline"):return p
    if p!="auto":raise ValueError(f"unknown CLM_LLM_PROVIDER: {p!r}")
    if os.environ.get("OPENROUTER_API_KEY"):return "openrouter"
    if config.get("api_key") or os.environ.get("OPENAI_API_KEY"):return "openai"
    base=config.get("base_url") or os.environ.get("OLLAMA_BASE_URL","http://localhost:11434")
    return "ollama" if _ollama_up(str(base).rstrip("/")) else "offline"
def chat(prompt,system=SYSTEM_PROMPT,max_tokens=None,temperature=None,provider=None,config=None):
    config=config or {}; system=str(config.get("system") or system); max_tokens=int(config.get("max_tokens",600) if max_tokens is None else max_tokens); temperature=float(config.get("temperature",0.0) if temperature is None else temperature); messages=[{"role":"system","content":system}]; messages.extend(config.get("few_shot_messages") or []); messages.append({"role":"user","content":prompt}); p=provider or resolve_provider(config)
    if p in ("openai","openrouter"):
        if p=="openrouter":
            base=str(config.get("base_url") or os.environ.get("OPENROUTER_BASE_URL","https://openrouter.ai/api/v1")).rstrip("/"); api_key=config.get("api_key") or os.environ.get("OPENROUTER_API_KEY");
            if not api_key:raise RuntimeError("OpenRouter provider requires OPENROUTER_API_KEY")
            default_model=os.environ.get("CLM_MODEL","");
            if not (config.get("model") or default_model):raise RuntimeError("OpenRouter provider requires an explicit model")
            headers={"Authorization":f"Bearer {api_key}"}
        else:
            base=str(config.get("base_url") or os.environ.get("OPENAI_BASE_URL","https://api.openai.com/v1")).rstrip("/"); api_key=config.get("api_key") or os.environ.get("OPENAI_API_KEY");
            if not api_key:raise RuntimeError("OpenAI provider requires an API key")
            default_model=os.environ.get("CLM_MODEL","gpt-4o-mini"); headers={"Authorization":f"Bearer {api_key}"}
        body={"model":config.get("model") or default_model,"messages":messages,"max_tokens":max_tokens,"temperature":temperature};
        if isinstance(config.get("extra_body"),dict):body.update(config["extra_body"])
        timeout=float(config.get("timeout",os.environ.get("CLM_LLM_TIMEOUT",120))); out=_post_json(f"{base}/chat/completions",body,headers=headers,timeout=timeout); content=out["choices"][0]["message"].get("content"); return "" if content is None else str(content)
    if p=="ollama":
        base=str(config.get("base_url") or os.environ.get("OLLAMA_BASE_URL","http://localhost:11434")).rstrip("/"); body={"model":config.get("model") or os.environ.get("CLM_MODEL","llama3.1"),"messages":messages,"stream":False,"keep_alive":config.get("keep_alive","30m"),"options":{"temperature":temperature,"num_predict":max_tokens}};
        if "num_ctx" in config:body["options"]["num_ctx"]=int(config["num_ctx"])
        if "think" in config:body["think"]=bool(config["think"])
        if "format" in config:body["format"]=config["format"]
        timeout=float(config.get("timeout",os.environ.get("CLM_LLM_TIMEOUT",120))); out=_post_json(f"{base}/api/chat",body,timeout=timeout); return out["message"]["content"]
    raise RuntimeError("offline provider: no model call available")
def offline_answer(question,context):
    lines=["(offline mode - extractive answer, no LLM call)",""]; keep=False
    for ln in context.splitlines():
        if ln.startswith("[Constraint path]") or ln.startswith("[Evidence]"):keep=True
        elif ln.startswith("[Instruction]"):keep=False
        if keep and ln.strip():lines.append(ln)
    lines += ["",f"Question: {question}","Use the constraint path and evidence above; alternatives are mutually exclusive design choices, not dependencies."]; return "\n".join(lines)
def render_prompt(question,context,config=None):
    config=config or {}; prefix=str(config.get("prompt_prefix") or ""); return f"{prefix}{context}\n\nQuestion: {question}\nThought: " if config.get("qa_prompt_style")=="hipporag2" else f"{prefix}{context}\n\nUSER QUESTION: {question}"
def generate(question,context,provider=None,config=None):
    p=provider or resolve_provider(config); config=config or {}; prompt=render_prompt(question,context,config)
    if p=="offline":return offline_answer(question,context),"offline"
    try:
        answer=chat(prompt,provider=p,config=config); answer_prefix=config.get("answer_prefix");
        if answer_prefix and answer_prefix in answer:answer=answer.split(str(answer_prefix),1)[1].strip()
        return answer,p
    except (urllib.error.URLError,RuntimeError,KeyError,OSError) as e:return offline_answer(question,context)+f"\n\n[provider '{p}' failed: {e}]","offline"
