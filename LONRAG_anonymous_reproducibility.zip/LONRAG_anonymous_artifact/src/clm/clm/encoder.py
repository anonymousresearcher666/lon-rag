"""Trainable text-to-event heads shared by indexing, queries, and claims."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .textembed import embed


def initialize_projection(
    text_vectors: np.ndarray,
    output_dim: int,
    seed: int = 13,
) -> tuple[np.ndarray, np.ndarray]:
    """Initialize a stable text-to-event projection with truncated SVD."""
    vectors = np.asarray(text_vectors, dtype=np.float64)
    if vectors.ndim != 2 or len(vectors) == 0:
        raise ValueError("text_vectors must be a non-empty matrix")
    rng = np.random.default_rng(seed)
    requested = min(output_dim, min(vectors.shape))
    try:
        from sklearn.utils.extmath import randomized_svd
        _, _, right = randomized_svd(
            vectors,
            n_components=requested,
            n_iter=5,
            random_state=seed,
        )
    except ImportError:
        _, _, right = np.linalg.svd(vectors, full_matrices=False)
        right = right[:requested]
    available = min(output_dim, right.shape[0])
    spatial = np.zeros((vectors.shape[1], output_dim), dtype=np.float64)
    spatial[:, :available] = right[:available].T
    if available < output_dim:
        spatial[:, available:] = rng.normal(
            scale=1.0 / np.sqrt(vectors.shape[1]),
            size=(vectors.shape[1], output_dim - available),
        )
    temporal = np.zeros(vectors.shape[1], dtype=np.float64)
    return spatial, temporal


@dataclass
class CoordinateEncoder:
    """A persisted linear head that maps text vectors to CLM events."""

    spatial_weight: np.ndarray
    temporal_weight: np.ndarray
    backend: str = "hashed"
    model: str = "all-MiniLM-L6-v2"
    query_spatial_weight: np.ndarray | None = None
    query_spatial_bias: np.ndarray | None = None

    def __post_init__(self) -> None:
        self.spatial_weight = np.asarray(self.spatial_weight, dtype=np.float64)
        self.temporal_weight = np.asarray(self.temporal_weight, dtype=np.float64)
        if self.spatial_weight.ndim != 2:
            raise ValueError("spatial_weight must be a matrix")
        if self.temporal_weight.shape != (self.spatial_weight.shape[0],):
            raise ValueError("temporal_weight must match the text-vector dimension")
        if self.query_spatial_weight is not None:
            self.query_spatial_weight = np.asarray(self.query_spatial_weight, dtype=np.float64)
            if self.query_spatial_weight.shape != self.spatial_weight.shape:
                raise ValueError("query_spatial_weight must match spatial_weight dimensions")
        if self.query_spatial_bias is not None:
            self.query_spatial_bias = np.asarray(self.query_spatial_bias, dtype=np.float64)
            if self.query_spatial_bias.shape != (self.output_dim,):
                raise ValueError("query_spatial_bias must match the output dimension")

    @property
    def input_dim(self) -> int:
        return self.spatial_weight.shape[0]

    @property
    def output_dim(self) -> int:
        return self.spatial_weight.shape[1]

    def encode_vectors(self, vectors: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        values = np.asarray(vectors, dtype=np.float64)
        if values.shape[-1] != self.input_dim:
            raise ValueError(f"encoder expects {self.input_dim} text features, got {values.shape[-1]}")
        return values @ self.spatial_weight, values @ self.temporal_weight

    def encode_query_vectors(self, vectors: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        values = np.asarray(vectors, dtype=np.float64)
        if values.shape[-1] != self.input_dim:
            raise ValueError(f"encoder expects {self.input_dim} text features, got {values.shape[-1]}")
        weight = self.query_spatial_weight if self.query_spatial_weight is not None else self.spatial_weight
        spatial = values @ weight
        if self.query_spatial_bias is not None:
            spatial = spatial + self.query_spatial_bias
        return spatial, values @ self.temporal_weight

    def encode_texts(self, texts: Iterable[str]) -> tuple[np.ndarray, np.ndarray]:
        vectors = embed(list(texts), backend=self.backend, model=self.model, dim=self.input_dim)
        return self.encode_vectors(vectors)

    @classmethod
    def fit_existing(cls, text_vectors, z, tau, *, backend: str, model: str, ridge: float = 1e-4):
        x = np.asarray(text_vectors, dtype=np.float64)
        gram = x.T @ x + ridge * np.eye(x.shape[1])
        spatial = np.linalg.solve(gram, x.T @ np.asarray(z, dtype=np.float64))
        temporal = np.linalg.solve(gram, x.T @ np.asarray(tau, dtype=np.float64))
        return cls(spatial, temporal, backend, model)
