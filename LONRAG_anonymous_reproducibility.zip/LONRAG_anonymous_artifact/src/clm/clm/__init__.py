"""Causal Lorentzian Memory - compact research prototype.

Docs folder -> chunking -> typed extraction -> spacetime-event geometry
(CPU/CUDA) -> role-diverse retrieval -> LLM (OpenAI-compatible / Ollama /
offline) -> CCC + GAD claim verification.
"""

from .pipeline import Memory  # noqa: F401

__version__ = "0.2.0"
