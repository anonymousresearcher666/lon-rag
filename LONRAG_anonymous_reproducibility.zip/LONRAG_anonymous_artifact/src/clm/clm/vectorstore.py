"""Configurable vector index for retrieval prefiltering.

Backends (env CLM_VECTOR_BACKEND, default "auto"):
  faiss    - FAISS HNSW (pip install faiss-cpu | faiss-gpu)
  hnswlib  - hnswlib HNSW (pip install hnswlib)
  qdrant   - remote Qdrant via REST (production vector DB)
             QDRANT_URL (default http://localhost:6333),
             QDRANT_COLLECTION (default clm), QDRANT_API_KEY (optional)
  numpy    - exact brute-force (always available; fine to ~10^5 vectors)
  auto     - faiss > hnswlib > numpy

All backends implement: add(ids, vectors), search(vector, k) -> [(id, score)].
Scores are inner products on normalized vectors (cosine). The pipeline uses
this as the ANN *prefilter*; exact geometric reranking (d_L) happens after,
so backend recall only affects the candidate pool, never correctness.
"""

import json
import os
import urllib.request

import numpy as np


class NumpyIndex:
    name = "numpy"

    def __init__(self, dim):
        self.dim = dim
        self.ids, self.vecs = [], np.zeros((0, dim), dtype=np.float32)

    def add(self, ids, vectors):
        values = np.asarray(vectors, np.float32)
        if values.ndim != 2 or values.shape[1] != self.dim:
            raise ValueError(f"expected vectors with shape (n, {self.dim})")
        if len(ids) != len(values):
            raise ValueError("ids and vectors must have equal length")
        self.ids.extend(ids)
        self.vecs = np.vstack([self.vecs, values])

    def search(self, vector, k):
        if not len(self.ids):
            return []
        sims = self.vecs @ np.asarray(vector, np.float32)
        top = np.argsort(-sims)[:k]
        return [(self.ids[i], float(sims[i])) for i in top]


class FaissIndex:
    name = "faiss"

    def __init__(self, dim, m=32):
        import faiss
        self.index = faiss.IndexHNSWFlat(dim, m, faiss.METRIC_INNER_PRODUCT)
        self.index.hnsw.efSearch = 128
        self.ids = []

    def add(self, ids, vectors):
        self.ids.extend(ids)
        self.index.add(np.asarray(vectors, np.float32))

    def search(self, vector, k):
        distances, indices = self.index.search(
            np.asarray([vector], np.float32), min(k, len(self.ids))
        )
        return [
            (self.ids[i], float(distance))
            for distance, i in zip(distances[0], indices[0]) if i >= 0
        ]


class HnswlibIndex:
    name = "hnswlib"

    def __init__(self, dim, max_elements=1_000_000):
        import hnswlib
        self.index = hnswlib.Index(space="ip", dim=dim)
        self.index.init_index(max_elements=max_elements, M=32,
                              ef_construction=200)
        self.index.set_ef(128)
        self.count = 0

    def add(self, ids, vectors):
        self.index.add_items(np.asarray(vectors, np.float32),
                             np.asarray(ids, np.int64))
        self.count += len(ids)

    def search(self, vector, k):
        if self.count == 0:
            return []
        labels, dists = self.index.knn_query(
            np.asarray(vector, np.float32), k=min(k, self.count))
        return [(int(i), 1.0 - float(d))
                for i, d in zip(labels[0], dists[0])]


class QdrantIndex:
    """Remote Qdrant over REST - a real production vector database.
    No SDK dependency; stdlib urllib only."""
    name = "qdrant"

    def __init__(self, dim, *, url=None, collection=None, api_key=None):
        self.base = str(url or os.environ.get(
            "QDRANT_URL", "http://localhost:6333"
        )).rstrip("/")
        self.coll = collection or os.environ.get("QDRANT_COLLECTION", "clm")
        self.headers = {"Content-Type": "application/json"}
        key = api_key or os.environ.get("QDRANT_API_KEY")
        if key:
            self.headers["api-key"] = key
        self._req("PUT", f"/collections/{self.coll}", {
            "vectors": {"size": dim, "distance": "Dot"}})

    def _req(self, method, path, body=None):
        req = urllib.request.Request(
            self.base + path,
            data=json.dumps(body).encode() if body is not None else None,
            headers=self.headers, method=method)
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())

    def add(self, ids, vectors, batch=256):
        pts = [{"id": int(i), "vector": np.asarray(v, np.float32).tolist()}
               for i, v in zip(ids, vectors)]
        for j in range(0, len(pts), batch):
            self._req("PUT", f"/collections/{self.coll}/points?wait=true",
                      {"points": pts[j:j + batch]})

    def search(self, vector, k):
        out = self._req("POST", f"/collections/{self.coll}/points/search",
                        {"vector": np.asarray(vector, np.float32).tolist(),
                         "limit": k})
        return [(int(p["id"]), float(p["score"]))
                for p in out.get("result", [])]


def get_index(dim, backend=None, options=None):
    """Create a vector index.

    ``auto`` falls back through optional local backends. An explicitly named
    backend is strict: configuration and connection failures are surfaced.
    """
    be = (backend or os.environ.get("CLM_VECTOR_BACKEND", "auto")).lower()
    factories = {
        "faiss": FaissIndex,
        "hnswlib": HnswlibIndex,
        "qdrant": QdrantIndex,
        "numpy": NumpyIndex,
    }
    if be not in factories and be != "auto":
        raise ValueError(f"unknown vector backend: {be!r}")
    if be != "auto":
        if be == "qdrant":
            return factories[be](dim, **(options or {}))
        return factories[be](dim)

    order = ("faiss", "hnswlib", "numpy")
    for name in order:
        try:
            return factories[name](dim)
        except ImportError:
            continue
    return NumpyIndex(dim)
