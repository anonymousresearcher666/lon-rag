"""Format-aware document loading and heading-aware chunking."""

from __future__ import annotations

import csv
import json
import re
from html.parser import HTMLParser
from pathlib import Path


TEXT_SUFFIXES = {".txt", ".md", ".markdown", ".rst", ".log"}
TABULAR_SUFFIXES = {".csv", ".tsv"}
JSON_SUFFIXES = {".json", ".jsonl"}
HTML_SUFFIXES = {".html", ".htm"}
OPTIONAL_SUFFIXES = {".pdf", ".docx", ".pptx", ".xlsx"}
RESERVED_FILENAMES = {"clm_seed.json"}
SUPPORTED_SUFFIXES = (
    TEXT_SUFFIXES | TABULAR_SUFFIXES | JSON_SUFFIXES | HTML_SUFFIXES | OPTIONAL_SUFFIXES
)


class DocumentLoadError(RuntimeError):
    """Raised when a supported document cannot be decoded or parsed."""


class _HTMLTextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.skip_depth = 0

    def handle_starttag(self, tag, attrs):
        del attrs
        lowered = tag.lower()
        if lowered in {"script", "style", "noscript"}:
            self.skip_depth += 1
        if lowered in {"p", "div", "section", "article", "li", "br"}:
            self.parts.append("\n")
        if lowered in {"h1", "h2", "h3", "h4"}:
            self.parts.append(f"\n{'#' * int(lowered[1])} ")

    def handle_endtag(self, tag):
        lowered = tag.lower()
        if lowered in {"script", "style", "noscript"} and self.skip_depth:
            self.skip_depth -= 1
        if lowered in {"p", "div", "section", "article", "li", "h1", "h2", "h3", "h4"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip_depth and data.strip():
            self.parts.append(data.strip())

    def text(self):
        value = " ".join(self.parts)
        return re.sub(r"[ \t]*\n[ \t]*", "\n", value).strip()


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="latin-1")


def _read_tabular(path: Path) -> str:
    delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    with path.open(encoding="utf-8-sig", errors="replace", newline="") as handle:
        rows = list(csv.reader(handle, delimiter=delimiter))
    if not rows:
        return ""
    header = rows[0]
    blocks = ["# Table"]
    for row_number, row in enumerate(rows[1:] if len(rows) > 1 else rows, start=1):
        values = []
        for index, value in enumerate(row):
            label = header[index] if len(rows) > 1 and index < len(header) else f"column_{index + 1}"
            if value.strip():
                values.append(f"{label}: {value.strip()}")
        if values:
            blocks.append(f"## Row {row_number}\n" + "\n".join(values))
    return "\n\n".join(blocks)


def _read_json(path: Path) -> str:
    if path.suffix.lower() == ".jsonl":
        values = []
        for line_number, line in enumerate(_read_text(path).splitlines(), start=1):
            if line.strip():
                try:
                    values.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise DocumentLoadError(f"invalid JSONL at line {line_number}: {exc}") from exc
    else:
        try:
            values = json.loads(_read_text(path))
        except json.JSONDecodeError as exc:
            raise DocumentLoadError(f"invalid JSON: {exc}") from exc
    return "# JSON data\n\n" + json.dumps(values, indent=2, ensure_ascii=True)


def _read_html(path: Path) -> str:
    parser = _HTMLTextExtractor()
    parser.feed(_read_text(path))
    return parser.text()


def _read_pdf(path: Path) -> str:
    try:
        import pypdf
    except ImportError as exc:
        raise DocumentLoadError(
            "PDF support requires pypdf; install with `pip install -e '.[documents]'`"
        ) from exc
    try:
        reader = pypdf.PdfReader(str(path))
        pages = []
        for number, page in enumerate(reader.pages, start=1):
            text = (page.extract_text() or "").strip()
            if text:
                pages.append(f"# Page {number}\n\n{text}")
        return "\n\n".join(pages)
    except Exception as exc:
        raise DocumentLoadError(f"unable to read PDF: {exc}") from exc


def _read_docx(path: Path) -> str:
    try:
        import docx
    except ImportError as exc:
        raise DocumentLoadError(
            "DOCX support requires python-docx; install with `pip install -e '.[documents]'`"
        ) from exc
    try:
        document = docx.Document(str(path))
        blocks = [paragraph.text.strip() for paragraph in document.paragraphs if paragraph.text.strip()]
        for table_number, table in enumerate(document.tables, start=1):
            blocks.append(f"# Table {table_number}")
            for row in table.rows:
                values = [cell.text.strip() for cell in row.cells]
                if any(values):
                    blocks.append(" | ".join(values))
        return "\n\n".join(blocks)
    except Exception as exc:
        raise DocumentLoadError(f"unable to read DOCX: {exc}") from exc


def _read_pptx(path: Path) -> str:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise DocumentLoadError(
            "PPTX support requires python-pptx; install with `pip install -e '.[documents]'`"
        ) from exc
    try:
        presentation = Presentation(str(path))
        slides = []
        for number, slide in enumerate(presentation.slides, start=1):
            text = [shape.text.strip() for shape in slide.shapes if hasattr(shape, "text") and shape.text.strip()]
            if text:
                slides.append(f"# Slide {number}\n\n" + "\n\n".join(text))
        return "\n\n".join(slides)
    except Exception as exc:
        raise DocumentLoadError(f"unable to read PPTX: {exc}") from exc


def _read_xlsx(path: Path) -> str:
    try:
        import openpyxl
    except ImportError as exc:
        raise DocumentLoadError(
            "XLSX support requires openpyxl; install with `pip install -e '.[documents]'`"
        ) from exc
    try:
        workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
        sheets = []
        for worksheet in workbook.worksheets:
            rows = []
            for row in worksheet.iter_rows(values_only=True):
                values = ["" if value is None else str(value) for value in row]
                if any(values):
                    rows.append(" | ".join(values))
            if rows:
                sheets.append(f"# Sheet: {worksheet.title}\n\n" + "\n".join(rows))
        return "\n\n".join(sheets)
    except Exception as exc:
        raise DocumentLoadError(f"unable to read XLSX: {exc}") from exc


READERS = {
    **{suffix: _read_text for suffix in TEXT_SUFFIXES},
    **{suffix: _read_tabular for suffix in TABULAR_SUFFIXES},
    **{suffix: _read_json for suffix in JSON_SUFFIXES},
    **{suffix: _read_html for suffix in HTML_SUFFIXES},
    ".pdf": _read_pdf,
    ".docx": _read_docx,
    ".pptx": _read_pptx,
    ".xlsx": _read_xlsx,
}


def iter_document_files(docs_dir: str | Path) -> list[Path]:
    root = Path(docs_dir)
    if not root.is_dir():
        raise FileNotFoundError(f"document directory does not exist: {root}")
    return [
        path for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.name.lower() not in RESERVED_FILENAMES
        and path.suffix.lower() in SUPPORTED_SUFFIXES
    ]


def read_document(path: str | Path) -> str:
    document = Path(path)
    reader = READERS.get(document.suffix.lower())
    if reader is None:
        raise DocumentLoadError(f"unsupported document type: {document.suffix or '(none)'}")
    return reader(document)


def load_documents(docs_dir: str | Path):
    root = Path(docs_dir)
    documents = []
    for path in iter_document_files(root):
        text = read_document(path).strip()
        if text:
            documents.append((str(path.relative_to(root)), text))
    return documents


def _split_long_block(block: str, max_chars: int, overlap: int) -> list[str]:
    if len(block) <= max_chars:
        return [block]
    parts = []
    start = 0
    step = max(1, max_chars - overlap)
    while start < len(block):
        end = min(len(block), start + max_chars)
        if end < len(block):
            boundary = block.rfind(" ", start + max_chars // 2, end)
            if boundary > start:
                end = boundary
        part = block[start:end].strip()
        if part:
            parts.append(part)
        if end >= len(block):
            break
        start = max(start + 1, end - overlap)
    return parts


def chunk_document(name, text, max_chars=900, overlap=120):
    """Chunk a document by headings/paragraphs with bounded overlap."""
    if max_chars <= 0:
        raise ValueError("chunk size must be positive")
    if overlap < 0 or overlap >= max_chars:
        raise ValueError("chunk overlap must be non-negative and smaller than chunk size")
    chunks: list[tuple[str, str]] = []
    buffer: list[str] = []
    section = ""

    def flush():
        if buffer:
            chunks.append((section, "\n\n".join(buffer)))
            buffer.clear()

    for raw_block in re.split(r"\n\s*\n", text.replace("\r\n", "\n")):
        block = raw_block.strip()
        if not block:
            continue
        heading = re.match(r"^#{1,4}\s+(.*)$", block.splitlines()[0])
        if heading:
            flush()
            section = heading.group(1).strip()
        for part in _split_long_block(block, max_chars, overlap):
            projected = sum(len(value) for value in buffer) + len(buffer) * 2 + len(part)
            if projected > max_chars and buffer:
                flush()
            buffer.append(part)
    flush()
    return [(f"{name}::{index}", current_section, chunk) for index, (current_section, chunk) in enumerate(chunks)]


def chunk_corpus(docs_dir, max_chars=900, overlap=120):
    chunks = []
    for name, text in load_documents(docs_dir):
        chunks.extend(chunk_document(name, text, max_chars, overlap))
    return chunks


def inspect_corpus(docs_dir: str | Path) -> dict:
    root = Path(docs_dir)
    files = iter_document_files(root)
    by_type: dict[str, int] = {}
    total_bytes = 0
    entries = []
    for path in files:
        suffix = path.suffix.lower().lstrip(".") or "text"
        by_type[suffix] = by_type.get(suffix, 0) + 1
        size = path.stat().st_size
        total_bytes += size
        entries.append({
            "name": str(path.relative_to(root)),
            "type": suffix.upper(),
            "bytes": size,
        })
    return {
        "path": str(root.resolve()),
        "files": entries,
        "file_count": len(entries),
        "total_bytes": total_bytes,
        "by_type": by_type,
        "supported_extensions": sorted(SUPPORTED_SUFFIXES),
    }
