"""Rule-based and optional LLM relation extraction for CLM."""

from __future__ import annotations

import re
from collections.abc import Callable

from .graph import Graph


TERM = r"((?:[A-Za-z][A-Za-z0-9\-]*[ ]){0,3}[A-Za-z][A-Za-z0-9\-]*)"

# Pattern, relation, source/target capture groups, confidence. The selected
# groups already follow Graph's dependency convention: prerequisite -> effect.
RULES = [
    (rf"{TERM}\s+(?:requires?|depends? (?:on|upon)|needs?)\s+{TERM}",
     "requires", (2, 1), 0.90),
    (rf"{TERM}\s+(?:is|are)\s+(?:needed|required|necessary|a prerequisite)\s+"
     rf"(?:for|of|to)\s+{TERM}", "requires", (1, 2), 0.85),
    (rf"[Ww]ithout\s+{TERM},\s+{TERM}", "requires", (1, 2), 0.75),
    (rf"{TERM}\s+must\s+(?:precede|come before|happen before)\s+{TERM}",
     "requires", (1, 2), 0.85),
    (rf"{TERM}\s+(?:causes?|leads? to|results? in|triggers?)\s+{TERM}",
     "causes", (1, 2), 0.85),
    (rf"{TERM}\s+(?:prevents?|avoids?|mitigates?|protects? against)\s+{TERM}",
     "prevents", (1, 2), 0.85),
    (rf"{TERM}\s+(?:limits?|constrains?|restricts?)\s+{TERM}",
     "limits", (1, 2), 0.80),
    (rf"{TERM}\s+(?:is a kind of|is a type of|is a|are a type of)\s+{TERM}",
     "is_a", (1, 2), 0.75),
    (rf"{TERM}\s+(?:is|are)\s+part of\s+{TERM}",
     "part_of", (1, 2), 0.80),
    (rf"{TERM}\s+(?:(?:is|are) an alternative to|(?:serves? )?as an alternative to|instead of|"
     rf"can replace)\s+{TERM}", "alternative_to", (1, 2), 0.85),
    (rf"{TERM}\s+(?:contradicts?|is incompatible with|conflicts? with|"
     rf"cannot be combined with)\s+{TERM}", "contradicts", (1, 2), 0.85),
]

NEGATION = re.compile(
    r"\b(?:not|never|no longer|doesn'?t|don'?t|does not|do not)\s+"
    r"(?:require|need|depend|cause|prevent|limit)",
    re.IGNORECASE,
)
STOP = {
    "this", "that", "these", "those", "it", "they", "which", "the system",
    "the unit", "there", "the", "a", "an",
}
_TRAIL = {
    "in", "of", "on", "for", "with", "to", "at", "by", "the", "a", "an",
    "and", "or", "either", "both", "its", "their",
}


def canonicalize(term: str) -> str:
    normalized = re.sub(r"\s+", " ", term.strip().lower())
    normalized = re.sub(
        r"^(the|a|an|this|these|those|its|their|either|both)\s+",
        "",
        normalized,
    )
    words = normalized.split()
    while words and words[-1] in _TRAIL:
        words.pop()
    while words and words[0] in _TRAIL:
        words.pop(0)
    normalized = " ".join(words)
    if normalized.endswith("s") and not normalized.endswith("ss") and len(normalized) > 4:
        normalized = normalized[:-1]
    return normalized


def add_relation(
    graph: Graph,
    subject: str,
    relation: str,
    object_: str,
    *,
    confidence: float,
    provenance: str,
    chunk_idx: int | None = None,
) -> bool:
    """Add a natural-language triple using the graph's edge convention."""
    subject = canonicalize(subject)
    object_ = canonicalize(object_)
    relation = relation.lower().strip()
    if not subject or not object_ or subject == object_:
        return False
    if subject in STOP or object_ in STOP:
        return False

    subject_idx = graph.add_node(subject)
    object_idx = graph.add_node(object_)
    if relation == "requires":
        src, dst = object_idx, subject_idx
    else:
        src, dst = subject_idx, object_idx
    graph.add_edge(src, dst, relation, confidence, provenance)

    if chunk_idx is not None:
        graph.add_edge(subject_idx, chunk_idx, "mentioned_in", 1.0, provenance)
        graph.add_edge(object_idx, chunk_idx, "mentioned_in", 1.0, provenance)
    return True


def extract_rules(graph: Graph, chunk_idx: int, text: str, provenance: str) -> int:
    """Extract typed relations from one chunk with deterministic cue rules."""
    extracted = 0
    without_headings = re.sub(r"(?m)^#{1,6}\s+.*$", "", text)
    for raw_sentence in re.split(r"(?<=[.;])\s+", without_headings):
        sentence = re.sub(r"\s+", " ", raw_sentence).strip()
        if not sentence or NEGATION.search(sentence):
            continue
        for pattern, relation, groups, confidence in RULES:
            for match in re.finditer(pattern, sentence, flags=re.IGNORECASE):
                # Rule capture groups already encode graph orientation. Convert
                # back to a natural-language triple for the shared insertion API.
                left = canonicalize(match.group(groups[0]))
                right = canonicalize(match.group(groups[1]))
                if relation == "requires":
                    subject, object_ = right, left
                else:
                    subject, object_ = left, right
                extracted += add_relation(
                    graph,
                    subject,
                    relation,
                    object_,
                    confidence=confidence,
                    provenance=provenance,
                    chunk_idx=chunk_idx,
                )
    return extracted


LLM_EXTRACTION_PROMPT = """Extract typed relations from the passage.
Return one per line as: ENTITY_A | RELATION | ENTITY_B
Allowed relations: requires, causes, prevents, limits, is_a, part_of,
alternative_to, contradicts. "A | requires | B" means A depends on B.
Use short canonical noun phrases. Output nothing else.

PASSAGE:
{passage}"""
ALLOWED_RELATIONS = {
    "requires", "causes", "prevents", "limits", "is_a", "part_of",
    "alternative_to", "contradicts", "related",
}


def classify_open_relation(relation: str) -> str:
    """Map an open predicate onto a CLM relation class without discarding it."""
    # Predicates are not entity names.  In particular, canonicalize() removes
    # trailing prepositions (useful for noun phrases, disastrous for predicates):
    # ``part of`` used to become ``part`` and ``results in`` became ``result``.
    # Preserve the complete predicate here so relation typing sees its syntax.
    value = re.sub(r"\s+", " ", relation.strip().lower())
    if re.search(
        r"\b(?:not|never|cannot|can't|does not|do not|did not|failed to)\s+"
        r"(?:require|need|depend|cause|prevent|avoid|limit|restrict|constrain)",
        value,
    ):
        return "related"
    if re.search(r"\b(requir(?:e|es|ed|ing)|depend(?:s|ed|ing)?(?: on| upon)?|need(?:s|ed|ing)?)\b", value):
        return "requires"
    if re.search(
        r"\b(caus(?:e|es|ed|ing)|lead(?:s|ing)? to|led to|"
        r"trigger(?:s|ed|ing)?|result(?:s|ed|ing)? in)\b",
        value,
    ):
        return "causes"
    if re.search(r"\b(prevent(?:s|ed|ing)?|avoid(?:s|ed|ing)?|mitigat(?:e|es|ed|ing))\b", value):
        return "prevents"
    if re.search(r"\b(limit(?:s|ed|ing)?|constrain(?:s|ed|ing)?|restrict(?:s|ed|ing)?)\b", value):
        return "limits"
    if re.search(r"\b(alternative|substitute|replacement|replaced by)\b", value):
        return "alternative_to"
    if re.search(r"\b(contradict(?:s|ed|ing)?|conflict(?:s|ed|ing)?(?: with)?|opposite)\b", value):
        return "contradicts"
    if re.search(
        r"\b(?:is |are |was |were |be |been )?(?:a |an |the )?"
        r"(?:part|component|member) of\b|\bbelong(?:s|ed|ing)? to\b",
        value,
    ):
        return "part_of"
    if re.fullmatch(r"(?:is|was|are|were) (?:a|an)", value) or re.search(
        r"\b(?:is|was|are|were) (?:a |an |the )?(?:kind|type|class) of\b",
        value,
    ):
        return "is_a"
    return "related"


def normalize_open_relation(
    subject: str, predicate: str, object_: str
) -> tuple[str, str, str]:
    """Type an OpenIE triple and normalize passive causal orientation."""
    relation = classify_open_relation(predicate)
    value = re.sub(r"\s+", " ", predicate.strip().lower())
    inverse = False
    if relation == "causes":
        inverse = bool(re.search(
            r"\b(?:is|are|was|were|be|been)?\s*caused by\b|"
            r"\bresult(?:s|ed|ing)? from\b|\bdue to\b",
            value,
        ))
    elif relation == "requires":
        inverse = bool(re.search(
            r"\b(?:is|are|was|were|be|been)?\s*(?:required|needed)\s+"
            r"(?:by|for|to)\b",
            value,
        ))
    elif relation == "prevents":
        inverse = bool(re.search(r"\bprevent(?:ed)? by\b", value))
    elif relation == "limits":
        inverse = bool(re.search(
            r"\b(?:limit(?:ed)?|restrict(?:ed)?|constrain(?:ed)?) by\b",
            value,
        ))
    if inverse:
        subject, object_ = object_, subject
    return subject, relation, object_


def extract_openie(
    graph: Graph,
    chunk_idx: int,
    passage_name: str,
    triples: list[list[str]],
    provenance: str,
) -> int:
    """Insert precomputed OpenIE triples and integrate passage/entity nodes.

    The passage-to-phrase edges implement the dense/sparse integration needed
    for graph search: a query can seed either a passage or a phrase and still
    reach the other representation.
    """
    passage_idx = graph.add_node(passage_name, kind="concept")
    graph.add_edge(passage_idx, chunk_idx, "mentioned_in", 1.0, provenance)
    extracted = 0
    for triple in triples:
        if not isinstance(triple, list) or len(triple) != 3:
            continue
        subject, predicate, object_ = (str(value) for value in triple)
        subject, relation, object_ = normalize_open_relation(
            subject, predicate, object_
        )
        if not add_relation(
            graph,
            subject,
            relation,
            object_,
            confidence=0.85,
            provenance=provenance,
            chunk_idx=chunk_idx,
        ):
            continue
        extracted += 1
        subject_idx = graph.get_concept(canonicalize(subject))
        object_idx = graph.get_concept(canonicalize(object_))
        for entity_idx in (subject_idx, object_idx):
            if entity_idx is not None and entity_idx != passage_idx:
                graph.add_edge(passage_idx, entity_idx, "related", 1.0, provenance)
    return extracted


def extract_llm(
    graph: Graph,
    chunk_idx: int,
    text: str,
    provenance: str,
    llm_call: Callable[[str], str],
) -> int:
    """Extract typed triples from an LLM's strict line-based response."""
    extracted = 0
    response = llm_call(LLM_EXTRACTION_PROMPT.format(passage=text[:2000]))
    for line in response.splitlines():
        parts = [part.strip() for part in line.split("|")]
        if len(parts) != 3:
            continue
        subject, relation, object_ = parts
        if relation.lower() not in ALLOWED_RELATIONS:
            continue
        extracted += add_relation(
            graph,
            subject,
            relation,
            object_,
            confidence=0.85,
            provenance=provenance,
            chunk_idx=chunk_idx,
        )
    return extracted
