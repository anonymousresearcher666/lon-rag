"""Text embeddings with deterministic offline, Ollama, SentenceTransformers and NV-Embed-v2 backends."""
import hashlib,json,os,re,urllib.error,urllib.request
from pathlib import Path
from typing import Any,Iterable
import numpy as np
DIM=512

def _hash(token:str,dim:int)->tuple[int,float]:
    h=int(hashlib.md5(token.encode()).hexdigest()[:8],16); return h%dim,(1.0 if (h>>1)%2==0 else -1.0)

def embed_hashed(texts:Iterable[str],dim:int=DIM)->np.ndarray:
    texts=list(texts); out=np.zeros((len(texts),dim),dtype=np.float32)
    for i,t in enumerate(texts):
        toks=re.findall(r"[a-z0-9]+",t.lower()); grams=toks+[" ".join(toks[j:j+2]) for j in range(len(toks)-1)]
        for g in grams:
            j,s=_hash(g,dim); out[i,j]+=s
        n=np.linalg.norm(out[i]);
        if n>0: out[i]/=n
    return out
_ST_MODELS:dict[str,Any]={}; _NV_MODELS:dict[str,Any]={}

def _patch_nv_sdpa_attention_4d(model:Any,torch:Any)->None:
    import types
    def forward(module:Any,x:Any,context:Any=None,mask:Any=None)->Any:
        del mask; context=x if context is None else context; batch,ql,_=x.shape; cl=context.shape[1]; heads=module.heads; q=module.to_q(x); k,v=module.to_kv(context).chunk(2,dim=-1); hd=q.shape[-1]//heads
        def split(vv,l): return vv.reshape(batch,l,heads,hd).transpose(1,2)
        q,k,v=split(q,ql),split(k,cl),split(v,cl); output=torch.nn.functional.scaled_dot_product_attention(q,k,v); output=output.transpose(1,2).contiguous().reshape(batch,ql,heads*hd); return module.to_out(output)
    for module in model.modules():
        if module.__class__.__name__=="Attention" and hasattr(module,"heads") and hasattr(module,"to_q") and hasattr(module,"to_kv") and hasattr(module,"to_out"):
            module.forward=types.MethodType(forward,module)

def _embed_nv_embed_v2(values:list[str],model:str,instruction:str|None)->np.ndarray:
    try:
        import torch
        from transformers import AutoConfig,AutoModel
    except ImportError as exc: raise RuntimeError("the nv-embed-v2 backend requires the hipporag-exact dependencies") from exc
    batch_size=max(1,int(os.environ.get("CLM_EMBED_BATCH_SIZE","4"))); char_budget=max(1,int(os.environ.get("CLM_NV_BATCH_CHAR_BUDGET","2048"))); prefix=f"Instruct: {instruction}\nQuery: " if instruction else ""; cache_root=Path(os.environ.get("CLM_EMBED_CACHE",".clm_data/embed_batches")); cache_root.mkdir(parents=True,exist_ok=True)
    indexed=sorted(enumerate(values),key=lambda item:(len(item[1]),item[0])); batches=[]; pending=[]; pending_max=0
    for item in indexed:
        prospective_max=max(pending_max,len(item[1]))
        if pending and (len(pending)>=batch_size or prospective_max*(len(pending)+1)>char_budget): batches.append(pending); pending=[]; pending_max=0
        pending.append(item); pending_max=max(pending_max,len(item[1]))
    if pending:batches.append(pending)
    outputs=[None]*len(values); completed=0
    for batch_number,indexed_batch in enumerate(batches,start=1):
        batch=[value for _,value in indexed_batch]; digest=hashlib.sha256(); digest.update(b"nv-embed-v2-sdpa4d-v1\0"); digest.update(model.encode()); digest.update(b"\0"); digest.update(prefix.encode())
        for value in batch:digest.update(b"\0"); digest.update(value.encode())
        cache_path=cache_root/f"{digest.hexdigest()}.npy"
        if cache_path.exists():
            vectors=np.load(cache_path)
            if vectors.ndim!=2 or len(vectors)!=len(batch):raise RuntimeError(f"invalid cached NV-Embed batch: {cache_path}")
        else:
            if model not in _NV_MODELS:
                cache_dir=os.environ.get("CLM_HF_CACHE"); load_source=os.environ.get("CLM_NV_MODEL_PATH",model); model_config=None
                if load_source!=model:
                    model_config=AutoConfig.from_pretrained(load_source,trust_remote_code=True,cache_dir=cache_dir,local_files_only=True); model_config._name_or_path=load_source
                    if getattr(model_config,"text_config",None) is not None:model_config.text_config._name_or_path=load_source
                loaded=AutoModel.from_pretrained(load_source,config=model_config,trust_remote_code=True,torch_dtype="auto",cache_dir=cache_dir,local_files_only=(load_source!=model))
                if torch.cuda.is_available(): loaded=loaded.to("cuda"); _patch_nv_sdpa_attention_4d(loaded,torch)
                elif torch.backends.mps.is_available(): loaded=loaded.to("mps"); _patch_nv_sdpa_attention_4d(loaded,torch)
                loaded.eval(); _NV_MODELS[model]=loaded
            encoder=_NV_MODELS[model]
            try:
                with torch.inference_mode(): vectors=encoder.encode(prompts=batch,instruction=prefix,max_length=2048)
            except torch.OutOfMemoryError:
                if not torch.cuda.is_available():raise
                torch.cuda.empty_cache()
                with torch.inference_mode(): vectors=encoder.encode(prompts=batch,instruction=prefix,max_length=2048)
            if isinstance(vectors,torch.Tensor):vectors=vectors.detach().float().cpu().numpy()
            vectors=np.asarray(vectors,dtype=np.float32); temporary=cache_path.with_suffix(".tmp")
            with temporary.open("wb") as handle:np.save(handle,vectors)
            os.replace(temporary,cache_path)
        for (original_index,_),vector in zip(indexed_batch,vectors): outputs[original_index]=np.asarray(vector,dtype=np.float32)
        completed+=len(batch)
        if len(values)>batch_size and (completed==len(values) or len(batches)<=10 or batch_number%10==0):print(f"embedded {completed}/{len(values)} with NV-Embed-v2",flush=True)
    if any(vector is None for vector in outputs):raise RuntimeError("NV-Embed-v2 failed to produce every requested vector")
    matrix=np.stack(outputs).astype(np.float32,copy=False) if outputs else np.zeros((0,4096),dtype=np.float32); norms=np.linalg.norm(matrix,axis=1,keepdims=True); return matrix/np.maximum(norms,1e-12)

def _embed_ollama(values:list[str],model:str,instruction:str|None)->np.ndarray:
    base=os.environ.get("OLLAMA_BASE_URL","http://127.0.0.1:11434").rstrip("/"); batch_size=max(1,int(os.environ.get("CLM_EMBED_BATCH_SIZE","64"))); char_budget=max(1,int(os.environ.get("CLM_OLLAMA_BATCH_CHAR_BUDGET","8192"))); prepared=[f"Instruct: {instruction}\nQuery: {value}" if instruction else value for value in values]; cache_root=Path(os.environ.get("CLM_EMBED_CACHE",".clm_data/embed_batches")); cache_root.mkdir(parents=True,exist_ok=True)
    def embed_batch(batch:list[str])->np.ndarray:
        digest=hashlib.sha256(); digest.update(model.encode())
        for value in batch:digest.update(b"\0"); digest.update(value.encode())
        cache_path=cache_root/f"{digest.hexdigest()}.npy"
        if cache_path.exists():
            embeddings=np.load(cache_path)
            if embeddings.ndim==2 and len(embeddings)==len(batch):return np.asarray(embeddings,dtype=np.float32)
        payload=json.dumps({"model":model,"input":batch,"keep_alive":"30m"}).encode(); request=urllib.request.Request(f"{base}/api/embed",data=payload,headers={"Content-Type":"application/json"},method="POST")
        try:
            with urllib.request.urlopen(request,timeout=1800) as response:result=json.loads(response.read())
        except urllib.error.HTTPError as exc:
            detail=exc.read().decode("utf-8",errors="replace").strip()
            if exc.code==400 and len(batch)>1:
                midpoint=len(batch)//2; return np.concatenate((embed_batch(batch[:midpoint]),embed_batch(batch[midpoint:])),axis=0)
            raise RuntimeError(f"Ollama embedding request failed for model {model!r}: HTTP Error {exc.code}{(': '+detail) if detail else ''}") from exc
        embeddings=np.asarray(result.get("embeddings",[]),dtype=np.float32)
        if embeddings.ndim!=2 or len(embeddings)!=len(batch):raise RuntimeError("Ollama returned an invalid embedding batch")
        temporary=cache_path.with_suffix(".tmp")
        with temporary.open("wb") as handle:np.save(handle,embeddings)
        os.replace(temporary,cache_path); return embeddings
    indexed=sorted(enumerate(prepared),key=lambda item:(len(item[1]),item[0])); batches=[]; pending=[]; pending_max=0
    for item in indexed:
        prospective_max=max(pending_max,len(item[1]))
        if pending and (len(pending)>=batch_size or prospective_max*(len(pending)+1)>char_budget):batches.append(pending); pending=[]; pending_max=0
        pending.append(item); pending_max=max(pending_max,len(item[1]))
    if pending:batches.append(pending)
    outputs=[None]*len(prepared); completed=0
    for batch_number,indexed_batch in enumerate(batches,start=1):
        matrix=embed_batch([value for _,value in indexed_batch])
        for (original_index,_),vector in zip(indexed_batch,matrix):outputs[original_index]=np.asarray(vector,dtype=np.float32)
        completed+=len(indexed_batch)
        if len(prepared)>1 and (batch_number%10==0 or batch_number==len(batches)):print(f"embedded {completed}/{len(prepared)} ({batch_number}/{len(batches)} batches)",flush=True)
    if any(vector is None for vector in outputs):raise RuntimeError("Ollama failed to produce every requested vector")
    vectors=np.stack(outputs).astype(np.float32,copy=False) if outputs else np.zeros((0,0),np.float32); norms=np.linalg.norm(vectors,axis=1,keepdims=True); return vectors/np.maximum(norms,1e-12)

def embed(texts:Iterable[str],*,backend:str="hashed",model:str="all-MiniLM-L6-v2",dim:int=DIM,instruction:str|None=None)->np.ndarray:
    values=list(texts)
    if backend=="hashed":return embed_hashed(values,dim=dim)
    if backend=="ollama":return _embed_ollama(values,model,instruction)
    if backend=="nv-embed-v2":return _embed_nv_embed_v2(values,model,instruction)
    if backend!="sentence-transformers":raise ValueError(f"unknown text embedding backend: {backend!r}")
    try:from sentence_transformers import SentenceTransformer
    except ImportError as exc:raise RuntimeError("sentence-transformers backend requested but the package is not installed") from exc
    if model not in _ST_MODELS:_ST_MODELS[model]=SentenceTransformer(model)
    return np.asarray(_ST_MODELS[model].encode(values,normalize_embeddings=True),dtype=np.float32)
def cosine(a:np.ndarray,b:np.ndarray)->np.ndarray:return a@b.T
