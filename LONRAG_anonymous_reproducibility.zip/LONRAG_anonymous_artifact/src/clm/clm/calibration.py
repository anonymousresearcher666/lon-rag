"""Finite-sample conformal thresholds for CLM verification scores."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import ceil, floor

import numpy as np


def _upper_quantile(values, alpha: float) -> float:
    ordered = np.sort(np.asarray(values, dtype=float))
    if len(ordered) == 0:
        raise ValueError("calibration scores must not be empty")
    rank = min(len(ordered) - 1, ceil((len(ordered) + 1) * (1 - alpha)) - 1)
    return float(ordered[max(rank, 0)])


def _lower_quantile(values, alpha: float) -> float:
    ordered = np.sort(np.asarray(values, dtype=float))
    if len(ordered) == 0:
        raise ValueError("calibration scores must not be empty")
    rank = max(0, floor((len(ordered) + 1) * alpha) - 1)
    return float(ordered[min(rank, len(ordered) - 1)])


@dataclass
class CalibrationState:
    alpha: float = 0.1
    gad_max: float = 1.5
    ccc_pass_min: float = 0.0
    reversed_slack_min: float = 0.0
    invalid_slack_min: float = 0.0
    calibrated: bool = False
    faithful_count: int = 0
    reversed_count: int = 0
    invalid_count: int = 0

    @classmethod
    def fit(
        cls,
        *,
        faithful_gad,
        faithful_ccc,
        reversed_slack=(),
        invalid_slack=(),
        alpha: float = 0.1,
    ) -> "CalibrationState":
        if not 0 < alpha < 1:
            raise ValueError("alpha must be between 0 and 1")
        faithful_gad = list(faithful_gad)
        faithful_ccc = list(faithful_ccc)
        reversed_slack = list(reversed_slack)
        invalid_slack = list(invalid_slack)
        if not faithful_gad or not faithful_ccc:
            raise ValueError("calibration requires faithful GAD and CCC examples")
        return cls(
            alpha=alpha,
            gad_max=_upper_quantile(faithful_gad, alpha),
            ccc_pass_min=_lower_quantile(faithful_ccc, alpha),
            reversed_slack_min=(
                _lower_quantile(reversed_slack, alpha) if reversed_slack else 0.0
            ),
            invalid_slack_min=(
                _lower_quantile(invalid_slack, alpha) if invalid_slack else 0.0
            ),
            calibrated=True,
            faithful_count=len(faithful_gad),
            reversed_count=len(reversed_slack),
            invalid_count=len(invalid_slack),
        )

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, values: dict | None) -> "CalibrationState":
        return cls(**values) if values else cls()
