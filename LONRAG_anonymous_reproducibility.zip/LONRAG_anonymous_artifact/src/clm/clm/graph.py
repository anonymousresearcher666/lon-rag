"""Typed semantic graph used by the CLM prototype."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterable
TAXONOMIC={"is_a","part_of","subclass_of"}; DEPENDENCY={"requires","causes","prevents","limits"}; OPPOSITION={"contradicts","alternative_to"}; RELATED={"related","mentioned_in"}; RELATION_CLASSES={"taxonomic":TAXONOMIC,"dependency":DEPENDENCY,"opposition":OPPOSITION,"related":RELATED}
def register_relation(label:str,klass:str)->None:
    try: relation_set=RELATION_CLASSES[klass]
    except KeyError as exc: raise ValueError(f"unknown relation class {klass!r}; choose {', '.join(sorted(RELATION_CLASSES))}") from exc
    normalized=label.lower().strip();
    if not normalized: raise ValueError("relation label must not be empty")
    relation_set.add(normalized)
@dataclass(frozen=True)
class Node: idx:int; name:str; kind:str="concept"; text:str=""; provenance:str=""
@dataclass
class Edge: src:int; dst:int; etype:str; confidence:float=1.0; provenance:str=""
@dataclass
class Graph:
    nodes:list[Node]=field(default_factory=list); edges:list[Edge]=field(default_factory=list); ccc_excluded_pairs:set[tuple[int,int]]=field(default_factory=set); _by_name:dict[tuple[str,str],int]=field(default_factory=dict); _edge_by_key:dict[tuple[int,int,str,str],Edge]=field(default_factory=dict)
    def add_node(self,name:str,kind:str="concept",text:str="",provenance:str="")->int:
        normalized=name.strip();
        if not normalized: raise ValueError("node name must not be empty")
        if kind not in {"concept","chunk"}: raise ValueError(f"unsupported node kind: {kind!r}")
        key=(kind,normalized)
        if key in self._by_name: return self._by_name[key]
        idx=len(self.nodes); self.nodes.append(Node(idx,normalized,kind,text,provenance)); self._by_name[key]=idx; return idx
    def get_concept(self,name:str)->int|None: return self._by_name.get(("concept",name))
    def add_edge(self,src:int,dst:int,etype:str,confidence:float=1.0,provenance:str="")->Edge:
        if not (0<=src<len(self.nodes) and 0<=dst<len(self.nodes)): raise IndexError(f"edge endpoints out of range: ({src}, {dst})")
        relation=etype.lower().strip();
        if not relation: raise ValueError("edge relation must not be empty")
        if not 0.0<=confidence<=1.0: raise ValueError("edge confidence must be between 0 and 1")
        key=(src,dst,relation,provenance)
        if key in self._edge_by_key:
            edge=self._edge_by_key[key]; edge.confidence=max(edge.confidence,float(confidence)); return edge
        edge=Edge(src,dst,relation,float(confidence),provenance); self.edges.append(edge); self._edge_by_key[key]=edge; return edge
    def edges_of(self,etypes:Iterable[str])->list[Edge]:
        relation_types=set(etypes); return [edge for edge in self.edges if edge.etype in relation_types]
    def dependency_scc_filter(self)->int:
        dependency_edges=self.edges_of(DEPENDENCY)
        if not dependency_edges: return 0
        adjacency={}; reverse={}; vertices=set()
        for edge in dependency_edges:
            adjacency.setdefault(edge.src,[]).append(edge.dst); reverse.setdefault(edge.dst,[]).append(edge.src); vertices.update((edge.src,edge.dst))
        visited=set(); finish_order=[]
        for start in vertices:
            if start in visited: continue
            stack=[(start,False)]
            while stack:
                node,expanded=stack.pop()
                if expanded: finish_order.append(node); continue
                if node in visited: continue
                visited.add(node); stack.append((node,True)); stack.extend((neighbor,False) for neighbor in adjacency.get(node,()) if neighbor not in visited)
        component={}; component_sizes={}
        for start in reversed(finish_order):
            if start in component: continue
            component_id=len(component_sizes); component_stack=[start]; component[start]=component_id; size=0
            while component_stack:
                node=component_stack.pop(); size+=1
                for neighbor in reverse.get(node,()):
                    if neighbor not in component: component[neighbor]=component_id; component_stack.append(neighbor)
            component_sizes[component_id]=size
        demoted=0
        for edge in dependency_edges:
            cid=component[edge.src]; in_cycle=cid==component[edge.dst] and (component_sizes[cid]>1 or edge.src==edge.dst)
            if not in_cycle: continue
            self._edge_by_key.pop((edge.src,edge.dst,edge.etype,edge.provenance),None); self.ccc_excluded_pairs.update(((edge.src,edge.dst),(edge.dst,edge.src))); edge.etype="related"; self._edge_by_key[(edge.src,edge.dst,edge.etype,edge.provenance)]=edge; demoted+=1
        return demoted
    def ccc_eligible(self,a:int,b:int,min_confidence:float=0.75)->bool:
        if (a,b) in self.ccc_excluded_pairs: return False
        direct=[edge for edge in self.edges if {edge.src,edge.dst}=={a,b} and edge.etype in DEPENDENCY|OPPOSITION]
        return not direct or max(edge.confidence for edge in direct)>=min_confidence
    def reachable(self,a:int,b:int,etypes:Iterable[str]=DEPENDENCY)->bool:
        relation_types=set(etypes); adjacency={}
        for edge in self.edges:
            if edge.etype in relation_types: adjacency.setdefault(edge.src,[]).append(edge.dst)
        seen,frontier={a},[a]
        while frontier:
            node=frontier.pop()
            for neighbor in adjacency.get(node,()):
                if neighbor==b:return True
                if neighbor not in seen: seen.add(neighbor); frontier.append(neighbor)
        return False
