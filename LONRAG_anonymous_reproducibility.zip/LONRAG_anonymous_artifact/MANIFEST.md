# Artifact manifest

## Included

- `README.md` — complete reproduction protocol.
- `pyproject.toml`, `requirements*.txt` — Python dependencies.
- `src/clm/clm/` — core graph, geometry, embedding, recognition, retrieval,
  training, verification and memory implementation.
- `scripts/bridge_paper_protocol.py` — deterministic BridgeRAG candidate/fusion accounting.
- `scripts/evaluate_bridge_conditioning_paper.py` — bridge-conditioned parent and non-evicting graph append evaluator.
- `scripts/evaluate_lon_lorentz_variant.py` — fixed-pool Lorentzian reranker.
- `scripts/evaluate_recognition.py` — recognition-guided retrieval calibration/holdout driver.
- `scripts/prepare_openie_stack.py` — memory/fact-index construction.
- `scripts/download_hipporag_reference_assets.py` — pinned public assets.
- `scripts/materialize_hipporag_corpus.py` — corpus-to-doc conversion.
- `scripts/generate_openie_from_corpus.py` — aligned OpenIE regeneration fallback.
- `scripts/prepare_graphrag_bench.py` — official-style GraphRAG-Bench chunk preparation.
- `scripts/generate_graphrag_bench_openie.py` — GraphRAG-Bench OpenIE generation.
- `scripts/build_graphrag_bench_stack.py` — per-corpus GraphRAG-Bench stack builder.
- `scripts/evaluate_graphrag_bench_corpus.py` — frozen transfer evaluator.
- `scripts/compare_lorentz_ablation.py`, `scripts/evaluation_common.py` — identity/statistics helpers.

## Explicitly excluded

- all experimental result JSON/JSONL files;
- generated paper-result macros and tables;
- datasets and corpus text;
- `.git` metadata and repository URLs;
- model weights;
- vector/fact indexes;
- embeddings and NumPy arrays;
- OpenIE/LLM response caches;
- PDFs and manuscript sources;
- local build products;
- any file larger than the lightweight code/documentation threshold.
